# TC-31 - Verify partial write failure across multiple target data stores does not leave data in an inconsistent state

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T16:01:00.910Z
**Result:** ✅ PASSED
**Duration:** 11019ms

## Test Description
Ingest one event. Query ALL target tables (InventoryFlight, InventoryFlightLeg, InventoryFlightPlace, InventoryFlightSegment, FlightState). Verify every table has a record AND all share the same RecordCorrelationId. A missing table or mismatched CorrelationId indicates a partial write.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785945652232-pzwae10i0"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8031-2026-11-21",
    "version": "310001",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8031"
    },
    "scheduledDepartureDate": "2026-11-21",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-21T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YUL_2",
        "iataCode": "YUL",
        "city": "YUL",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-21T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-21-YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-21T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-21T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-21T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-21T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YUL"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-21T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-21T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-21T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-21T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8031-2026-11-21",
    "originFeedTimeStamp": "2026-08-05T16:00:52.232Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2448 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T16:00:52.233Z

## Database Verification

### Query 1: InventoryFlight
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8031-2026-11-21"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8031-2026-11-21",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8031",
    "OperatingNumber": "8031",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-20T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ9AG1V531DNKHW2Q24YV7GY",
    "RecordCreatedAt": "2026-08-05T16:00:55.141Z",
    "RecordModifiedAt": "2026-08-05T16:00:55.141Z",
    "RecordExpiredAt": null,
    "RecordVersion": "310001"
  }
]
```

### Query 2: InventoryFlightLeg
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8031-2026-11-21"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8031-2026-11-21",
    "Id": "YYZ-YUL",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8031",
    "OperatingNumber": "8031",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YUL_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YUL",
    "LocalDepartureScheduleAt": "2026-11-21T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-21T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-21T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-21T14:30:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "320",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 170,
    "ScheduledFittedAircraftConfigurationCode": "321",
    "ScheduledFittedBusinessSeatCapacity": 14,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 156,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 14,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 156,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 14,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 156,
    "OperationalFittedAircraftConfigurationCode": "321",
    "OperationalFittedBusinessSeatCapacity": 14,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 156,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T16:00:55.141Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T16:00:55.141Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T16:00:55.141Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T16:00:55.141Z",
    "RecordCorrelationId": "01KZ9AG1V531DNKHW2Q24YV7GY",
    "RecordCreatedAt": "2026-08-05T16:00:55.141Z",
    "RecordModifiedAt": "2026-08-05T16:00:55.141Z",
    "RecordExpiredAt": null,
    "RecordVersion": "310001"
  }
]
```

### Query 3: InventoryFlightPlace
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightPlace" WHERE "InventoryFlightId" = $1
```
**Parameters:** ["AC-8031-2026-11-21"]
**Row Count:** 2
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8031-2026-11-21",
    "InventoryPlaceId": "YYZ_1",
    "PlaceIATACode": "YYZ",
    "PlaceCityCode": "YYZ",
    "CountryCode": "CA",
    "InventoryPlaceRegionCode": "NAMER",
    "InventoryPlaceContinentCode": "ITC1",
    "LocalScheduledDepartureAt": "2026-11-21T02:30:00.000Z",
    "LocalScheduledArrivalAt": null,
    "LocalEstimatedOffBlockAt": null,
    "LocalEstimatedTakeOffAt": null,
    "LocalEstimatedTouchdownAt": null,
    "LocalEstimatedOnBlockAt": null,
    "LocalActualOffBlockAt": null,
    "LocalActualTakeOffAt": null,
    "LocalActualTouchdownAt": null,
    "LocalActualOnBlockAt": null,
    "Terminals": [
      {
        "code": "1"
      }
    ],
    "RecordCorrelationId": "01KZ9AG1V531DNKHW2Q24YV7GY",
    "RecordCreatedAt": "2026-08-05T16:00:55.141Z",
    "RecordModifiedAt": "2026-08-05T16:00:55.141Z",
    "RecordExpiredAt": null,
    "RecordVersion": "310001"
  },
  {
    "InventoryFlightId": "AC-8031-2026-11-21",
    "InventoryPlaceId": "YUL_2",
    "PlaceIATACode": "YUL",
    "PlaceCityCode": "YUL",
    "CountryCode": "CA",
    "InventoryPlaceRegionCode": "NAMER",
    "InventoryPlaceContinentCode": "ITC1",
    "LocalScheduledDepartureAt": null,
    "LocalScheduledArrivalAt": "2026-11-21T05:00:00.000Z",
    "LocalEstimatedOffBlockAt": null,
    "LocalEstimatedTakeOffAt": null,
    "LocalEstimatedTouchdownAt": null,
    "LocalEstimatedOnBlockAt": null,
    "LocalActualOffBlockAt": null,
    "LocalActualTakeOffAt": null,
    "LocalActualTouchdownAt": null,
    "LocalActualOnBlockAt": null,
    "Terminals": [
      {
        "code": "1"
      }
    ],
    "RecordCorrelationId": "01KZ9AG1V531DNKHW2Q24YV7GY",
    "RecordCreatedAt": "2026-08-05T16:00:55.141Z",
    "RecordModifiedAt": "2026-08-05T16:00:55.141Z",
    "RecordExpiredAt": null,
    "RecordVersion": "310001"
  }
]
```

### Query 4: InventoryFlightSegment
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightSegment" WHERE "InventoryFlightId" = $1
```
**Parameters:** ["AC-8031-2026-11-21"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8031-2026-11-21",
    "Id": "2026-11-21-YYZ-YUL",
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YUL_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YUL",
    "LocalDepartureScheduleAt": "2026-11-21T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-21T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-21T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-21T14:30:00.000Z",
    "LegCount": 1,
    "TrafficRestrictions": null,
    "RecordCorrelationId": "01KZ9AG1V531DNKHW2Q24YV7GY",
    "RecordCreatedAt": "2026-08-05T16:00:55.141Z",
    "RecordModifiedAt": "2026-08-05T16:00:55.141Z",
    "RecordExpiredAt": null,
    "RecordVersion": "310001"
  }
]
```

### Query 5: FlightState
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT 
      "OperatingCarrierCode",
      "OperatingFlightNumber",
      "DepartureAirportIATACode",
      "ArrivalAirportIATACode",
      "LocalDepartureScheduledDate",
      "CurrentFlightAcceptanceStatusCode",
      "CurrentFlightGeneralStatusCode",
      "CurrentFlightLoadControlStatusCode",
      "CurrentFlightBoardingStatusCode",
      "PreviousFlightAcceptanceStatusCode",
      "PreviousFlightGeneralStatusCode",
      "PreviousFlightLoadControlStatusCode",
      "PreviousFlightBoardingStatusCode",
      "UTCFlightAcceptanceStatusModifiedAt",
      "UTCFlightGeneralStatusModifiedAt",
      "UTCFlightLoadControlStatusModifiedAt",
      "UTCFlightBoardingStatusModifiedAt",
      "RecordCreatedAt",
      "RecordModifiedAt",
      "RecordVersion",
      "SourceCreatedBy"
    FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8031","YYZ","2026-11-21"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8031",
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YUL",
    "LocalDepartureScheduledDate": "2026-11-20T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T16:00:55.141Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T16:00:55.141Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T16:00:55.141Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T16:00:55.141Z",
    "RecordCreatedAt": "2026-08-05T16:00:55.141Z",
    "RecordModifiedAt": "2026-08-05T16:00:55.141Z",
    "RecordVersion": "310001",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

## Assertions

✅ **Lambda success**: ✅ PASS
✅ **InventoryFlight written (no partial write)**: ✅ PASS
✅ **InventoryFlightLeg written (no partial write)**: ✅ PASS
✅ **InventoryFlightPlace written (no partial write)**: ✅ PASS
✅ **InventoryFlightSegment written (no partial write)**: ✅ PASS
✅ **FlightState written (no partial write)**: ✅ PASS
✅ **All CustomerDataMart tables share same RecordCorrelationId (atomic write)**: ✅ PASS
✅ **RecordCorrelationId is valid ULID (26 chars)**: ✅ PASS
✅ **⚠️ FlightState has different RecordCorrelationId (separate write — documented)**: ✅ PASS

---
## Final Verdict: ✅ PASSED