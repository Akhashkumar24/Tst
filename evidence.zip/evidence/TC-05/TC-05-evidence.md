# TC-05 - Validate FlightDesignator mapping (with/without franchisee flight)

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T07:27:39.631Z
**Result:** ✅ PASSED
**Duration:** 7804ms

## Test Description
Case A: carrier=AC, codeshare=OPERATING (OperatingCarrier=AC in FlightState). Case B: carrier=AC with franchisee=EY (OperatingCarrier=EY in FlightState).

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785914855631-0jt3jhwcr"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8055-2026-11-15",
    "version": "1785914855631907293",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8055"
    },
    "scheduledDepartureDate": "2026-11-15",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "INTERNATIONAL"
    ],
    "codeshare": "MARKETING",
    "flightPoints": [
      {
        "id": "AUH_1",
        "iataCode": "AUH",
        "city": "AUH",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-15T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YYZ_2",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-15T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-15-AUH-YYZ",
        "boardFlightPointId": "AUH_1",
        "offFlightPointId": "YYZ_2",
        "boardPointIataCode": "AUH",
        "offPointIataCode": "YYZ",
        "scheduledDepartureDateTime": "2026-11-15T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-15T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-15T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-15T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "AUH-YYZ"
        ]
      }
    ],
    "legs": [
      {
        "id": "AUH-YYZ",
        "boardFlightPointId": "AUH_1",
        "offFlightPointId": "YYZ_2",
        "boardPointIataCode": "AUH",
        "offPointIataCode": "YYZ",
        "scheduledDepartureDateTime": "2026-11-15T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-15T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-15T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-15T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "franchiseeFlight": {
            "airlineCode": "EY",
            "disclosure": "ETIHAD AIRWAYS"
          },
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8055-2026-11-15",
    "originFeedTimeStamp": "2026-08-05T07:27:35.631Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2536 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T07:27:35.631Z

## Database Verification

### Query 1: Case A FlightState (OPERATING, no franchisee)
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8005","YYZ","2026-11-15"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8005",
    "OperationalSuffix": null,
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YOW",
    "LocalDepartureScheduledDate": "2026-11-14T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T06:56:30.755Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T06:56:30.755Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T06:56:30.755Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T06:56:30.755Z",
    "CurrentBagFlightLoadStatusCode": null,
    "PreviousBagFlightLoadStatusCode": null,
    "UTCBagFlightLoadStatusModifiedAt": null,
    "RecordCorrelationId": "01KZ8D40NGC5JGTJZHAWC2Q1BB",
    "RecordCreatedAt": "2026-08-05T06:56:30.755Z",
    "RecordModifiedAt": "2026-08-05T07:27:32.016Z",
    "RecordExpiredAt": "2027-08-05T07:27:32.016Z",
    "RecordVersion": "1785914851827112000",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

### Query 2: Case B FlightState (MARKETING, franchisee=EY)
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["EY","8055","AUH","2026-11-15"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "EY",
    "OperatingFlightNumber": "8055",
    "OperationalSuffix": null,
    "DepartureAirportIATACode": "AUH",
    "ArrivalAirportIATACode": "YYZ",
    "LocalDepartureScheduledDate": "2026-11-14T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T06:56:35.562Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T06:56:35.562Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T06:56:35.562Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T06:56:35.562Z",
    "CurrentBagFlightLoadStatusCode": null,
    "PreviousBagFlightLoadStatusCode": null,
    "UTCBagFlightLoadStatusModifiedAt": null,
    "RecordCorrelationId": "01KZ8D44DE3A9F15XDT7RK8DCJ",
    "RecordCreatedAt": "2026-08-05T06:56:35.562Z",
    "RecordModifiedAt": "2026-08-05T07:27:35.854Z",
    "RecordExpiredAt": "2027-08-05T07:27:35.854Z",
    "RecordVersion": "1785914855631907300",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

### Query 3: Case B FlightState alt (carrier=AC check)
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8055","AUH","2026-11-15"]
**Row Count:** 0
**Results:**
```json
[]
```

## Assertions

✅ **Case A: FlightState exists for AC-8005**: ✅ PASS
✅ **Case A: OperatingCarrierCode=AC**: ✅ PASS
✅ **Case B: FlightState exists for franchisee flight**: ✅ PASS
✅ **Case B: OperatingCarrierCode mapped correctly**: ✅ PASS

---
## Final Verdict: ✅ PASSED