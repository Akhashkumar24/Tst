# TC-13 - Verify special characters in text fields are handled safely

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T07:46:13.595Z
**Result:** ✅ PASSED
**Duration:** 6519ms

## Test Description
Ingest event with terminal='A1@#$%'. Verify stored safely in BookingInventoryDataStore.InventoryFlightPlace.Terminals (jsonb). No SQL injection or crash.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785915969300-9sanj2j7g"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8013-2026-11-16",
    "version": "1785915969300355933",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8013"
    },
    "scheduledDepartureDate": "2026-11-16",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-16T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "A1@#$%"
            }
          ]
        }
      },
      {
        "id": "YUL_2",
        "iataCode": "YUL",
        "city": "YUL",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-16T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-16-YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-16T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-16T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-16T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YUL"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-16T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-16T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-16T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8013-2026-11-16",
    "originFeedTimeStamp": "2026-08-05T07:46:09.300Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2466 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T07:46:09.300Z

## Database Verification

### Query 1: InventoryFlight
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8013-2026-11-16"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8013-2026-11-16",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8013",
    "OperatingNumber": "8013",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-15T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8E63YK243STH8XAWP0DRKJ",
    "RecordCreatedAt": "2026-08-05T07:46:09.491Z",
    "RecordModifiedAt": "2026-08-05T07:46:09.491Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785915969300355800"
  }
]
```

### Query 2: InventoryFlightPlace (Terminals jsonb)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightPlace" WHERE "InventoryFlightId" = $1
```
**Parameters:** ["AC-8013-2026-11-16"]
**Row Count:** 2
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8013-2026-11-16",
    "InventoryPlaceId": "YYZ_1",
    "PlaceIATACode": "YYZ",
    "PlaceCityCode": "YYZ",
    "CountryCode": "CA",
    "InventoryPlaceRegionCode": "NAMER",
    "InventoryPlaceContinentCode": "ITC1",
    "LocalScheduledDepartureAt": "2026-11-16T02:30:00.000Z",
    "LocalScheduledArrivalAt": null,
    "LocalEstimatedOffBlockAt": null,
    "LocalEstimatedTakeOffAt": null,
    "LocalEstimatedTouchdownAt": null,
    "LocalEstimatedOnBlockAt": null,
    "LocalActualOffBlockAt": null,
    "LocalActualTakeOffAt": null,
    "LocalActualTouchdownAt": null,
    "LocalActualOnBlockAt": null,
    "Terminals": [
      {
        "code": "A1@#$%"
      }
    ],
    "RecordCorrelationId": "01KZ8E63YK243STH8XAWP0DRKJ",
    "RecordCreatedAt": "2026-08-05T07:46:09.491Z",
    "RecordModifiedAt": "2026-08-05T07:46:09.491Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785915969300355800"
  },
  {
    "InventoryFlightId": "AC-8013-2026-11-16",
    "InventoryPlaceId": "YUL_2",
    "PlaceIATACode": "YUL",
    "PlaceCityCode": "YUL",
    "CountryCode": "CA",
    "InventoryPlaceRegionCode": "NAMER",
    "InventoryPlaceContinentCode": "ITC1",
    "LocalScheduledDepartureAt": null,
    "LocalScheduledArrivalAt": "2026-11-16T05:00:00.000Z",
    "LocalEstimatedOffBlockAt": null,
    "LocalEstimatedTakeOffAt": null,
    "LocalEstimatedTouchdownAt": null,
    "LocalEstimatedOnBlockAt": null,
    "LocalActualOffBlockAt": null,
    "LocalActualTakeOffAt": null,
    "LocalActualTouchdownAt": null,
    "LocalActualOnBlockAt": null,
    "Terminals": [
      {
        "code": "1"
      }
    ],
    "RecordCorrelationId": "01KZ8E63YK243STH8XAWP0DRKJ",
    "RecordCreatedAt": "2026-08-05T07:46:09.491Z",
    "RecordModifiedAt": "2026-08-05T07:46:09.491Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785915969300355800"
  }
]
```

### Query 3: FlightState
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8013","YYZ","2026-11-16"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8013",
    "OperationalSuffix": null,
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YUL",
    "LocalDepartureScheduledDate": "2026-11-15T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T07:46:09.491Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T07:46:09.491Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T07:46:09.491Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T07:46:09.491Z",
    "CurrentBagFlightLoadStatusCode": null,
    "PreviousBagFlightLoadStatusCode": null,
    "UTCBagFlightLoadStatusModifiedAt": null,
    "RecordCorrelationId": "01KZ8E63YK243STH8XAWP0DRKJ",
    "RecordCreatedAt": "2026-08-05T07:46:09.491Z",
    "RecordModifiedAt": "2026-08-05T07:46:09.491Z",
    "RecordExpiredAt": "2027-08-05T07:46:09.491Z",
    "RecordVersion": "1785915969300355800",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

## Assertions

✅ **Lambda did not crash (200)**: ✅ PASS
✅ **No Lambda functionError**: ✅ PASS
✅ **InventoryFlight record persisted**: ✅ PASS
✅ **InventoryFlightPlace records persisted**: ✅ PASS
✅ **Terminals jsonb stored special chars safely**: ✅ PASS

---
## Final Verdict: ✅ PASSED