# TC-46 - Validate CarrierCode resolution in InventoryFlight and FlightState

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T10:12:35.482Z
**Result:** ✅ PASSED
**Duration:** 16236ms

## Test Description
Case A: no franchisee (codeshare=OPERATING → MarketingCarrierCode=AC, OperatingCarrierCode=AC). Case B: franchisee=EY (OperatingCarrierCode=EY in FlightState).

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785924751097-oqvl1r9yt"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8146-2026-11-19",
    "version": "1785924751097459269",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8146"
    },
    "scheduledDepartureDate": "2026-11-19",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "MARKETING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-19T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YUL_2",
        "iataCode": "YUL",
        "city": "YUL",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-19T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-19-YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-19T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-19T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-19T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-19T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YUL"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-19T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-19T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-19T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-19T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "franchiseeFlight": {
            "airlineCode": "EY",
            "disclosure": "ETIHAD"
          },
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8146-2026-11-19",
    "originFeedTimeStamp": "2026-08-05T10:12:31.097Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2523 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T10:12:31.097Z

## Database Verification

### Query 1: Case A: InventoryFlight (no franchisee)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8046-2026-11-19"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8046-2026-11-19",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8046",
    "OperatingNumber": "8046",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-18T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8PHZN3HK374YH7NXV63PZM",
    "RecordCreatedAt": "2026-08-05T10:12:26.915Z",
    "RecordModifiedAt": "2026-08-05T10:12:26.915Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924743909742800"
  }
]
```

### Query 2: Case A: FlightState
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8046","YYZ","2026-11-19"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8046",
    "OperationalSuffix": null,
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YUL",
    "LocalDepartureScheduledDate": "2026-11-18T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T10:12:26.915Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T10:12:26.915Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T10:12:26.915Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T10:12:26.915Z",
    "CurrentBagFlightLoadStatusCode": null,
    "PreviousBagFlightLoadStatusCode": null,
    "UTCBagFlightLoadStatusModifiedAt": null,
    "RecordCorrelationId": "01KZ8PHZN3HK374YH7NXV63PZM",
    "RecordCreatedAt": "2026-08-05T10:12:26.915Z",
    "RecordModifiedAt": "2026-08-05T10:12:26.915Z",
    "RecordExpiredAt": "2027-08-05T10:12:26.915Z",
    "RecordVersion": "1785924743909742800",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

### Query 3: Case B: InventoryFlight (franchisee=EY)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8146-2026-11-19"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8146-2026-11-19",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8146",
    "OperatingNumber": "8146",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-18T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": false,
    "IsMarketingCodeshare": true,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8PJ3Z1GAVF82NTKBRJZEDM",
    "RecordCreatedAt": "2026-08-05T10:12:31.330Z",
    "RecordModifiedAt": "2026-08-05T10:12:31.330Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924751097459200"
  }
]
```

### Query 4: Case B: FlightState (EY lookup)
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["EY","8146","YYZ","2026-11-19"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "EY",
    "OperatingFlightNumber": "8146",
    "OperationalSuffix": null,
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YUL",
    "LocalDepartureScheduledDate": "2026-11-18T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T10:12:31.330Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T10:12:31.330Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T10:12:31.330Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T10:12:31.330Z",
    "CurrentBagFlightLoadStatusCode": null,
    "PreviousBagFlightLoadStatusCode": null,
    "UTCBagFlightLoadStatusModifiedAt": null,
    "RecordCorrelationId": "01KZ8PJ3Z1GAVF82NTKBRJZEDM",
    "RecordCreatedAt": "2026-08-05T10:12:31.330Z",
    "RecordModifiedAt": "2026-08-05T10:12:31.330Z",
    "RecordExpiredAt": "2027-08-05T10:12:31.330Z",
    "RecordVersion": "1785924751097459200",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

### Query 5: Case B: FlightState (AC lookup)
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8146","YYZ","2026-11-19"]
**Row Count:** 0
**Results:**
```json
[]
```

## Assertions

✅ **Case A: InventoryFlight exists**: ✅ PASS
✅ **Case A: FlightState exists**: ✅ PASS
✅ **Case A: MarketingCarrierCode=AC**: ✅ PASS
✅ **Case A: OperatingCarrierCode=AC**: ✅ PASS
✅ **Case A: FlightState.OperatingCarrierCode=AC**: ✅ PASS
✅ **Case B: InventoryFlight exists**: ✅ PASS
✅ **Case B: FlightState exists (EY or AC)**: ✅ PASS
✅ **Case B: InventoryFlight.OperatingCarrierCode documented**: ✅ PASS

---
## Final Verdict: ✅ PASSED