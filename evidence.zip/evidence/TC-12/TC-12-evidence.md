# TC-12 - Verify IATA airport code format handling at writer level

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T07:46:07.073Z
**Result:** ✅ PASSED
**Duration:** 19334ms

## Test Description
Valid 3-char 'YYZ' persists correctly. Invalid formats ('YY','YYZZ','123') — writer may accept or truncate. Documents actual behavior.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785915955855-cfvstx8dl"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8012-2026-11-16",
    "version": "1785915955855620696",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8012"
    },
    "scheduledDepartureDate": "2026-11-16",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-16T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YUL_2",
        "iataCode": "YUL",
        "city": "YUL",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-16T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-16-YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-16T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-16T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-16T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YUL"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-16T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-16T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-16T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8012-2026-11-16",
    "originFeedTimeStamp": "2026-08-05T07:45:55.855Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2461 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** N/A
- **Function Error:** None
- **Invoked At:** N/A

## Database Verification

### Query 1: Valid IATA 'YYZ' — InventoryFlight
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8012-2026-11-16"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8012-2026-11-16",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8012",
    "OperatingNumber": "8012",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-15T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8E5PTG9HBH2HJYZ3P82ZQ2",
    "RecordCreatedAt": "2026-08-05T07:45:56.048Z",
    "RecordModifiedAt": "2026-08-05T07:45:56.048Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785915955855620600"
  }
]
```

### Query 2: Valid IATA 'YYZ' — FlightState
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8012","YYZ","2026-11-16"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8012",
    "OperationalSuffix": null,
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YUL",
    "LocalDepartureScheduledDate": "2026-11-15T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T07:45:56.048Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T07:45:56.048Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T07:45:56.048Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T07:45:56.048Z",
    "CurrentBagFlightLoadStatusCode": null,
    "PreviousBagFlightLoadStatusCode": null,
    "UTCBagFlightLoadStatusModifiedAt": null,
    "RecordCorrelationId": "01KZ8E5PTG9HBH2HJYZ3P82ZQ2",
    "RecordCreatedAt": "2026-08-05T07:45:56.048Z",
    "RecordModifiedAt": "2026-08-05T07:45:56.048Z",
    "RecordExpiredAt": "2027-08-05T07:45:56.048Z",
    "RecordVersion": "1785915955855620600",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

### Query 3: IATA 'YY' (2 chars) — InventoryFlight
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8112-2026-11-16"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8112-2026-11-16",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8112",
    "OperatingNumber": "8112",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-15T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8E5ST77MVP5MJC62KBDZ64",
    "RecordCreatedAt": "2026-08-05T07:45:59.111Z",
    "RecordModifiedAt": "2026-08-05T07:45:59.111Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785915958919325400"
  }
]
```

### Query 4: IATA 'YYZZ' (4 chars) — InventoryFlight
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8212-2026-11-16"]
**Row Count:** 0
**Results:**
```json
[]
```

### Query 5: IATA '123' (numeric) — InventoryFlight
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8312-2026-11-16"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8312-2026-11-16",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8312",
    "OperatingNumber": "8312",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-15T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8E5Z2YD1NKRVCJTTMDVZRE",
    "RecordCreatedAt": "2026-08-05T07:46:04.511Z",
    "RecordModifiedAt": "2026-08-05T07:46:04.511Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785915964308224000"
  }
]
```

## Assertions

✅ **Lambda 200 for valid IATA YYZ**: ✅ PASS
✅ **Valid 'YYZ' — InventoryFlight created**: ✅ PASS
✅ **Valid 'YYZ' — FlightState created**: ✅ PASS
✅ **Lambda 200 for 'YY' (no crash)**: ✅ PASS
✅ **Lambda 200 for 'YYZZ' (no crash)**: ✅ PASS
✅ **Lambda 200 for '123' (no crash)**: ✅ PASS
✅ **'YY' behavior documented (may persist or DB reject)**: ✅ PASS
✅ **'YYZZ' behavior documented (may truncate or DB reject)**: ✅ PASS
✅ **'123' behavior documented**: ✅ PASS

---
## Final Verdict: ✅ PASSED