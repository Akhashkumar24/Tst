# TC-33 - Verify ingestion of payload with unrecognized field does not fail

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T09:58:15.805Z
**Result:** ✅ PASSED
**Duration:** 8561ms

## Test Description
Ingest valid event + extra unmapped field 'newAttribute':'value123' and nested unknown on leg. Verify ingested to BookingInventoryDataStore.InventoryFlight and InventoryFlightLeg, unmapped fields silently ignored.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785923890945-cy1f24k29"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8033-2026-11-18",
    "version": "1785923890945956792",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8033"
    },
    "scheduledDepartureDate": "2026-11-18",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-18T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        },
        "extraPointField": "should-be-ignored"
      },
      {
        "id": "YOW_2",
        "iataCode": "YOW",
        "city": "YOW",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-18T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-18-YYZ-YOW",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YOW_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YOW",
        "scheduledDepartureDateTime": "2026-11-18T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-18T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-18T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-18T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YOW"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-YOW",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YOW_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YOW",
        "scheduledDepartureDateTime": "2026-11-18T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-18T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-18T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-18T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        },
        "unknownLegField": {
          "nested": true,
          "data": [
            1,
            2,
            3
          ]
        }
      }
    ],
    "newAttribute": "value123"
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8033-2026-11-18",
    "originFeedTimeStamp": "2026-08-05T09:58:10.945Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2574 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T09:58:10.946Z

## Database Verification

### Query 1: InventoryFlight (extra field ignored)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8033-2026-11-18"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8033-2026-11-18",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8033",
    "OperatingNumber": "8033",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-17T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8NQVYWY5WEK226W2PTX2BT",
    "RecordCreatedAt": "2026-08-05T09:58:11.164Z",
    "RecordModifiedAt": "2026-08-05T09:58:11.164Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785923890945956900"
  }
]
```

### Query 2: InventoryFlightLeg (extra field ignored)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8033-2026-11-18"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8033-2026-11-18",
    "Id": "YYZ-YOW",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8033",
    "OperatingNumber": "8033",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YOW_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YOW",
    "LocalDepartureScheduleAt": "2026-11-18T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-18T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-18T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-18T14:30:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "320",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 170,
    "ScheduledFittedAircraftConfigurationCode": "321",
    "ScheduledFittedBusinessSeatCapacity": 14,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 156,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 14,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 156,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 14,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 156,
    "OperationalFittedAircraftConfigurationCode": "321",
    "OperationalFittedBusinessSeatCapacity": 14,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 156,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T09:58:11.164Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T09:58:11.164Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T09:58:11.164Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T09:58:11.164Z",
    "RecordCorrelationId": "01KZ8NQVYWY5WEK226W2PTX2BT",
    "RecordCreatedAt": "2026-08-05T09:58:11.164Z",
    "RecordModifiedAt": "2026-08-05T09:58:11.164Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785923890945956900"
  }
]
```

### Query 3: InventoryFlightPlace (extra field ignored)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightPlace" WHERE "InventoryFlightId" = $1
```
**Parameters:** ["AC-8033-2026-11-18"]
**Row Count:** 2
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8033-2026-11-18",
    "InventoryPlaceId": "YYZ_1",
    "PlaceIATACode": "YYZ",
    "PlaceCityCode": "YYZ",
    "CountryCode": "CA",
    "InventoryPlaceRegionCode": "NAMER",
    "InventoryPlaceContinentCode": "ITC1",
    "LocalScheduledDepartureAt": "2026-11-18T02:30:00.000Z",
    "LocalScheduledArrivalAt": null,
    "LocalEstimatedOffBlockAt": null,
    "LocalEstimatedTakeOffAt": null,
    "LocalEstimatedTouchdownAt": null,
    "LocalEstimatedOnBlockAt": null,
    "LocalActualOffBlockAt": null,
    "LocalActualTakeOffAt": null,
    "LocalActualTouchdownAt": null,
    "LocalActualOnBlockAt": null,
    "Terminals": [
      {
        "code": "1"
      }
    ],
    "RecordCorrelationId": "01KZ8NQVYWY5WEK226W2PTX2BT",
    "RecordCreatedAt": "2026-08-05T09:58:11.164Z",
    "RecordModifiedAt": "2026-08-05T09:58:11.164Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785923890945956900"
  },
  {
    "InventoryFlightId": "AC-8033-2026-11-18",
    "InventoryPlaceId": "YOW_2",
    "PlaceIATACode": "YOW",
    "PlaceCityCode": "YOW",
    "CountryCode": "CA",
    "InventoryPlaceRegionCode": "NAMER",
    "InventoryPlaceContinentCode": "ITC1",
    "LocalScheduledDepartureAt": null,
    "LocalScheduledArrivalAt": "2026-11-18T05:00:00.000Z",
    "LocalEstimatedOffBlockAt": null,
    "LocalEstimatedTakeOffAt": null,
    "LocalEstimatedTouchdownAt": null,
    "LocalEstimatedOnBlockAt": null,
    "LocalActualOffBlockAt": null,
    "LocalActualTakeOffAt": null,
    "LocalActualTouchdownAt": null,
    "LocalActualOnBlockAt": null,
    "Terminals": [
      {
        "code": "1"
      }
    ],
    "RecordCorrelationId": "01KZ8NQVYWY5WEK226W2PTX2BT",
    "RecordCreatedAt": "2026-08-05T09:58:11.164Z",
    "RecordModifiedAt": "2026-08-05T09:58:11.164Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785923890945956900"
  }
]
```

### Query 4: FlightState
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8033","YYZ","2026-11-18"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8033",
    "OperationalSuffix": null,
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YOW",
    "LocalDepartureScheduledDate": "2026-11-17T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T09:58:11.164Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T09:58:11.164Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T09:58:11.164Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T09:58:11.164Z",
    "CurrentBagFlightLoadStatusCode": null,
    "PreviousBagFlightLoadStatusCode": null,
    "UTCBagFlightLoadStatusModifiedAt": null,
    "RecordCorrelationId": "01KZ8NQVYWY5WEK226W2PTX2BT",
    "RecordCreatedAt": "2026-08-05T09:58:11.164Z",
    "RecordModifiedAt": "2026-08-05T09:58:11.164Z",
    "RecordExpiredAt": "2027-08-05T09:58:11.164Z",
    "RecordVersion": "1785923890945956900",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

## Assertions

✅ **Lambda success (no crash on extra fields)**: ✅ PASS
✅ **No Lambda functionError**: ✅ PASS
✅ **InventoryFlight persisted despite extra fields**: ✅ PASS
✅ **InventoryFlightLeg persisted despite extra fields**: ✅ PASS
✅ **InventoryFlightPlace persisted**: ✅ PASS
✅ **FlightState persisted**: ✅ PASS

---
## Final Verdict: ✅ PASSED