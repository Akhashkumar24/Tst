# TC-38 - Verify write consistency between InventoryFlightLeg and FlightState for DCS statuses

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T10:00:00.180Z
**Result:** ✅ PASSED
**Duration:** 8076ms

## Test Description
Ingest event with specific DCS statuses (GATED/OPEN/OPEN/STARTED). Query both BookingInventoryDataStore.InventoryFlightLeg and FlightOperationsDataStore.FlightState. Compare CurrentFlightAcceptanceStatusCode, CurrentFlightBoardingStatusCode values.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785923994762-w0omvazmz"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8038-2026-11-18",
    "version": "1785923994762624225",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8038"
    },
    "scheduledDepartureDate": "2026-11-18",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YUL_1",
        "iataCode": "YUL",
        "city": "YUL",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-18T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YYZ_2",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-18T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-18-YUL-YYZ",
        "boardFlightPointId": "YUL_1",
        "offFlightPointId": "YYZ_2",
        "boardPointIataCode": "YUL",
        "offPointIataCode": "YYZ",
        "scheduledDepartureDateTime": "2026-11-18T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-18T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-18T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-18T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YUL-YYZ"
        ]
      }
    ],
    "legs": [
      {
        "id": "YUL-YYZ",
        "boardFlightPointId": "YUL_1",
        "offFlightPointId": "YYZ_2",
        "boardPointIataCode": "YUL",
        "offPointIataCode": "YYZ",
        "scheduledDepartureDateTime": "2026-11-18T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-18T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-18T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-18T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "GATED",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "STARTED"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8038-2026-11-18",
    "originFeedTimeStamp": "2026-08-05T09:59:54.762Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2461 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T09:59:54.763Z

## Database Verification

### Query 1: InventoryFlightLeg (DCS statuses)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8038-2026-11-18"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8038-2026-11-18",
    "Id": "YUL-YYZ",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8038",
    "OperatingNumber": "8038",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YUL_1",
    "OffInventoryPlaceId": "YYZ_2",
    "BoardPlaceIATACode": "YUL",
    "OffPlaceIATACode": "YYZ",
    "LocalDepartureScheduleAt": "2026-11-18T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-18T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-18T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-18T14:30:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "320",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 170,
    "ScheduledFittedAircraftConfigurationCode": "321",
    "ScheduledFittedBusinessSeatCapacity": 14,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 156,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 14,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 156,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 14,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 156,
    "OperationalFittedAircraftConfigurationCode": "321",
    "OperationalFittedBusinessSeatCapacity": 14,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 156,
    "CurrentFlightAcceptanceStatusCode": "GATED",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "STARTED",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T09:59:54.965Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T09:59:54.965Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T09:59:54.965Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T09:59:54.965Z",
    "RecordCorrelationId": "01KZ8NV1ANE2P555KQPHQ5YNH6",
    "RecordCreatedAt": "2026-08-05T09:59:54.965Z",
    "RecordModifiedAt": "2026-08-05T09:59:54.965Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785923994762624300"
  }
]
```

### Query 2: FlightState (DCS statuses)
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT 
      "OperatingCarrierCode",
      "OperatingFlightNumber",
      "DepartureAirportIATACode",
      "ArrivalAirportIATACode",
      "LocalDepartureScheduledDate",
      "CurrentFlightAcceptanceStatusCode",
      "CurrentFlightGeneralStatusCode",
      "CurrentFlightLoadControlStatusCode",
      "CurrentFlightBoardingStatusCode",
      "PreviousFlightAcceptanceStatusCode",
      "PreviousFlightGeneralStatusCode",
      "PreviousFlightLoadControlStatusCode",
      "PreviousFlightBoardingStatusCode",
      "UTCFlightAcceptanceStatusModifiedAt",
      "UTCFlightGeneralStatusModifiedAt",
      "UTCFlightLoadControlStatusModifiedAt",
      "UTCFlightBoardingStatusModifiedAt",
      "RecordCreatedAt",
      "RecordModifiedAt",
      "RecordVersion",
      "SourceCreatedBy"
    FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8038","YUL","2026-11-18"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8038",
    "DepartureAirportIATACode": "YUL",
    "ArrivalAirportIATACode": "YYZ",
    "LocalDepartureScheduledDate": "2026-11-17T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "GATED",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "STARTED",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T09:59:54.965Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T09:59:54.965Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T09:59:54.965Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T09:59:54.965Z",
    "RecordCreatedAt": "2026-08-05T09:59:54.965Z",
    "RecordModifiedAt": "2026-08-05T09:59:54.965Z",
    "RecordVersion": "1785923994762624300",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

## Assertions

✅ **Lambda success**: ✅ PASS
✅ **InventoryFlightLeg record exists**: ✅ PASS
✅ **FlightState record exists**: ✅ PASS
✅ **InventoryFlightLeg.CurrentFlightAcceptanceStatusCode = GATED**: ✅ PASS
✅ **FlightState.CurrentFlightAcceptanceStatusCode = GATED**: ✅ PASS
✅ **InventoryFlightLeg.CurrentFlightGeneralStatusCode = OPEN**: ✅ PASS
✅ **FlightState.CurrentFlightGeneralStatusCode = OPEN**: ✅ PASS
✅ **InventoryFlightLeg.CurrentFlightLoadControlStatusCode = OPEN**: ✅ PASS
✅ **FlightState.CurrentFlightLoadControlStatusCode = OPEN**: ✅ PASS
✅ **InventoryFlightLeg.CurrentFlightBoardingStatusCode = STARTED**: ✅ PASS
✅ **FlightState.CurrentFlightBoardingStatusCode = STARTED**: ✅ PASS
✅ **Acceptance status consistent across both DBs**: ✅ PASS
✅ **Boarding status consistent across both DBs**: ✅ PASS

---
## Final Verdict: ✅ PASSED