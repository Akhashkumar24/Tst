# TC-07 - Validate segments correctly linked to legs

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T07:27:47.700Z
**Result:** ✅ PASSED
**Duration:** 4044ms

## Test Description
Ingest multi-leg event with through segment (YYZ→LHR via YHZ). Verify 3 segments and 2 legs created.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785914863657-way2qo6ve"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8007-2026-11-15",
    "version": "1785914863657845688",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8007"
    },
    "scheduledDepartureDate": "2026-11-15",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "INTERNATIONAL"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-15T19:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YHZ_2",
        "iataCode": "YHZ",
        "city": "YHZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-15T23:05:00"
            }
          ]
        },
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-15T22:09:00"
            }
          ]
        }
      },
      {
        "id": "LHR_3",
        "iataCode": "LHR",
        "city": "LON",
        "country": "GB",
        "region": "EUROP",
        "continent": "ITC2",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-16T09:00:00"
            }
          ],
          "terminals": [
            {
              "code": "2"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-15-YYZ-YHZ",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YHZ_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YHZ",
        "scheduledDepartureDateTime": "2026-11-15T19:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-15T23:00:00Z",
        "scheduledArrivalDateTime": "2026-11-15T22:09:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T01:09:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YHZ"
        ]
      },
      {
        "id": "2026-11-15-YYZ-LHR",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "LHR_3",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "LHR",
        "scheduledDepartureDateTime": "2026-11-15T19:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-15T23:00:00Z",
        "scheduledArrivalDateTime": "2026-11-16T09:00:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T08:00:00Z",
        "numberOfLegs": 2,
        "legIds": [
          "YYZ-YHZ",
          "YHZ-LHR"
        ]
      },
      {
        "id": "2026-11-15-YHZ-LHR",
        "boardFlightPointId": "YHZ_2",
        "offFlightPointId": "LHR_3",
        "boardPointIataCode": "YHZ",
        "offPointIataCode": "LHR",
        "scheduledDepartureDateTime": "2026-11-15T23:05:00",
        "scheduledDepartureDateTimeUtc": "2026-11-16T02:05:00Z",
        "scheduledArrivalDateTime": "2026-11-16T09:00:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T08:00:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YHZ-LHR"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-YHZ",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YHZ_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YHZ",
        "scheduledDepartureDateTime": "2026-11-15T19:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-15T23:00:00Z",
        "scheduledArrivalDateTime": "2026-11-15T22:09:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T01:09:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "7M8",
          "scheduledFittedConfiguration": {
            "code": "7M1",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 153
              }
            ]
          },
          "acvTotalCapacity": 169,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 153
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 153
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "7M1",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 153
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      },
      {
        "id": "YHZ-LHR",
        "boardFlightPointId": "YHZ_2",
        "offFlightPointId": "LHR_3",
        "boardPointIataCode": "YHZ",
        "offPointIataCode": "LHR",
        "scheduledDepartureDateTime": "2026-11-15T23:05:00",
        "scheduledDepartureDateTimeUtc": "2026-11-16T02:05:00Z",
        "scheduledArrivalDateTime": "2026-11-16T09:00:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T08:00:00Z",
        "routingOrder": 2,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "7M8",
          "scheduledFittedConfiguration": {
            "code": "7M1",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 153
              }
            ]
          },
          "acvTotalCapacity": 169,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 153
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 153
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "7M1",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 153
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8007-2026-11-15",
    "originFeedTimeStamp": "2026-08-05T07:27:43.657Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 4567 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T07:27:43.657Z

## Database Verification

### Query 1: InventoryFlightSegment
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightSegment" WHERE "InventoryFlightId" = $1
```
**Parameters:** ["AC-8007-2026-11-15"]
**Row Count:** 3
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8007-2026-11-15",
    "Id": "2026-11-15-YYZ-YHZ",
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YHZ_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YHZ",
    "LocalDepartureScheduleAt": "2026-11-15T13:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-15T23:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-15T16:39:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-16T01:09:00.000Z",
    "LegCount": 1,
    "TrafficRestrictions": null,
    "RecordCorrelationId": "01KZ8D4C6ZYH8FWK82XZSPM5BN",
    "RecordCreatedAt": "2026-08-05T06:56:43.663Z",
    "RecordModifiedAt": "2026-08-05T07:27:43.839Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785914863657845800"
  },
  {
    "InventoryFlightId": "AC-8007-2026-11-15",
    "Id": "2026-11-15-YYZ-LHR",
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "LHR_3",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "LHR",
    "LocalDepartureScheduleAt": "2026-11-15T13:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-15T23:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-16T03:30:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-16T08:00:00.000Z",
    "LegCount": 2,
    "TrafficRestrictions": null,
    "RecordCorrelationId": "01KZ8D4C6ZYH8FWK82XZSPM5BN",
    "RecordCreatedAt": "2026-08-05T06:56:43.663Z",
    "RecordModifiedAt": "2026-08-05T07:27:43.839Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785914863657845800"
  },
  {
    "InventoryFlightId": "AC-8007-2026-11-15",
    "Id": "2026-11-15-YHZ-LHR",
    "BoardInventoryPlaceId": "YHZ_2",
    "OffInventoryPlaceId": "LHR_3",
    "BoardPlaceIATACode": "YHZ",
    "OffPlaceIATACode": "LHR",
    "LocalDepartureScheduleAt": "2026-11-15T17:35:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-16T02:05:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-16T03:30:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-16T08:00:00.000Z",
    "LegCount": 1,
    "TrafficRestrictions": null,
    "RecordCorrelationId": "01KZ8D4C6ZYH8FWK82XZSPM5BN",
    "RecordCreatedAt": "2026-08-05T06:56:43.663Z",
    "RecordModifiedAt": "2026-08-05T07:27:43.839Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785914863657845800"
  }
]
```

### Query 2: InventoryFlightLeg
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8007-2026-11-15"]
**Row Count:** 2
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8007-2026-11-15",
    "Id": "YYZ-YHZ",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8007",
    "OperatingNumber": "8007",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YHZ_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YHZ",
    "LocalDepartureScheduleAt": "2026-11-15T13:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-15T23:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-15T16:39:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-16T01:09:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "7M8",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 169,
    "ScheduledFittedAircraftConfigurationCode": "7M1",
    "ScheduledFittedBusinessSeatCapacity": 16,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 153,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 16,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 153,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 16,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 153,
    "OperationalFittedAircraftConfigurationCode": "7M1",
    "OperationalFittedBusinessSeatCapacity": 16,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 153,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T06:56:43.663Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T06:56:43.663Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T06:56:43.663Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T06:56:43.663Z",
    "RecordCorrelationId": "01KZ8D4C6ZYH8FWK82XZSPM5BN",
    "RecordCreatedAt": "2026-08-05T06:56:43.663Z",
    "RecordModifiedAt": "2026-08-05T07:27:43.839Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785914863657845800"
  },
  {
    "InventoryFlightId": "AC-8007-2026-11-15",
    "Id": "YHZ-LHR",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8007",
    "OperatingNumber": "8007",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YHZ_2",
    "OffInventoryPlaceId": "LHR_3",
    "BoardPlaceIATACode": "YHZ",
    "OffPlaceIATACode": "LHR",
    "LocalDepartureScheduleAt": "2026-11-15T17:35:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-16T02:05:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-16T03:30:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-16T08:00:00.000Z",
    "SequenceNumber": 2,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "7M8",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 169,
    "ScheduledFittedAircraftConfigurationCode": "7M1",
    "ScheduledFittedBusinessSeatCapacity": 16,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 153,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 16,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 153,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 16,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 153,
    "OperationalFittedAircraftConfigurationCode": "7M1",
    "OperationalFittedBusinessSeatCapacity": 16,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 153,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T06:56:43.663Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T06:56:43.663Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T06:56:43.663Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T06:56:43.663Z",
    "RecordCorrelationId": "01KZ8D4C6ZYH8FWK82XZSPM5BN",
    "RecordCreatedAt": "2026-08-05T06:56:43.663Z",
    "RecordModifiedAt": "2026-08-05T07:27:43.839Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785914863657845800"
  }
]
```

## Assertions

✅ **Lambda success**: ✅ PASS
✅ **3 segments created (YYZ-YHZ, YYZ-LHR through, YHZ-LHR)**: ✅ PASS
✅ **2 legs created**: ✅ PASS

---
## Final Verdict: ✅ PASSED