# TC-56 - Validate StatusModifiedAt timestamps update only for changed statuses

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T10:13:53.827Z
**Result:** ✅ PASSED
**Duration:** 10369ms

## Test Description
First event: all 4 DCS statuses set. Second event: only acceptanceStatus changes (OPEN→CLOSED). Verify FlightAcceptanceStatusModifiedAt updates, others remain unchanged in InventoryFlightLeg. Also check UTCFlightAcceptanceStatusModifiedAt in FlightState.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785924829728-wyzda7lus"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8056-2026-11-19",
    "version": "5000000002",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8056"
    },
    "scheduledDepartureDate": "2026-11-19",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-19T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YUL_2",
        "iataCode": "YUL",
        "city": "YUL",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-19T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-19-YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-19T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-19T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-19T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-19T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YUL"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-19T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-19T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-19T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-19T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "CLOSED",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8056-2026-11-19",
    "originFeedTimeStamp": "2026-08-05T10:13:54.728Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "UPDATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2454 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T10:13:49.729Z

## Database Verification

### Query 1: InventoryFlightLeg after 1st event (all statuses set)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8056-2026-11-19"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8056-2026-11-19",
    "Id": "YYZ-YUL",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8056",
    "OperatingNumber": "8056",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YUL_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YUL",
    "LocalDepartureScheduleAt": "2026-11-19T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-19T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-19T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-19T14:30:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "320",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 170,
    "ScheduledFittedAircraftConfigurationCode": "321",
    "ScheduledFittedBusinessSeatCapacity": 14,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 156,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 14,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 156,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 14,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 156,
    "OperationalFittedAircraftConfigurationCode": "321",
    "OperationalFittedBusinessSeatCapacity": 14,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 156,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T10:13:45.915Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T10:13:45.915Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T10:13:45.915Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T10:13:45.915Z",
    "RecordCorrelationId": "01KZ8PMCSV3XB4JS4NQ275K2R8",
    "RecordCreatedAt": "2026-08-05T10:13:45.915Z",
    "RecordModifiedAt": "2026-08-05T10:13:45.915Z",
    "RecordExpiredAt": null,
    "RecordVersion": "5000000001"
  }
]
```

### Query 2: FlightState after 1st event
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT 
      "OperatingCarrierCode",
      "OperatingFlightNumber",
      "DepartureAirportIATACode",
      "ArrivalAirportIATACode",
      "LocalDepartureScheduledDate",
      "CurrentFlightAcceptanceStatusCode",
      "CurrentFlightGeneralStatusCode",
      "CurrentFlightLoadControlStatusCode",
      "CurrentFlightBoardingStatusCode",
      "PreviousFlightAcceptanceStatusCode",
      "PreviousFlightGeneralStatusCode",
      "PreviousFlightLoadControlStatusCode",
      "PreviousFlightBoardingStatusCode",
      "UTCFlightAcceptanceStatusModifiedAt",
      "UTCFlightGeneralStatusModifiedAt",
      "UTCFlightLoadControlStatusModifiedAt",
      "UTCFlightBoardingStatusModifiedAt",
      "RecordCreatedAt",
      "RecordModifiedAt",
      "RecordVersion",
      "SourceCreatedBy"
    FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8056","YYZ","2026-11-19"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8056",
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YUL",
    "LocalDepartureScheduledDate": "2026-11-18T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T10:13:45.915Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T10:13:45.915Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T10:13:45.915Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T10:13:45.915Z",
    "RecordCreatedAt": "2026-08-05T10:13:45.915Z",
    "RecordModifiedAt": "2026-08-05T10:13:45.915Z",
    "RecordVersion": "5000000001",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

### Query 3: InventoryFlightLeg after 2nd event (only acceptance changed)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8056-2026-11-19"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8056-2026-11-19",
    "Id": "YYZ-YUL",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8056",
    "OperatingNumber": "8056",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YUL_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YUL",
    "LocalDepartureScheduleAt": "2026-11-19T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-19T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-19T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-19T14:30:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "320",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 170,
    "ScheduledFittedAircraftConfigurationCode": "321",
    "ScheduledFittedBusinessSeatCapacity": 14,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 156,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 14,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 156,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 14,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 156,
    "OperationalFittedAircraftConfigurationCode": "321",
    "OperationalFittedBusinessSeatCapacity": 14,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 156,
    "CurrentFlightAcceptanceStatusCode": "CLOSED",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": "OPEN",
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T10:13:49.913Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T10:13:45.915Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T10:13:45.915Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T10:13:45.915Z",
    "RecordCorrelationId": "01KZ8PMGPSA5PS91WK32AW53MS",
    "RecordCreatedAt": "2026-08-05T10:13:45.915Z",
    "RecordModifiedAt": "2026-08-05T10:13:49.913Z",
    "RecordExpiredAt": null,
    "RecordVersion": "5000000002"
  }
]
```

### Query 4: FlightState after 2nd event
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT 
      "OperatingCarrierCode",
      "OperatingFlightNumber",
      "DepartureAirportIATACode",
      "ArrivalAirportIATACode",
      "LocalDepartureScheduledDate",
      "CurrentFlightAcceptanceStatusCode",
      "CurrentFlightGeneralStatusCode",
      "CurrentFlightLoadControlStatusCode",
      "CurrentFlightBoardingStatusCode",
      "PreviousFlightAcceptanceStatusCode",
      "PreviousFlightGeneralStatusCode",
      "PreviousFlightLoadControlStatusCode",
      "PreviousFlightBoardingStatusCode",
      "UTCFlightAcceptanceStatusModifiedAt",
      "UTCFlightGeneralStatusModifiedAt",
      "UTCFlightLoadControlStatusModifiedAt",
      "UTCFlightBoardingStatusModifiedAt",
      "RecordCreatedAt",
      "RecordModifiedAt",
      "RecordVersion",
      "SourceCreatedBy"
    FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8056","YYZ","2026-11-19"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8056",
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YUL",
    "LocalDepartureScheduledDate": "2026-11-18T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "CLOSED",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": "OPEN",
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T10:13:49.913Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T10:13:45.915Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T10:13:45.915Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T10:13:45.915Z",
    "RecordCreatedAt": "2026-08-05T10:13:45.915Z",
    "RecordModifiedAt": "2026-08-05T10:13:49.913Z",
    "RecordVersion": "5000000002",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

## Assertions

✅ **Lambda success**: ✅ PASS
✅ **InventoryFlightLeg: FlightAcceptanceStatusModifiedAt updated**: ✅ PASS
✅ **InventoryFlightLeg: FlightGeneralStatusModifiedAt unchanged**: ✅ PASS
✅ **InventoryFlightLeg: FlightBoardingStatusModifiedAt unchanged**: ✅ PASS
✅ **InventoryFlightLeg: CurrentFlightAcceptanceStatusCode=CLOSED after 2nd event**: ✅ PASS
✅ **FlightState: UTCFlightAcceptanceStatusModifiedAt updated**: ✅ PASS
✅ **FlightState: UTCFlightGeneralStatusModifiedAt unchanged**: ✅ PASS

---
## Final Verdict: ✅ PASSED