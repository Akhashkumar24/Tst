# TC-34 - Validate handling of missing/null optional source fields

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T09:58:23.038Z
**Result:** ✅ PASSED
**Duration:** 7218ms

## Test Description
Ingest with operationalSuffix=null, no terminals, no trafficRestrictions. Verify ingestion succeeds. InventoryFlight.OperationalSuffix=NULL, InventoryFlightPlace.Terminals=NULL or empty.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785923898203-c2hstbzcl"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8034-2026-11-18",
    "version": "1785923898203545555",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8034"
    },
    "scheduledDepartureDate": "2026-11-18",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-18T08:00:00"
            }
          ]
        }
      },
      {
        "id": "YUL_2",
        "iataCode": "YUL",
        "city": "YUL",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-18T10:30:00"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-18-YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-18T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-18T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-18T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-18T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YUL"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-18T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-18T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-18T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-18T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8034-2026-11-18",
    "originFeedTimeStamp": "2026-08-05T09:58:18.203Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2407 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T09:58:18.203Z

## Database Verification

### Query 1: InventoryFlight (optional nulls)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8034-2026-11-18"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8034-2026-11-18",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8034",
    "OperatingNumber": "8034",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-17T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8NR3171BMCG199S84R37QH",
    "RecordCreatedAt": "2026-08-05T09:58:18.407Z",
    "RecordModifiedAt": "2026-08-05T09:58:18.407Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785923898203545600"
  }
]
```

### Query 2: InventoryFlightPlace (Terminals should be null/empty)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightPlace" WHERE "InventoryFlightId" = $1
```
**Parameters:** ["AC-8034-2026-11-18"]
**Row Count:** 2
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8034-2026-11-18",
    "InventoryPlaceId": "YYZ_1",
    "PlaceIATACode": "YYZ",
    "PlaceCityCode": "YYZ",
    "CountryCode": "CA",
    "InventoryPlaceRegionCode": "NAMER",
    "InventoryPlaceContinentCode": "ITC1",
    "LocalScheduledDepartureAt": "2026-11-18T02:30:00.000Z",
    "LocalScheduledArrivalAt": null,
    "LocalEstimatedOffBlockAt": null,
    "LocalEstimatedTakeOffAt": null,
    "LocalEstimatedTouchdownAt": null,
    "LocalEstimatedOnBlockAt": null,
    "LocalActualOffBlockAt": null,
    "LocalActualTakeOffAt": null,
    "LocalActualTouchdownAt": null,
    "LocalActualOnBlockAt": null,
    "Terminals": null,
    "RecordCorrelationId": "01KZ8NR3171BMCG199S84R37QH",
    "RecordCreatedAt": "2026-08-05T09:58:18.407Z",
    "RecordModifiedAt": "2026-08-05T09:58:18.407Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785923898203545600"
  },
  {
    "InventoryFlightId": "AC-8034-2026-11-18",
    "InventoryPlaceId": "YUL_2",
    "PlaceIATACode": "YUL",
    "PlaceCityCode": "YUL",
    "CountryCode": "CA",
    "InventoryPlaceRegionCode": "NAMER",
    "InventoryPlaceContinentCode": "ITC1",
    "LocalScheduledDepartureAt": null,
    "LocalScheduledArrivalAt": "2026-11-18T05:00:00.000Z",
    "LocalEstimatedOffBlockAt": null,
    "LocalEstimatedTakeOffAt": null,
    "LocalEstimatedTouchdownAt": null,
    "LocalEstimatedOnBlockAt": null,
    "LocalActualOffBlockAt": null,
    "LocalActualTakeOffAt": null,
    "LocalActualTouchdownAt": null,
    "LocalActualOnBlockAt": null,
    "Terminals": null,
    "RecordCorrelationId": "01KZ8NR3171BMCG199S84R37QH",
    "RecordCreatedAt": "2026-08-05T09:58:18.407Z",
    "RecordModifiedAt": "2026-08-05T09:58:18.407Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785923898203545600"
  }
]
```

### Query 3: InventoryFlightLeg (OperationalSuffix should be null)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8034-2026-11-18"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8034-2026-11-18",
    "Id": "YYZ-YUL",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8034",
    "OperatingNumber": "8034",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YUL_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YUL",
    "LocalDepartureScheduleAt": "2026-11-18T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-18T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-18T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-18T14:30:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "320",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 170,
    "ScheduledFittedAircraftConfigurationCode": "321",
    "ScheduledFittedBusinessSeatCapacity": 14,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 156,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 14,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 156,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 14,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 156,
    "OperationalFittedAircraftConfigurationCode": "321",
    "OperationalFittedBusinessSeatCapacity": 14,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 156,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T09:58:18.407Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T09:58:18.407Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T09:58:18.407Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T09:58:18.407Z",
    "RecordCorrelationId": "01KZ8NR3171BMCG199S84R37QH",
    "RecordCreatedAt": "2026-08-05T09:58:18.407Z",
    "RecordModifiedAt": "2026-08-05T09:58:18.407Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785923898203545600"
  }
]
```

### Query 4: FlightState (OperationalSuffix should be null)
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8034","YYZ","2026-11-18"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8034",
    "OperationalSuffix": null,
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YUL",
    "LocalDepartureScheduledDate": "2026-11-17T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T09:58:18.407Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T09:58:18.407Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T09:58:18.407Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T09:58:18.407Z",
    "CurrentBagFlightLoadStatusCode": null,
    "PreviousBagFlightLoadStatusCode": null,
    "UTCBagFlightLoadStatusModifiedAt": null,
    "RecordCorrelationId": "01KZ8NR3171BMCG199S84R37QH",
    "RecordCreatedAt": "2026-08-05T09:58:18.407Z",
    "RecordModifiedAt": "2026-08-05T09:58:18.407Z",
    "RecordExpiredAt": "2027-08-05T09:58:18.407Z",
    "RecordVersion": "1785923898203545600",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

## Assertions

✅ **Lambda success (no crash on missing optionals)**: ✅ PASS
✅ **No Lambda functionError**: ✅ PASS
✅ **InventoryFlight persisted with null optionals**: ✅ PASS
✅ **InventoryFlightPlace records exist**: ✅ PASS
✅ **InventoryFlight.OperationalSuffix is null (as expected)**: ✅ PASS
✅ **InventoryFlightPlace.Terminals is null (terminals removed)**: ✅ PASS
✅ **FlightState.OperationalSuffix is null**: ✅ PASS

---
## Final Verdict: ✅ PASSED