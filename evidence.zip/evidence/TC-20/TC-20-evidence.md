# TC-20 - Verify concurrent/near-simultaneous events handled without lost updates

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T07:56:39.401Z
**Result:** ✅ PASSED
**Duration:** 18027ms

## Test Description
Send two events in rapid succession for same flight: Event A (gate change), Event B (status change). Verify no duplicate records and final state reflects latest version.

## Payload Sent to Lambda
```json
{
  "eventA": {
    "meta": {
      "triggerEventLog": {
        "id": "tc-1785916592199-dj3z4xyjr"
      },
      "version": "1.3.0"
    },
    "scheduleProcessedFlight": {
      "type": "dated-flight",
      "id": "AC-8020-2026-11-17",
      "version": "1000000002",
      "flightDesignator": {
        "carrierCode": "AC",
        "flightNumber": "8020"
      },
      "scheduledDepartureDate": "2026-11-17",
      "dayOfOperation": "WED",
      "isCancelled": false,
      "characteristics": [
        "DOMESTIC"
      ],
      "codeshare": "OPERATING",
      "flightPoints": [
        {
          "id": "YYZ_1",
          "iataCode": "YYZ",
          "city": "YYZ",
          "country": "CA",
          "region": "NAMER",
          "continent": "ITC1",
          "departure": {
            "timings": [
              {
                "qualifier": "STD",
                "value": "2026-11-17T08:00:00"
              }
            ],
            "terminals": [
              {
                "code": "5"
              }
            ]
          }
        },
        {
          "id": "YUL_2",
          "iataCode": "YUL",
          "city": "YUL",
          "country": "CA",
          "region": "NAMER",
          "continent": "ITC1",
          "arrival": {
            "timings": [
              {
                "qualifier": "STA",
                "value": "2026-11-17T10:30:00"
              }
            ],
            "terminals": [
              {
                "code": "1"
              }
            ]
          }
        }
      ],
      "segments": [
        {
          "id": "2026-11-17-YYZ-YUL",
          "boardFlightPointId": "YYZ_1",
          "offFlightPointId": "YUL_2",
          "boardPointIataCode": "YYZ",
          "offPointIataCode": "YUL",
          "scheduledDepartureDateTime": "2026-11-17T08:00:00",
          "scheduledDepartureDateTimeUtc": "2026-11-17T12:00:00Z",
          "scheduledArrivalDateTime": "2026-11-17T10:30:00",
          "scheduledArrivalDateTimeUtc": "2026-11-17T14:30:00Z",
          "numberOfLegs": 1,
          "legIds": [
            "YYZ-YUL"
          ]
        }
      ],
      "legs": [
        {
          "id": "YYZ-YUL",
          "boardFlightPointId": "YYZ_1",
          "offFlightPointId": "YUL_2",
          "boardPointIataCode": "YYZ",
          "offPointIataCode": "YUL",
          "scheduledDepartureDateTime": "2026-11-17T08:00:00",
          "scheduledDepartureDateTimeUtc": "2026-11-17T12:00:00Z",
          "scheduledArrivalDateTime": "2026-11-17T10:30:00",
          "scheduledArrivalDateTimeUtc": "2026-11-17T14:30:00Z",
          "routingOrder": 1,
          "serviceType": "J",
          "aircraftEquipment": {
            "aircraftType": "320",
            "scheduledFittedConfiguration": {
              "code": "321",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            },
            "acvTotalCapacity": 170,
            "operationalSaleableConfiguration": {
              "code": "001",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            },
            "scheduledSaleableConfiguration": {
              "code": "001",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            },
            "operationalFittedConfiguration": {
              "code": "321",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            }
          },
          "legDCSStatuses": {
            "acceptanceStatus": "OPEN",
            "generalStatus": "OPEN",
            "loadControlStatus": "OPEN",
            "boardingStatus": "NOT_OPEN"
          }
        }
      ]
    },
    "events": {
      "recordDomain": "SCHEDULE",
      "recordId": "AC-8020-2026-11-17",
      "originFeedTimeStamp": "2026-08-05T07:56:33.199Z",
      "events": [
        {
          "origin": "COMPARISON",
          "eventType": "UPDATED"
        }
      ]
    }
  },
  "eventB": {
    "meta": {
      "triggerEventLog": {
        "id": "tc-1785916592199-f1bvmkj1g"
      },
      "version": "1.3.0"
    },
    "scheduleProcessedFlight": {
      "type": "dated-flight",
      "id": "AC-8020-2026-11-17",
      "version": "1000000003",
      "flightDesignator": {
        "carrierCode": "AC",
        "flightNumber": "8020"
      },
      "scheduledDepartureDate": "2026-11-17",
      "dayOfOperation": "WED",
      "isCancelled": false,
      "characteristics": [
        "DOMESTIC"
      ],
      "codeshare": "OPERATING",
      "flightPoints": [
        {
          "id": "YYZ_1",
          "iataCode": "YYZ",
          "city": "YYZ",
          "country": "CA",
          "region": "NAMER",
          "continent": "ITC1",
          "departure": {
            "timings": [
              {
                "qualifier": "STD",
                "value": "2026-11-17T08:00:00"
              }
            ],
            "terminals": [
              {
                "code": "5"
              }
            ]
          }
        },
        {
          "id": "YUL_2",
          "iataCode": "YUL",
          "city": "YUL",
          "country": "CA",
          "region": "NAMER",
          "continent": "ITC1",
          "arrival": {
            "timings": [
              {
                "qualifier": "STA",
                "value": "2026-11-17T10:30:00"
              }
            ],
            "terminals": [
              {
                "code": "1"
              }
            ]
          }
        }
      ],
      "segments": [
        {
          "id": "2026-11-17-YYZ-YUL",
          "boardFlightPointId": "YYZ_1",
          "offFlightPointId": "YUL_2",
          "boardPointIataCode": "YYZ",
          "offPointIataCode": "YUL",
          "scheduledDepartureDateTime": "2026-11-17T08:00:00",
          "scheduledDepartureDateTimeUtc": "2026-11-17T12:00:00Z",
          "scheduledArrivalDateTime": "2026-11-17T10:30:00",
          "scheduledArrivalDateTimeUtc": "2026-11-17T14:30:00Z",
          "numberOfLegs": 1,
          "legIds": [
            "YYZ-YUL"
          ]
        }
      ],
      "legs": [
        {
          "id": "YYZ-YUL",
          "boardFlightPointId": "YYZ_1",
          "offFlightPointId": "YUL_2",
          "boardPointIataCode": "YYZ",
          "offPointIataCode": "YUL",
          "scheduledDepartureDateTime": "2026-11-17T08:00:00",
          "scheduledDepartureDateTimeUtc": "2026-11-17T12:00:00Z",
          "scheduledArrivalDateTime": "2026-11-17T10:30:00",
          "scheduledArrivalDateTimeUtc": "2026-11-17T14:30:00Z",
          "routingOrder": 1,
          "serviceType": "J",
          "aircraftEquipment": {
            "aircraftType": "320",
            "scheduledFittedConfiguration": {
              "code": "321",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            },
            "acvTotalCapacity": 170,
            "operationalSaleableConfiguration": {
              "code": "001",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            },
            "scheduledSaleableConfiguration": {
              "code": "001",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            },
            "operationalFittedConfiguration": {
              "code": "321",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            }
          },
          "legDCSStatuses": {
            "acceptanceStatus": "CLOSED",
            "generalStatus": "OPEN",
            "loadControlStatus": "OPEN",
            "boardingStatus": "NOT_OPEN"
          }
        }
      ]
    },
    "events": {
      "recordDomain": "SCHEDULE",
      "recordId": "AC-8020-2026-11-17",
      "originFeedTimeStamp": "2026-08-05T07:56:34.199Z",
      "events": [
        {
          "origin": "COMPARISON",
          "eventType": "UPDATED"
        }
      ]
    }
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 4927 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** N/A
- **Function Error:** None
- **Invoked At:** N/A

## Database Verification

### Query 1: InventoryFlight after concurrent updates
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8020-2026-11-17"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8020-2026-11-17",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8020",
    "OperatingNumber": "8020",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-16T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8ES4SX7VXZB6N2HYJQPRV9",
    "RecordCreatedAt": "2026-08-05T07:56:28.177Z",
    "RecordModifiedAt": "2026-08-05T07:56:32.957Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1000000003"
  }
]
```

### Query 2: InventoryFlightLeg after concurrent updates
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8020-2026-11-17"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8020-2026-11-17",
    "Id": "YYZ-YUL",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8020",
    "OperatingNumber": "8020",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YUL_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YUL",
    "LocalDepartureScheduleAt": "2026-11-17T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-17T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-17T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-17T14:30:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "320",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 170,
    "ScheduledFittedAircraftConfigurationCode": "321",
    "ScheduledFittedBusinessSeatCapacity": 14,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 156,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 14,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 156,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 14,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 156,
    "OperationalFittedAircraftConfigurationCode": "321",
    "OperationalFittedBusinessSeatCapacity": 14,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 156,
    "CurrentFlightAcceptanceStatusCode": "CLOSED",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": "OPEN",
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T07:56:32.957Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T07:56:28.177Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T07:56:28.177Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T07:56:28.177Z",
    "RecordCorrelationId": "01KZ8ES4SX7VXZB6N2HYJQPRV9",
    "RecordCreatedAt": "2026-08-05T07:56:28.177Z",
    "RecordModifiedAt": "2026-08-05T07:56:32.957Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1000000003"
  }
]
```

### Query 3: Row counts (no duplicates check)
**Database:** CustomerDataMart
**SQL:**
```sql

    SELECT 
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1)::int AS flight_count,
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1)::int AS leg_count,
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlightSegment" WHERE "InventoryFlightId" = $1)::int AS segment_count,
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlightPlace" WHERE "InventoryFlightId" = $1)::int AS place_count,
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlightSegmentAlias" WHERE "InventoryFlightId" = $1)::int AS alias_count
  
```
**Parameters:** ["AC-8020-2026-11-17"]
**Row Count:** 1
**Results:**
```json
[
  {
    "flight_count": 1,
    "leg_count": 1,
    "segment_count": 1,
    "place_count": 2,
    "alias_count": 0
  }
]
```

### Query 4: FlightState after concurrent updates
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT 
      "OperatingCarrierCode",
      "OperatingFlightNumber",
      "DepartureAirportIATACode",
      "ArrivalAirportIATACode",
      "LocalDepartureScheduledDate",
      "CurrentFlightAcceptanceStatusCode",
      "CurrentFlightGeneralStatusCode",
      "CurrentFlightLoadControlStatusCode",
      "CurrentFlightBoardingStatusCode",
      "PreviousFlightAcceptanceStatusCode",
      "PreviousFlightGeneralStatusCode",
      "PreviousFlightLoadControlStatusCode",
      "PreviousFlightBoardingStatusCode",
      "UTCFlightAcceptanceStatusModifiedAt",
      "UTCFlightGeneralStatusModifiedAt",
      "UTCFlightLoadControlStatusModifiedAt",
      "UTCFlightBoardingStatusModifiedAt",
      "RecordCreatedAt",
      "RecordModifiedAt",
      "RecordVersion",
      "SourceCreatedBy"
    FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8020","YYZ","2026-11-17"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8020",
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YUL",
    "LocalDepartureScheduledDate": "2026-11-16T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "CLOSED",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": "OPEN",
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T07:56:32.957Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T07:56:28.177Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T07:56:28.177Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T07:56:28.177Z",
    "RecordCreatedAt": "2026-08-05T07:56:28.177Z",
    "RecordModifiedAt": "2026-08-05T07:56:32.957Z",
    "RecordVersion": "1000000003",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

## Assertions

✅ **Both Lambdas returned 200**: ✅ PASS
✅ **Exactly 1 InventoryFlight record (no dup)**: ✅ PASS
✅ **Exactly 1 leg record (no dup)**: ✅ PASS
✅ **Exactly 1 segment record (no dup)**: ✅ PASS
✅ **RecordVersion reflects latest event**: ✅ PASS
✅ **Exactly 1 FlightState record**: ✅ PASS

---
## Final Verdict: ✅ PASSED