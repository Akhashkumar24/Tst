# TC-27 - Verify a malformed/poison SKD payload does not block processing of subsequent valid events

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T16:00:01.791Z
**Result:** ✅ PASSED
**Duration:** 12420ms

## Test Description
Send a structurally invalid (poison) payload, then immediately send a valid event for a different flight. Verify: Lambda does not crash on poison, valid event is persisted correctly, no processing backlog.

## Payload Sent to Lambda
```json
{
  "poison": {
    "meta": {
      "triggerEventLog": {
        "id": "tc-poison-8027"
      },
      "version": "1.3.0"
    },
    "scheduleProcessedFlight": null,
    "events": null
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 126 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** N/A
- **Function Error:** None
- **Invoked At:** N/A

## Database Verification

### Query 1: InventoryFlight for valid event (should exist)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8027-2026-11-21"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8027-2026-11-21",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8027",
    "OperatingNumber": "8027",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-20T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ9AE9JVJ9Q4YHQRQRZE7D0W",
    "RecordCreatedAt": "2026-08-05T15:59:57.531Z",
    "RecordModifiedAt": "2026-08-05T15:59:57.531Z",
    "RecordExpiredAt": null,
    "RecordVersion": "270001"
  }
]
```

### Query 2: InventoryFlightLeg for valid event
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8027-2026-11-21"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8027-2026-11-21",
    "Id": "YYZ-YUL",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8027",
    "OperatingNumber": "8027",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YUL_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YUL",
    "LocalDepartureScheduleAt": "2026-11-21T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-21T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-21T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-21T14:30:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "320",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 170,
    "ScheduledFittedAircraftConfigurationCode": "321",
    "ScheduledFittedBusinessSeatCapacity": 14,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 156,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 14,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 156,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 14,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 156,
    "OperationalFittedAircraftConfigurationCode": "321",
    "OperationalFittedBusinessSeatCapacity": 14,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 156,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T15:59:57.531Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T15:59:57.531Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T15:59:57.531Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T15:59:57.531Z",
    "RecordCorrelationId": "01KZ9AE9JVJ9Q4YHQRQRZE7D0W",
    "RecordCreatedAt": "2026-08-05T15:59:57.531Z",
    "RecordModifiedAt": "2026-08-05T15:59:57.531Z",
    "RecordExpiredAt": null,
    "RecordVersion": "270001"
  }
]
```

### Query 3: FlightState for valid event
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8027","YYZ","2026-11-21"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8027",
    "OperationalSuffix": null,
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YUL",
    "LocalDepartureScheduledDate": "2026-11-20T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T15:59:57.531Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T15:59:57.531Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T15:59:57.531Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T15:59:57.531Z",
    "CurrentBagFlightLoadStatusCode": null,
    "PreviousBagFlightLoadStatusCode": null,
    "UTCBagFlightLoadStatusModifiedAt": null,
    "RecordCorrelationId": "01KZ9AE9JVJ9Q4YHQRQRZE7D0W",
    "RecordCreatedAt": "2026-08-05T15:59:57.531Z",
    "RecordModifiedAt": "2026-08-05T15:59:57.531Z",
    "RecordExpiredAt": "2027-08-05T15:59:57.531Z",
    "RecordVersion": "270001",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

## Assertions

✅ **Poison payload: Lambda returned 200 (no crash)**: ✅ PASS
✅ **Poison payload: No Lambda functionError (handled gracefully)**: ✅ PASS
✅ **Valid event: Lambda returned 200**: ✅ PASS
✅ **Valid event: InventoryFlight persisted (poison did not block)**: ✅ PASS
✅ **Valid event: InventoryFlightLeg persisted**: ✅ PASS
✅ **Valid event: FlightState persisted**: ✅ PASS
✅ **Valid event: MarketingCarrierCode=AC**: ✅ PASS
✅ **Valid event: MarketingNumber=8027**: ✅ PASS

---
## Final Verdict: ✅ PASSED