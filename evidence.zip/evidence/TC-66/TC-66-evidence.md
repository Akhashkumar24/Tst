# TC-66 - Validate flight cancellation handling — writer behavior for legless payload

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T10:36:39.582Z
**Result:** ✅ PASSED
**Duration:** 15440ms

## Test Description
Ingest active flight, then send cancellation payload (isCancelled=true, no legs/flightPoints/segments). Document whether writer updates IsCancelled or ignores legless payloads.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785926195205-rm9b74juj"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8066-2026-11-20",
    "version": "100066002",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8066"
    },
    "scheduledDepartureDate": "2026-11-20",
    "dayOfOperation": "WED",
    "isCancelled": true,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "OPERATING"
  },
  "previousRecord": [
    {
      "op": "replace",
      "path": "/isCancelled",
      "value": false
    },
    {
      "op": "replace",
      "path": "/version",
      "value": "100066001"
    }
  ],
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8066-2026-11-20",
    "originFeedTimeStamp": "2026-08-05T10:36:40.205Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "UPDATED",
        "currentPath": "/isCancelled",
        "previousPath": "/isCancelled"
      },
      {
        "origin": "COMPARISON",
        "eventType": "DELETED",
        "previousPath": "/legs"
      },
      {
        "origin": "COMPARISON",
        "eventType": "DELETED",
        "previousPath": "/flightPoints"
      },
      {
        "origin": "COMPARISON",
        "eventType": "UPDATED",
        "currentPath": "/version",
        "previousPath": "/version"
      },
      {
        "origin": "COMPARISON",
        "eventType": "UPDATED"
      },
      {
        "origin": "COMPARISON",
        "eventType": "DELETED",
        "previousPath": "/segments"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 1100 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T10:36:35.206Z

## Database Verification

### Query 1: InventoryFlight before cancellation (IsCancelled=false)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8066-2026-11-20"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8066-2026-11-20",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8066",
    "OperatingNumber": "8066",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-19T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8QY1RP98GY3PCZ97CKS7SA",
    "RecordCreatedAt": "2026-08-05T10:36:30.871Z",
    "RecordModifiedAt": "2026-08-05T10:36:30.871Z",
    "RecordExpiredAt": null,
    "RecordVersion": "100066001"
  }
]
```

### Query 2: InventoryFlight after cancellation payload
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8066-2026-11-20"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8066-2026-11-20",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8066",
    "OperatingNumber": "8066",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-19T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": true,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8QY6837V3AEGK33077B0BX",
    "RecordCreatedAt": "2026-08-05T10:36:30.871Z",
    "RecordModifiedAt": "2026-08-05T10:36:35.459Z",
    "RecordExpiredAt": null,
    "RecordVersion": "100066002"
  }
]
```

### Query 3: FlightState after cancellation payload
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8066","YUL","2026-11-20"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8066",
    "OperationalSuffix": null,
    "DepartureAirportIATACode": "YUL",
    "ArrivalAirportIATACode": "YYZ",
    "LocalDepartureScheduledDate": "2026-11-19T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T10:36:30.871Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T10:36:30.871Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T10:36:30.871Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T10:36:30.871Z",
    "CurrentBagFlightLoadStatusCode": null,
    "PreviousBagFlightLoadStatusCode": null,
    "UTCBagFlightLoadStatusModifiedAt": null,
    "RecordCorrelationId": "01KZ8QY1RP98GY3PCZ97CKS7SA",
    "RecordCreatedAt": "2026-08-05T10:36:30.871Z",
    "RecordModifiedAt": "2026-08-05T10:36:30.871Z",
    "RecordExpiredAt": "2027-08-05T10:36:30.871Z",
    "RecordVersion": "100066001",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

### Query 4: InventoryFlightLeg after cancellation (should be deleted or preserved)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8066-2026-11-20"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8066-2026-11-20",
    "Id": "YUL-YYZ",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8066",
    "OperatingNumber": "8066",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YUL_1",
    "OffInventoryPlaceId": "YYZ_2",
    "BoardPlaceIATACode": "YUL",
    "OffPlaceIATACode": "YYZ",
    "LocalDepartureScheduleAt": "2026-11-20T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-20T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-20T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-20T14:30:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "320",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 170,
    "ScheduledFittedAircraftConfigurationCode": "321",
    "ScheduledFittedBusinessSeatCapacity": 14,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 156,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 14,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 156,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 14,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 156,
    "OperationalFittedAircraftConfigurationCode": "321",
    "OperationalFittedBusinessSeatCapacity": 14,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 156,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T10:36:30.871Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T10:36:30.871Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T10:36:30.871Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T10:36:30.871Z",
    "RecordCorrelationId": "01KZ8QY1RP98GY3PCZ97CKS7SA",
    "RecordCreatedAt": "2026-08-05T10:36:30.871Z",
    "RecordModifiedAt": "2026-08-05T10:36:30.871Z",
    "RecordExpiredAt": null,
    "RecordVersion": "100066001"
  }
]
```

## Assertions

✅ **Lambda returned 200 (no crash)**: ✅ PASS
✅ **No Lambda functionError**: ✅ PASS
✅ **IsCancelled=true (cancellation processed)**: ✅ PASS
✅ **RecordVersion updated**: ✅ PASS

---
## Final Verdict: ✅ PASSED