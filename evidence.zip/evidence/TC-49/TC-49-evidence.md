# TC-49 - Validate codeshare enum derives IsOperatingCodeshare/IsMarketingCodeshare flags

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T10:12:58.719Z
**Result:** ✅ PASSED
**Duration:** 9586ms

## Test Description
codeshare=OPERATING → IsOperatingCodeshare=true, IsMarketingCodeshare=false. codeshare=MARKETING → IsOperatingCodeshare=false, IsMarketingCodeshare=true.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785924775884-vr2ndtcjj"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8149-2026-11-19",
    "version": "1785924775884400851",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8149"
    },
    "scheduledDepartureDate": "2026-11-19",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "MARKETING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-19T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YUL_2",
        "iataCode": "YUL",
        "city": "YUL",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-19T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-19-YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-19T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-19T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-19T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-19T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YUL"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-19T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-19T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-19T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-19T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8149-2026-11-19",
    "originFeedTimeStamp": "2026-08-05T10:12:55.884Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2461 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T10:12:55.885Z

## Database Verification

### Query 1: OPERATING codeshare — InventoryFlight
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8049-2026-11-19"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8049-2026-11-19",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8049",
    "OperatingNumber": "8049",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-18T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8PJSE2D1KS7N44MMX73DMG",
    "RecordCreatedAt": "2026-08-05T10:12:53.314Z",
    "RecordModifiedAt": "2026-08-05T10:12:53.314Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924773106973200"
  }
]
```

### Query 2: MARKETING codeshare — InventoryFlight
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8149-2026-11-19"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8149-2026-11-19",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8149",
    "OperatingNumber": "8149",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-18T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": false,
    "IsMarketingCodeshare": true,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8PJW4EC7V9WJ44BW4RZMJC",
    "RecordCreatedAt": "2026-08-05T10:12:56.079Z",
    "RecordModifiedAt": "2026-08-05T10:12:56.079Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924775884401000"
  }
]
```

## Assertions

✅ **Lambda success**: ✅ PASS
✅ **OPERATING → IsOperatingCodeshare=true**: ✅ PASS
✅ **OPERATING → IsMarketingCodeshare=false**: ✅ PASS
✅ **MARKETING → IsOperatingCodeshare=false**: ✅ PASS
✅ **MARKETING → IsMarketingCodeshare=true**: ✅ PASS

---
## Final Verdict: ✅ PASSED