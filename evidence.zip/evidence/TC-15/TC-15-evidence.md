# TC-15 - Validate parsing of a valid ISO 8601 date-time value

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T07:47:43.620Z
**Result:** ✅ PASSED
**Duration:** 8831ms

## Test Description
Ingest event with STD='2026-11-16T12:40:00'. Verify LocalDepartureScheduleAt in InventoryFlightLeg and LocalScheduledDepartureAt in InventoryFlightPlace are populated correctly.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785916057017-9rnrjmitu"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8015-2026-11-16",
    "version": "1785916057016493507",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8015"
    },
    "scheduledDepartureDate": "2026-11-16",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "INTERNATIONAL"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "GVA_1",
        "iataCode": "GVA",
        "city": "GVA",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-16T12:40:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YUL_2",
        "iataCode": "YUL",
        "city": "YUL",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-16T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-16-GVA-YUL",
        "boardFlightPointId": "GVA_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "GVA",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-16T12:40:00",
        "scheduledDepartureDateTimeUtc": "2026-11-16T10:40:00Z",
        "scheduledArrivalDateTime": "2026-11-16T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "GVA-YUL"
        ]
      }
    ],
    "legs": [
      {
        "id": "GVA-YUL",
        "boardFlightPointId": "GVA_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "GVA",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-16T12:40:00",
        "scheduledDepartureDateTimeUtc": "2026-11-16T10:40:00Z",
        "scheduledArrivalDateTime": "2026-11-16T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8015-2026-11-16",
    "originFeedTimeStamp": "2026-08-05T07:47:37.017Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2466 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T07:47:37.017Z

## Database Verification

### Query 1: InventoryFlightLeg (datetime fields)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8015-2026-11-16"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8015-2026-11-16",
    "Id": "GVA-YUL",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8015",
    "OperatingNumber": "8015",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "GVA_1",
    "OffInventoryPlaceId": "YUL_2",
    "BoardPlaceIATACode": "GVA",
    "OffPlaceIATACode": "YUL",
    "LocalDepartureScheduleAt": "2026-11-16T07:10:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-16T10:40:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-16T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-16T14:30:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "320",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 170,
    "ScheduledFittedAircraftConfigurationCode": "321",
    "ScheduledFittedBusinessSeatCapacity": 14,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 156,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 14,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 156,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 14,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 156,
    "OperationalFittedAircraftConfigurationCode": "321",
    "OperationalFittedBusinessSeatCapacity": 14,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 156,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T07:47:39.191Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T07:47:39.191Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T07:47:39.191Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T07:47:39.191Z",
    "RecordCorrelationId": "01KZ8E8VHP3RX36Y4YJ53AS8R1",
    "RecordCreatedAt": "2026-08-05T07:47:39.191Z",
    "RecordModifiedAt": "2026-08-05T07:47:39.191Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785916057016493600"
  }
]
```

### Query 2: InventoryFlightPlace (LocalScheduledDepartureAt)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightPlace" WHERE "InventoryFlightId" = $1
```
**Parameters:** ["AC-8015-2026-11-16"]
**Row Count:** 2
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8015-2026-11-16",
    "InventoryPlaceId": "GVA_1",
    "PlaceIATACode": "GVA",
    "PlaceCityCode": "GVA",
    "CountryCode": "CA",
    "InventoryPlaceRegionCode": "NAMER",
    "InventoryPlaceContinentCode": "ITC1",
    "LocalScheduledDepartureAt": "2026-11-16T07:10:00.000Z",
    "LocalScheduledArrivalAt": null,
    "LocalEstimatedOffBlockAt": null,
    "LocalEstimatedTakeOffAt": null,
    "LocalEstimatedTouchdownAt": null,
    "LocalEstimatedOnBlockAt": null,
    "LocalActualOffBlockAt": null,
    "LocalActualTakeOffAt": null,
    "LocalActualTouchdownAt": null,
    "LocalActualOnBlockAt": null,
    "Terminals": [
      {
        "code": "1"
      }
    ],
    "RecordCorrelationId": "01KZ8E8VHP3RX36Y4YJ53AS8R1",
    "RecordCreatedAt": "2026-08-05T07:47:39.191Z",
    "RecordModifiedAt": "2026-08-05T07:47:39.191Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785916057016493600"
  },
  {
    "InventoryFlightId": "AC-8015-2026-11-16",
    "InventoryPlaceId": "YUL_2",
    "PlaceIATACode": "YUL",
    "PlaceCityCode": "YUL",
    "CountryCode": "CA",
    "InventoryPlaceRegionCode": "NAMER",
    "InventoryPlaceContinentCode": "ITC1",
    "LocalScheduledDepartureAt": null,
    "LocalScheduledArrivalAt": "2026-11-16T05:00:00.000Z",
    "LocalEstimatedOffBlockAt": null,
    "LocalEstimatedTakeOffAt": null,
    "LocalEstimatedTouchdownAt": null,
    "LocalEstimatedOnBlockAt": null,
    "LocalActualOffBlockAt": null,
    "LocalActualTakeOffAt": null,
    "LocalActualTouchdownAt": null,
    "LocalActualOnBlockAt": null,
    "Terminals": [
      {
        "code": "1"
      }
    ],
    "RecordCorrelationId": "01KZ8E8VHP3RX36Y4YJ53AS8R1",
    "RecordCreatedAt": "2026-08-05T07:47:39.191Z",
    "RecordModifiedAt": "2026-08-05T07:47:39.191Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785916057016493600"
  }
]
```

### Query 3: FlightState
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8015","GVA","2026-11-16"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8015",
    "OperationalSuffix": null,
    "DepartureAirportIATACode": "GVA",
    "ArrivalAirportIATACode": "YUL",
    "LocalDepartureScheduledDate": "2026-11-15T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T07:47:39.191Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T07:47:39.191Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T07:47:39.191Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T07:47:39.191Z",
    "CurrentBagFlightLoadStatusCode": null,
    "PreviousBagFlightLoadStatusCode": null,
    "UTCBagFlightLoadStatusModifiedAt": null,
    "RecordCorrelationId": "01KZ8E8VHP3RX36Y4YJ53AS8R1",
    "RecordCreatedAt": "2026-08-05T07:47:39.191Z",
    "RecordModifiedAt": "2026-08-05T07:47:39.191Z",
    "RecordExpiredAt": "2027-08-05T07:47:39.191Z",
    "RecordVersion": "1785916057016493600",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

## Assertions

✅ **Lambda success**: ✅ PASS
✅ **InventoryFlightLeg created**: ✅ PASS
✅ **FlightState created**: ✅ PASS
✅ **LocalDepartureScheduleAt is populated**: ✅ PASS
✅ **UTCDepartureScheduleAt is populated**: ✅ PASS
✅ **Departure point has LocalScheduledDepartureAt**: ✅ PASS

---
## Final Verdict: ✅ PASSED