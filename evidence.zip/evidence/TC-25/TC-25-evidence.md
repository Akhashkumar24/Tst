# TC-25 - Validate duplicate multi-leg event does not create duplicate records

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T07:57:24.721Z
**Result:** ✅ PASSED
**Duration:** 10411ms

## Test Description
Ingest full multi-leg event (YYZ→YHZ→LHR), re-ingest identical. Verify row counts in BookingInventoryDataStore unchanged across all tables.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785916636575-4kug4vtmg"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8025-2026-11-17",
    "version": "1785916636575215553",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8025"
    },
    "scheduledDepartureDate": "2026-11-17",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "INTERNATIONAL"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-17T19:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YHZ_2",
        "iataCode": "YHZ",
        "city": "YHZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-17T23:05:00"
            }
          ]
        },
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-17T22:09:00"
            }
          ]
        }
      },
      {
        "id": "LHR_3",
        "iataCode": "LHR",
        "city": "LON",
        "country": "GB",
        "region": "EUROP",
        "continent": "ITC2",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-16T09:00:00"
            }
          ],
          "terminals": [
            {
              "code": "2"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-17-YYZ-YHZ",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YHZ_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YHZ",
        "scheduledDepartureDateTime": "2026-11-17T19:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-17T23:00:00Z",
        "scheduledArrivalDateTime": "2026-11-17T22:09:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T01:09:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YHZ"
        ]
      },
      {
        "id": "2026-11-17-YYZ-LHR",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "LHR_3",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "LHR",
        "scheduledDepartureDateTime": "2026-11-17T19:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-17T23:00:00Z",
        "scheduledArrivalDateTime": "2026-11-16T09:00:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T08:00:00Z",
        "numberOfLegs": 2,
        "legIds": [
          "YYZ-YHZ",
          "YHZ-LHR"
        ]
      },
      {
        "id": "2026-11-17-YHZ-LHR",
        "boardFlightPointId": "YHZ_2",
        "offFlightPointId": "LHR_3",
        "boardPointIataCode": "YHZ",
        "offPointIataCode": "LHR",
        "scheduledDepartureDateTime": "2026-11-17T23:05:00",
        "scheduledDepartureDateTimeUtc": "2026-11-16T02:05:00Z",
        "scheduledArrivalDateTime": "2026-11-16T09:00:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T08:00:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YHZ-LHR"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-YHZ",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YHZ_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YHZ",
        "scheduledDepartureDateTime": "2026-11-17T19:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-17T23:00:00Z",
        "scheduledArrivalDateTime": "2026-11-17T22:09:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T01:09:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "7M8",
          "scheduledFittedConfiguration": {
            "code": "7M1",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 153
              }
            ]
          },
          "acvTotalCapacity": 169,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 153
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 153
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "7M1",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 153
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      },
      {
        "id": "YHZ-LHR",
        "boardFlightPointId": "YHZ_2",
        "offFlightPointId": "LHR_3",
        "boardPointIataCode": "YHZ",
        "offPointIataCode": "LHR",
        "scheduledDepartureDateTime": "2026-11-17T23:05:00",
        "scheduledDepartureDateTimeUtc": "2026-11-16T02:05:00Z",
        "scheduledArrivalDateTime": "2026-11-16T09:00:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T08:00:00Z",
        "routingOrder": 2,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "7M8",
          "scheduledFittedConfiguration": {
            "code": "7M1",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 153
              }
            ]
          },
          "acvTotalCapacity": 169,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 153
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 153
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "7M1",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 153
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8025-2026-11-17",
    "originFeedTimeStamp": "2026-08-05T07:57:16.575Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 4567 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T07:57:20.686Z

## Database Verification

### Query 1: Row counts after 1st ingestion
**Database:** CustomerDataMart
**SQL:**
```sql

    SELECT 
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1)::int AS flight_count,
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1)::int AS leg_count,
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlightSegment" WHERE "InventoryFlightId" = $1)::int AS segment_count,
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlightPlace" WHERE "InventoryFlightId" = $1)::int AS place_count,
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlightSegmentAlias" WHERE "InventoryFlightId" = $1)::int AS alias_count
  
```
**Parameters:** ["AC-8025-2026-11-17"]
**Row Count:** 1
**Results:**
```json
[
  {
    "flight_count": 1,
    "leg_count": 2,
    "segment_count": 3,
    "place_count": 3,
    "alias_count": 0
  }
]
```

### Query 2: FlightState after 1st ingestion
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8025","YYZ","2026-11-17"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8025",
    "OperationalSuffix": null,
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YHZ",
    "LocalDepartureScheduledDate": "2026-11-16T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T07:57:16.795Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T07:57:16.795Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T07:57:16.795Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T07:57:16.795Z",
    "CurrentBagFlightLoadStatusCode": null,
    "PreviousBagFlightLoadStatusCode": null,
    "UTCBagFlightLoadStatusModifiedAt": null,
    "RecordCorrelationId": "01KZ8ETFKTP1T024959VM5M2VK",
    "RecordCreatedAt": "2026-08-05T07:57:16.795Z",
    "RecordModifiedAt": "2026-08-05T07:57:16.795Z",
    "RecordExpiredAt": "2027-08-05T07:57:16.795Z",
    "RecordVersion": "1785916636575215600",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

### Query 3: Row counts after 2nd (duplicate) ingestion
**Database:** CustomerDataMart
**SQL:**
```sql

    SELECT 
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1)::int AS flight_count,
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1)::int AS leg_count,
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlightSegment" WHERE "InventoryFlightId" = $1)::int AS segment_count,
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlightPlace" WHERE "InventoryFlightId" = $1)::int AS place_count,
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlightSegmentAlias" WHERE "InventoryFlightId" = $1)::int AS alias_count
  
```
**Parameters:** ["AC-8025-2026-11-17"]
**Row Count:** 1
**Results:**
```json
[
  {
    "flight_count": 1,
    "leg_count": 2,
    "segment_count": 3,
    "place_count": 3,
    "alias_count": 0
  }
]
```

### Query 4: FlightState after 2nd ingestion
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8025","YYZ","2026-11-17"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8025",
    "OperationalSuffix": null,
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YHZ",
    "LocalDepartureScheduledDate": "2026-11-16T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T07:57:16.795Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T07:57:16.795Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T07:57:16.795Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T07:57:16.795Z",
    "CurrentBagFlightLoadStatusCode": null,
    "PreviousBagFlightLoadStatusCode": null,
    "UTCBagFlightLoadStatusModifiedAt": null,
    "RecordCorrelationId": "01KZ8ETKKDWZQRJDHFTENCP6DX",
    "RecordCreatedAt": "2026-08-05T07:57:16.795Z",
    "RecordModifiedAt": "2026-08-05T07:57:20.877Z",
    "RecordExpiredAt": "2027-08-05T07:57:20.877Z",
    "RecordVersion": "1785916636575215600",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

## Assertions

✅ **Lambda success on duplicate**: ✅ PASS
✅ **InventoryFlight count unchanged**: ✅ PASS
✅ **InventoryFlightLeg count unchanged**: ✅ PASS
✅ **InventoryFlightSegment count unchanged**: ✅ PASS
✅ **InventoryFlightPlace count unchanged**: ✅ PASS
✅ **FlightState count unchanged**: ✅ PASS

---
## Final Verdict: ✅ PASSED