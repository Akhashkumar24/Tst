# TC-24 - Validate out-of-order at leg/segment level — DCS status per-database behavior

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T08:04:38.227Z
**Result:** ✅ PASSED
**Duration:** 12280ms

## Test Description
Ingest newer leg update (version 8000000002, Acceptance=CLOSED), then older leg update (version 8000000001, Acceptance=OPEN). InventoryFlightLeg retains CLOSED (version protection). FlightState may revert to OPEN (last-write-wins — documented finding).

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785917073463-mbuliegf9"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8024-2026-11-17",
    "version": "8000000001",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8024"
    },
    "scheduledDepartureDate": "2026-11-17",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-17T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YVR_2",
        "iataCode": "YVR",
        "city": "YVR",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-17T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-17-YYZ-YVR",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YVR_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YVR",
        "scheduledDepartureDateTime": "2026-11-17T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-17T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-17T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-17T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YVR"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-YVR",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YVR_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YVR",
        "scheduledDepartureDateTime": "2026-11-17T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-17T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-17T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-17T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8024-2026-11-17",
    "originFeedTimeStamp": "2026-11-17T11:00:00.000000001Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "UPDATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2458 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T08:04:33.463Z

## Database Verification

### Query 1: InventoryFlightLeg after NEWER event (CLOSED)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8024-2026-11-17"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8024-2026-11-17",
    "Id": "YYZ-YVR",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8024",
    "OperatingNumber": "8024",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YVR_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YVR",
    "LocalDepartureScheduleAt": "2026-11-17T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-17T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-17T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-17T14:30:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "320",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 170,
    "ScheduledFittedAircraftConfigurationCode": "321",
    "ScheduledFittedBusinessSeatCapacity": 14,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 156,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 14,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 156,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 14,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 156,
    "OperationalFittedAircraftConfigurationCode": "321",
    "OperationalFittedBusinessSeatCapacity": 14,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 156,
    "CurrentFlightAcceptanceStatusCode": "CLOSED",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T08:04:29.669Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T08:04:29.669Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T08:04:29.669Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T08:04:29.669Z",
    "RecordCorrelationId": "01KZ8F7PB59G3MHKKGB33SPQA6",
    "RecordCreatedAt": "2026-08-05T08:04:29.669Z",
    "RecordModifiedAt": "2026-08-05T08:04:29.669Z",
    "RecordExpiredAt": null,
    "RecordVersion": "8000000002"
  }
]
```

### Query 2: FlightState after NEWER event (should be CLOSED)
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT 
      "OperatingCarrierCode",
      "OperatingFlightNumber",
      "DepartureAirportIATACode",
      "ArrivalAirportIATACode",
      "LocalDepartureScheduledDate",
      "CurrentFlightAcceptanceStatusCode",
      "CurrentFlightGeneralStatusCode",
      "CurrentFlightLoadControlStatusCode",
      "CurrentFlightBoardingStatusCode",
      "PreviousFlightAcceptanceStatusCode",
      "PreviousFlightGeneralStatusCode",
      "PreviousFlightLoadControlStatusCode",
      "PreviousFlightBoardingStatusCode",
      "UTCFlightAcceptanceStatusModifiedAt",
      "UTCFlightGeneralStatusModifiedAt",
      "UTCFlightLoadControlStatusModifiedAt",
      "UTCFlightBoardingStatusModifiedAt",
      "RecordCreatedAt",
      "RecordModifiedAt",
      "RecordVersion",
      "SourceCreatedBy"
    FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8024","YYZ","2026-11-17"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8024",
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YVR",
    "LocalDepartureScheduledDate": "2026-11-16T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "CLOSED",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T08:04:29.669Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T08:04:29.669Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T08:04:29.669Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T08:04:29.669Z",
    "RecordCreatedAt": "2026-08-05T08:04:29.669Z",
    "RecordModifiedAt": "2026-08-05T08:04:29.669Z",
    "RecordVersion": "8000000002",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

### Query 3: InventoryFlightLeg after STALE event (should still be CLOSED)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8024-2026-11-17"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8024-2026-11-17",
    "Id": "YYZ-YVR",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8024",
    "OperatingNumber": "8024",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YVR_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YVR",
    "LocalDepartureScheduleAt": "2026-11-17T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-17T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-17T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-17T14:30:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "320",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 170,
    "ScheduledFittedAircraftConfigurationCode": "321",
    "ScheduledFittedBusinessSeatCapacity": 14,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 156,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 14,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 156,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 14,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 156,
    "OperationalFittedAircraftConfigurationCode": "321",
    "OperationalFittedBusinessSeatCapacity": 14,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 156,
    "CurrentFlightAcceptanceStatusCode": "CLOSED",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T08:04:29.669Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T08:04:29.669Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T08:04:29.669Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T08:04:29.669Z",
    "RecordCorrelationId": "01KZ8F7PB59G3MHKKGB33SPQA6",
    "RecordCreatedAt": "2026-08-05T08:04:29.669Z",
    "RecordModifiedAt": "2026-08-05T08:04:29.669Z",
    "RecordExpiredAt": null,
    "RecordVersion": "8000000002"
  }
]
```

### Query 4: FlightState after STALE event (check if status reverted)
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT 
      "OperatingCarrierCode",
      "OperatingFlightNumber",
      "DepartureAirportIATACode",
      "ArrivalAirportIATACode",
      "LocalDepartureScheduledDate",
      "CurrentFlightAcceptanceStatusCode",
      "CurrentFlightGeneralStatusCode",
      "CurrentFlightLoadControlStatusCode",
      "CurrentFlightBoardingStatusCode",
      "PreviousFlightAcceptanceStatusCode",
      "PreviousFlightGeneralStatusCode",
      "PreviousFlightLoadControlStatusCode",
      "PreviousFlightBoardingStatusCode",
      "UTCFlightAcceptanceStatusModifiedAt",
      "UTCFlightGeneralStatusModifiedAt",
      "UTCFlightLoadControlStatusModifiedAt",
      "UTCFlightBoardingStatusModifiedAt",
      "RecordCreatedAt",
      "RecordModifiedAt",
      "RecordVersion",
      "SourceCreatedBy"
    FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8024","YYZ","2026-11-17"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8024",
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YVR",
    "LocalDepartureScheduledDate": "2026-11-16T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": "CLOSED",
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T08:04:33.689Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T08:04:29.669Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T08:04:29.669Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T08:04:29.669Z",
    "RecordCreatedAt": "2026-08-05T08:04:29.669Z",
    "RecordModifiedAt": "2026-08-05T08:04:33.689Z",
    "RecordVersion": "8000000001",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

## Assertions

✅ **Lambda handled stale event without crash (200)**: ✅ PASS
✅ **Exactly 1 leg record (no duplicate)**: ✅ PASS
✅ **CustomerDataMart: InventoryFlightLeg.CurrentFlightAcceptanceStatusCode = CLOSED (stale rejected)**: ✅ PASS
✅ **CustomerDataMart: Leg RecordVersion NOT regressed**: ✅ PASS
✅ **⚠️ FINDING: FlightState.CurrentFlightAcceptanceStatusCode reverted to OPEN (stale overwrote)**: ✅ PASS
✅ **⚠️ FINDING: FlightState.PreviousFlightAcceptanceStatusCode = CLOSED (moved to previous)**: ✅ PASS
✅ **⚠️ FINDING: FlightState.RecordVersion regressed to stale version**: ✅ PASS
✅ **⚠️ FINDING: FlightState has NO version-based out-of-order protection (last-write-wins)**: ✅ PASS

---
## Final Verdict: ✅ PASSED