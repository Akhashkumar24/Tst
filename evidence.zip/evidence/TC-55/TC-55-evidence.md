# TC-55 - Validate CabinCode-to-seat-capacity mapping in InventoryFlightLeg

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T10:13:43.443Z
**Result:** ✅ PASSED
**Duration:** 7273ms

## Test Description
Cabins J=27, W=21, Y=244 (total=292). Verify ScheduledFittedBusinessSeatCapacity=27, ScheduledFittedPremiumEconomySeatCapacity=21, ScheduledFittedEconomySeatCapacity=244, TotalSeatCapacity=292.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785924818451-z9x4ztat1"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8055-2026-11-19",
    "version": "1785924818451873160",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8055"
    },
    "scheduledDepartureDate": "2026-11-19",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "INTERNATIONAL"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "GVA_1",
        "iataCode": "GVA",
        "city": "GVA",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-19T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YUL_2",
        "iataCode": "YUL",
        "city": "YUL",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-19T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-19-GVA-YUL",
        "boardFlightPointId": "GVA_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "GVA",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-19T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-19T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-19T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-19T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "GVA-YUL"
        ]
      }
    ],
    "legs": [
      {
        "id": "GVA-YUL",
        "boardFlightPointId": "GVA_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "GVA",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-19T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-19T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-19T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-19T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "331",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 27
              },
              {
                "cabin": "W",
                "capacity": 21
              },
              {
                "cabin": "Y",
                "capacity": 244
              }
            ]
          },
          "acvTotalCapacity": 292,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 27
              },
              {
                "cabin": "W",
                "capacity": 21
              },
              {
                "cabin": "Y",
                "capacity": 244
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 27
              },
              {
                "cabin": "W",
                "capacity": 21
              },
              {
                "cabin": "Y",
                "capacity": 244
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "331",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 27
              },
              {
                "cabin": "W",
                "capacity": 21
              },
              {
                "cabin": "Y",
                "capacity": 244
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8055-2026-11-19",
    "originFeedTimeStamp": "2026-08-05T10:13:38.451Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2578 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T10:13:38.451Z

## Database Verification

### Query 1: InventoryFlightLeg (seat capacity mapping)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8055-2026-11-19"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8055-2026-11-19",
    "Id": "GVA-YUL",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8055",
    "OperatingNumber": "8055",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "GVA_1",
    "OffInventoryPlaceId": "YUL_2",
    "BoardPlaceIATACode": "GVA",
    "OffPlaceIATACode": "YUL",
    "LocalDepartureScheduleAt": "2026-11-19T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-19T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-19T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-19T14:30:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "320",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 292,
    "ScheduledFittedAircraftConfigurationCode": "331",
    "ScheduledFittedBusinessSeatCapacity": 27,
    "ScheduledFittedPremiumEconomySeatCapacity": 21,
    "ScheduledFittedEconomySeatCapacity": 244,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 27,
    "OperationalSaleablePremiumEconomySeatCapacity": 21,
    "OperationalSaleableEconomySeatCapacity": 244,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 27,
    "ScheduledSaleablePremiumEconomySeatCapacity": 21,
    "ScheduledSaleableEconomySeatCapacity": 244,
    "OperationalFittedAircraftConfigurationCode": "331",
    "OperationalFittedBusinessSeatCapacity": 27,
    "OperationalFittedPremiumEconomySeatCapacity": 21,
    "OperationalFittedEconomySeatCapacity": 244,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T10:13:38.632Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T10:13:38.632Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T10:13:38.632Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T10:13:38.632Z",
    "RecordCorrelationId": "01KZ8PM5P89F7DV9XJ1GS9ETTJ",
    "RecordCreatedAt": "2026-08-05T10:13:38.632Z",
    "RecordModifiedAt": "2026-08-05T10:13:38.632Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924818451873300"
  }
]
```

### Query 2: FlightLoadCount
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightStatisticsDataStore"."FlightLoadCount"
    WHERE "FlightOperatingCarrierCode" = $1
      AND "FlightOperatingNumber" = $2
      AND "FlightDepartureAirportCode" = $3
  
```
**Parameters:** ["AC","8055","GVA"]
**Row Count:** 13
**Results:**
```json
[
  {
    "FlightOperatingCarrierCode": "AC",
    "FlightOperatingNumber": "8055",
    "FlightLocalOriginScheduledAt": "2026-11-18T18:30:00.000Z",
    "FlightDepartureAirportCode": "GVA",
    "FlightArrivalAirportCode": "YUL",
    "EntityName": "Seat",
    "AggregationTypeCode": "ScheduledFittedConfiguration",
    "AggregationValue": "J",
    "CurrentValue": 27,
    "CurrentValueUpdatedAt": "2026-08-05T04:43:38.632Z",
    "PreviousValue": null,
    "PreviousValueUpdatedAt": null,
    "RecordCreatedAt": "2026-08-05T04:43:38.632Z",
    "RecordModifiedAt": "2026-08-05T04:43:38.632Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924818451873300",
    "FlightUTCScheduledDepartureAt": null,
    "FlightUTCScheduledArrivalAt": null,
    "AircraftEquipmentTypeCode": "320"
  },
  {
    "FlightOperatingCarrierCode": "AC",
    "FlightOperatingNumber": "8055",
    "FlightLocalOriginScheduledAt": "2026-11-18T18:30:00.000Z",
    "FlightDepartureAirportCode": "GVA",
    "FlightArrivalAirportCode": "YUL",
    "EntityName": "Seat",
    "AggregationTypeCode": "ScheduledFittedConfiguration",
    "AggregationValue": "O",
    "CurrentValue": 21,
    "CurrentValueUpdatedAt": "2026-08-05T04:43:38.632Z",
    "PreviousValue": null,
    "PreviousValueUpdatedAt": null,
    "RecordCreatedAt": "2026-08-05T04:43:38.632Z",
    "RecordModifiedAt": "2026-08-05T04:43:38.632Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924818451873300",
    "FlightUTCScheduledDepartureAt": null,
    "FlightUTCScheduledArrivalAt": null,
    "AircraftEquipmentTypeCode": "320"
  },
  {
    "FlightOperatingCarrierCode": "AC",
    "FlightOperatingNumber": "8055",
    "FlightLocalOriginScheduledAt": "2026-11-18T18:30:00.000Z",
    "FlightDepartureAirportCode": "GVA",
    "FlightArrivalAirportCode": "YUL",
    "EntityName": "Seat",
    "AggregationTypeCode": "ScheduledFittedConfiguration",
    "AggregationValue": "Y",
    "CurrentValue": 244,
    "CurrentValueUpdatedAt": "2026-08-05T04:43:38.632Z",
    "PreviousValue": null,
    "PreviousValueUpdatedAt": null,
    "RecordCreatedAt": "2026-08-05T04:43:38.632Z",
    "RecordModifiedAt": "2026-08-05T04:43:38.632Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924818451873300",
    "FlightUTCScheduledDepartureAt": null,
    "FlightUTCScheduledArrivalAt": null,
    "AircraftEquipmentTypeCode": "320"
  },
  {
    "FlightOperatingCarrierCode": "AC",
    "FlightOperatingNumber": "8055",
    "FlightLocalOriginScheduledAt": "2026-11-18T18:30:00.000Z",
    "FlightDepartureAirportCode": "GVA",
    "FlightArrivalAirportCode": "YUL",
    "EntityName": "Seat",
    "AggregationTypeCode": "OperationalSaleableConfiguration",
    "AggregationValue": "J",
    "CurrentValue": 27,
    "CurrentValueUpdatedAt": "2026-08-05T04:43:38.632Z",
    "PreviousValue": null,
    "PreviousValueUpdatedAt": null,
    "RecordCreatedAt": "2026-08-05T04:43:38.632Z",
    "RecordModifiedAt": "2026-08-05T04:43:38.632Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924818451873300",
    "FlightUTCScheduledDepartureAt": null,
    "FlightUTCScheduledArrivalAt": null,
    "AircraftEquipmentTypeCode": "320"
  },
  {
    "FlightOperatingCarrierCode": "AC",
    "FlightOperatingNumber": "8055",
    "FlightLocalOriginScheduledAt": "2026-11-18T18:30:00.000Z",
    "FlightDepartureAirportCode": "GVA",
    "FlightArrivalAirportCode": "YUL",
    "EntityName": "Seat",
    "AggregationTypeCode": "OperationalSaleableConfiguration",
    "AggregationValue": "O",
    "CurrentValue": 21,
    "CurrentValueUpdatedAt": "2026-08-05T04:43:38.632Z",
    "PreviousValue": null,
    "PreviousValueUpdatedAt": null,
    "RecordCreatedAt": "2026-08-05T04:43:38.632Z",
    "RecordModifiedAt": "2026-08-05T04:43:38.632Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924818451873300",
    "FlightUTCScheduledDepartureAt": null,
    "FlightUTCScheduledArrivalAt": null,
    "AircraftEquipmentTypeCode": "320"
  },
  {
    "FlightOperatingCarrierCode": "AC",
    "FlightOperatingNumber": "8055",
    "FlightLocalOriginScheduledAt": "2026-11-18T18:30:00.000Z",
    "FlightDepartureAirportCode": "GVA",
    "FlightArrivalAirportCode": "YUL",
    "EntityName": "Seat",
    "AggregationTypeCode": "OperationalSaleableConfiguration",
    "AggregationValue": "Y",
    "CurrentValue": 244,
    "CurrentValueUpdatedAt": "2026-08-05T04:43:38.632Z",
    "PreviousValue": null,
    "PreviousValueUpdatedAt": null,
    "RecordCreatedAt": "2026-08-05T04:43:38.632Z",
    "RecordModifiedAt": "2026-08-05T04:43:38.632Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924818451873300",
    "FlightUTCScheduledDepartureAt": null,
    "FlightUTCScheduledArrivalAt": null,
    "AircraftEquipmentTypeCode": "320"
  },
  {
    "FlightOperatingCarrierCode": "AC",
    "FlightOperatingNumber": "8055",
    "FlightLocalOriginScheduledAt": "2026-11-18T18:30:00.000Z",
    "FlightDepartureAirportCode": "GVA",
    "FlightArrivalAirportCode": "YUL",
    "EntityName": "Seat",
    "AggregationTypeCode": "ScheduledSaleableConfiguration",
    "AggregationValue": "J",
    "CurrentValue": 27,
    "CurrentValueUpdatedAt": "2026-08-05T04:43:38.632Z",
    "PreviousValue": null,
    "PreviousValueUpdatedAt": null,
    "RecordCreatedAt": "2026-08-05T04:43:38.632Z",
    "RecordModifiedAt": "2026-08-05T04:43:38.632Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924818451873300",
    "FlightUTCScheduledDepartureAt": null,
    "FlightUTCScheduledArrivalAt": null,
    "AircraftEquipmentTypeCode": "320"
  },
  {
    "FlightOperatingCarrierCode": "AC",
    "FlightOperatingNumber": "8055",
    "FlightLocalOriginScheduledAt": "2026-11-18T18:30:00.000Z",
    "FlightDepartureAirportCode": "GVA",
    "FlightArrivalAirportCode": "YUL",
    "EntityName": "Seat",
    "AggregationTypeCode": "ScheduledSaleableConfiguration",
    "AggregationValue": "O",
    "CurrentValue": 21,
    "CurrentValueUpdatedAt": "2026-08-05T04:43:38.632Z",
    "PreviousValue": null,
    "PreviousValueUpdatedAt": null,
    "RecordCreatedAt": "2026-08-05T04:43:38.632Z",
    "RecordModifiedAt": "2026-08-05T04:43:38.632Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924818451873300",
    "FlightUTCScheduledDepartureAt": null,
    "FlightUTCScheduledArrivalAt": null,
    "AircraftEquipmentTypeCode": "320"
  },
  {
    "FlightOperatingCarrierCode": "AC",
    "FlightOperatingNumber": "8055",
    "FlightLocalOriginScheduledAt": "2026-11-18T18:30:00.000Z",
    "FlightDepartureAirportCode": "GVA",
    "FlightArrivalAirportCode": "YUL",
    "EntityName": "Seat",
    "AggregationTypeCode": "ScheduledSaleableConfiguration",
    "AggregationValue": "Y",
    "CurrentValue": 244,
    "CurrentValueUpdatedAt": "2026-08-05T04:43:38.632Z",
    "PreviousValue": null,
    "PreviousValueUpdatedAt": null,
    "RecordCreatedAt": "2026-08-05T04:43:38.632Z",
    "RecordModifiedAt": "2026-08-05T04:43:38.632Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924818451873300",
    "FlightUTCScheduledDepartureAt": null,
    "FlightUTCScheduledArrivalAt": null,
    "AircraftEquipmentTypeCode": "320"
  },
  {
    "FlightOperatingCarrierCode": "AC",
    "FlightOperatingNumber": "8055",
    "FlightLocalOriginScheduledAt": "2026-11-18T18:30:00.000Z",
    "FlightDepartureAirportCode": "GVA",
    "FlightArrivalAirportCode": "YUL",
    "EntityName": "Seat",
    "AggregationTypeCode": "OperationalFittedConfiguration",
    "AggregationValue": "J",
    "CurrentValue": 27,
    "CurrentValueUpdatedAt": "2026-08-05T04:43:38.632Z",
    "PreviousValue": null,
    "PreviousValueUpdatedAt": null,
    "RecordCreatedAt": "2026-08-05T04:43:38.632Z",
    "RecordModifiedAt": "2026-08-05T04:43:38.632Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924818451873300",
    "FlightUTCScheduledDepartureAt": null,
    "FlightUTCScheduledArrivalAt": null,
    "AircraftEquipmentTypeCode": "320"
  },
  {
    "FlightOperatingCarrierCode": "AC",
    "FlightOperatingNumber": "8055",
    "FlightLocalOriginScheduledAt": "2026-11-18T18:30:00.000Z",
    "FlightDepartureAirportCode": "GVA",
    "FlightArrivalAirportCode": "YUL",
    "EntityName": "Seat",
    "AggregationTypeCode": "OperationalFittedConfiguration",
    "AggregationValue": "O",
    "CurrentValue": 21,
    "CurrentValueUpdatedAt": "2026-08-05T04:43:38.632Z",
    "PreviousValue": null,
    "PreviousValueUpdatedAt": null,
    "RecordCreatedAt": "2026-08-05T04:43:38.632Z",
    "RecordModifiedAt": "2026-08-05T04:43:38.632Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924818451873300",
    "FlightUTCScheduledDepartureAt": null,
    "FlightUTCScheduledArrivalAt": null,
    "AircraftEquipmentTypeCode": "320"
  },
  {
    "FlightOperatingCarrierCode": "AC",
    "FlightOperatingNumber": "8055",
    "FlightLocalOriginScheduledAt": "2026-11-18T18:30:00.000Z",
    "FlightDepartureAirportCode": "GVA",
    "FlightArrivalAirportCode": "YUL",
    "EntityName": "Seat",
    "AggregationTypeCode": "OperationalFittedConfiguration",
    "AggregationValue": "Y",
    "CurrentValue": 244,
    "CurrentValueUpdatedAt": "2026-08-05T04:43:38.632Z",
    "PreviousValue": null,
    "PreviousValueUpdatedAt": null,
    "RecordCreatedAt": "2026-08-05T04:43:38.632Z",
    "RecordModifiedAt": "2026-08-05T04:43:38.632Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924818451873300",
    "FlightUTCScheduledDepartureAt": null,
    "FlightUTCScheduledArrivalAt": null,
    "AircraftEquipmentTypeCode": "320"
  },
  {
    "FlightOperatingCarrierCode": "AC",
    "FlightOperatingNumber": "8055",
    "FlightLocalOriginScheduledAt": "2026-11-18T18:30:00.000Z",
    "FlightDepartureAirportCode": "GVA",
    "FlightArrivalAirportCode": "YUL",
    "EntityName": "Seat",
    "AggregationTypeCode": "ScheduledFittedTotalSeatCapacity",
    "AggregationValue": "",
    "CurrentValue": 292,
    "CurrentValueUpdatedAt": "2026-08-05T04:43:38.632Z",
    "PreviousValue": null,
    "PreviousValueUpdatedAt": null,
    "RecordCreatedAt": "2026-08-05T04:43:38.632Z",
    "RecordModifiedAt": "2026-08-05T04:43:38.632Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924818451873300",
    "FlightUTCScheduledDepartureAt": null,
    "FlightUTCScheduledArrivalAt": null,
    "AircraftEquipmentTypeCode": "320"
  }
]
```

## Assertions

✅ **Lambda success**: ✅ PASS
✅ **InventoryFlightLeg record exists**: ✅ PASS
✅ **TotalSeatCapacity=292**: ✅ PASS
✅ **ScheduledFittedBusinessSeatCapacity=27 (J cabin)**: ✅ PASS
✅ **ScheduledFittedPremiumEconomySeatCapacity=21 (W cabin)**: ✅ PASS
✅ **ScheduledFittedEconomySeatCapacity=244 (Y cabin)**: ✅ PASS
✅ **ScheduledFittedAircraftConfigurationCode=331**: ✅ PASS
✅ **FlightLoadCount populated**: ✅ PASS

---
## Final Verdict: ✅ PASSED