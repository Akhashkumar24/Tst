# TC-36 - Verify a single SKD event writes consistently across all target tables

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T10:07:00.032Z
**Result:** ✅ PASSED
**Duration:** 13576ms

## Test Description
Ingest one event. Query BookingInventoryDataStore (InventoryFlight, Leg, Place, Segment), FlightOperationsDataStore (FlightState), and FlightStatisticsDataStore (FlightLoadCount). Verify all have records.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785924408886-0ry5h5i5b"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8036-2026-11-18",
    "version": "1785924408886731190",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8036"
    },
    "scheduledDepartureDate": "2026-11-18",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-18T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YOW_2",
        "iataCode": "YOW",
        "city": "YOW",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-18T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-18-YYZ-YOW",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YOW_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YOW",
        "scheduledDepartureDateTime": "2026-11-18T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-18T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-18T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-18T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YOW"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-YOW",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YOW_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YOW",
        "scheduledDepartureDateTime": "2026-11-18T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-18T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-18T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-18T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8036-2026-11-18",
    "originFeedTimeStamp": "2026-08-05T10:06:48.886Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2461 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T10:06:48.887Z

## Database Verification

### Query 1: InventoryFlight
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8036-2026-11-18"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8036-2026-11-18",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8036",
    "OperatingNumber": "8036",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-17T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8P7SX7E76ZGCWXH0VGPXFZ",
    "RecordCreatedAt": "2026-08-05T10:06:53.352Z",
    "RecordModifiedAt": "2026-08-05T10:06:53.352Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924408886731300"
  }
]
```

### Query 2: InventoryFlightLeg
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8036-2026-11-18"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8036-2026-11-18",
    "Id": "YYZ-YOW",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8036",
    "OperatingNumber": "8036",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YOW_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YOW",
    "LocalDepartureScheduleAt": "2026-11-18T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-18T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-18T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-18T14:30:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "320",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 170,
    "ScheduledFittedAircraftConfigurationCode": "321",
    "ScheduledFittedBusinessSeatCapacity": 14,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 156,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 14,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 156,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 14,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 156,
    "OperationalFittedAircraftConfigurationCode": "321",
    "OperationalFittedBusinessSeatCapacity": 14,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 156,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T10:06:53.352Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T10:06:53.352Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T10:06:53.352Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T10:06:53.352Z",
    "RecordCorrelationId": "01KZ8P7SX7E76ZGCWXH0VGPXFZ",
    "RecordCreatedAt": "2026-08-05T10:06:53.352Z",
    "RecordModifiedAt": "2026-08-05T10:06:53.352Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924408886731300"
  }
]
```

### Query 3: InventoryFlightPlace
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightPlace" WHERE "InventoryFlightId" = $1
```
**Parameters:** ["AC-8036-2026-11-18"]
**Row Count:** 2
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8036-2026-11-18",
    "InventoryPlaceId": "YYZ_1",
    "PlaceIATACode": "YYZ",
    "PlaceCityCode": "YYZ",
    "CountryCode": "CA",
    "InventoryPlaceRegionCode": "NAMER",
    "InventoryPlaceContinentCode": "ITC1",
    "LocalScheduledDepartureAt": "2026-11-18T02:30:00.000Z",
    "LocalScheduledArrivalAt": null,
    "LocalEstimatedOffBlockAt": null,
    "LocalEstimatedTakeOffAt": null,
    "LocalEstimatedTouchdownAt": null,
    "LocalEstimatedOnBlockAt": null,
    "LocalActualOffBlockAt": null,
    "LocalActualTakeOffAt": null,
    "LocalActualTouchdownAt": null,
    "LocalActualOnBlockAt": null,
    "Terminals": [
      {
        "code": "1"
      }
    ],
    "RecordCorrelationId": "01KZ8P7SX7E76ZGCWXH0VGPXFZ",
    "RecordCreatedAt": "2026-08-05T10:06:53.352Z",
    "RecordModifiedAt": "2026-08-05T10:06:53.352Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924408886731300"
  },
  {
    "InventoryFlightId": "AC-8036-2026-11-18",
    "InventoryPlaceId": "YOW_2",
    "PlaceIATACode": "YOW",
    "PlaceCityCode": "YOW",
    "CountryCode": "CA",
    "InventoryPlaceRegionCode": "NAMER",
    "InventoryPlaceContinentCode": "ITC1",
    "LocalScheduledDepartureAt": null,
    "LocalScheduledArrivalAt": "2026-11-18T05:00:00.000Z",
    "LocalEstimatedOffBlockAt": null,
    "LocalEstimatedTakeOffAt": null,
    "LocalEstimatedTouchdownAt": null,
    "LocalEstimatedOnBlockAt": null,
    "LocalActualOffBlockAt": null,
    "LocalActualTakeOffAt": null,
    "LocalActualTouchdownAt": null,
    "LocalActualOnBlockAt": null,
    "Terminals": [
      {
        "code": "1"
      }
    ],
    "RecordCorrelationId": "01KZ8P7SX7E76ZGCWXH0VGPXFZ",
    "RecordCreatedAt": "2026-08-05T10:06:53.352Z",
    "RecordModifiedAt": "2026-08-05T10:06:53.352Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924408886731300"
  }
]
```

### Query 4: InventoryFlightSegment
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightSegment" WHERE "InventoryFlightId" = $1
```
**Parameters:** ["AC-8036-2026-11-18"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8036-2026-11-18",
    "Id": "2026-11-18-YYZ-YOW",
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YOW_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YOW",
    "LocalDepartureScheduleAt": "2026-11-18T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-18T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-18T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-18T14:30:00.000Z",
    "LegCount": 1,
    "TrafficRestrictions": null,
    "RecordCorrelationId": "01KZ8P7SX7E76ZGCWXH0VGPXFZ",
    "RecordCreatedAt": "2026-08-05T10:06:53.352Z",
    "RecordModifiedAt": "2026-08-05T10:06:53.352Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924408886731300"
  }
]
```

### Query 5: FlightState
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8036","YYZ","2026-11-18"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8036",
    "OperationalSuffix": null,
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YOW",
    "LocalDepartureScheduledDate": "2026-11-17T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T10:06:53.352Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T10:06:53.352Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T10:06:53.352Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T10:06:53.352Z",
    "CurrentBagFlightLoadStatusCode": null,
    "PreviousBagFlightLoadStatusCode": null,
    "UTCBagFlightLoadStatusModifiedAt": null,
    "RecordCorrelationId": "01KZ8P7SX7E76ZGCWXH0VGPXFZ",
    "RecordCreatedAt": "2026-08-05T10:06:53.352Z",
    "RecordModifiedAt": "2026-08-05T10:06:53.352Z",
    "RecordExpiredAt": "2027-08-05T10:06:53.352Z",
    "RecordVersion": "1785924408886731300",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

### Query 6: FlightLoadCount
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightStatisticsDataStore"."FlightLoadCount"
    WHERE "FlightOperatingCarrierCode" = $1
      AND "FlightOperatingNumber" = $2
      AND "FlightDepartureAirportCode" = $3
  
```
**Parameters:** ["AC","8036","YYZ"]
**Row Count:** 9
**Results:**
```json
[
  {
    "FlightOperatingCarrierCode": "AC",
    "FlightOperatingNumber": "8036",
    "FlightLocalOriginScheduledAt": "2026-11-17T18:30:00.000Z",
    "FlightDepartureAirportCode": "YYZ",
    "FlightArrivalAirportCode": "YOW",
    "EntityName": "Seat",
    "AggregationTypeCode": "ScheduledFittedConfiguration",
    "AggregationValue": "J",
    "CurrentValue": 14,
    "CurrentValueUpdatedAt": "2026-08-05T04:36:53.352Z",
    "PreviousValue": null,
    "PreviousValueUpdatedAt": null,
    "RecordCreatedAt": "2026-08-05T04:29:35.898Z",
    "RecordModifiedAt": "2026-08-05T04:36:53.352Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924408886731300",
    "FlightUTCScheduledDepartureAt": null,
    "FlightUTCScheduledArrivalAt": null,
    "AircraftEquipmentTypeCode": "320"
  },
  {
    "FlightOperatingCarrierCode": "AC",
    "FlightOperatingNumber": "8036",
    "FlightLocalOriginScheduledAt": "2026-11-17T18:30:00.000Z",
    "FlightDepartureAirportCode": "YYZ",
    "FlightArrivalAirportCode": "YOW",
    "EntityName": "Seat",
    "AggregationTypeCode": "ScheduledFittedConfiguration",
    "AggregationValue": "Y",
    "CurrentValue": 156,
    "CurrentValueUpdatedAt": "2026-08-05T04:36:53.352Z",
    "PreviousValue": null,
    "PreviousValueUpdatedAt": null,
    "RecordCreatedAt": "2026-08-05T04:29:35.898Z",
    "RecordModifiedAt": "2026-08-05T04:36:53.352Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924408886731300",
    "FlightUTCScheduledDepartureAt": null,
    "FlightUTCScheduledArrivalAt": null,
    "AircraftEquipmentTypeCode": "320"
  },
  {
    "FlightOperatingCarrierCode": "AC",
    "FlightOperatingNumber": "8036",
    "FlightLocalOriginScheduledAt": "2026-11-17T18:30:00.000Z",
    "FlightDepartureAirportCode": "YYZ",
    "FlightArrivalAirportCode": "YOW",
    "EntityName": "Seat",
    "AggregationTypeCode": "OperationalSaleableConfiguration",
    "AggregationValue": "J",
    "CurrentValue": 14,
    "CurrentValueUpdatedAt": "2026-08-05T04:36:53.352Z",
    "PreviousValue": null,
    "PreviousValueUpdatedAt": null,
    "RecordCreatedAt": "2026-08-05T04:29:35.898Z",
    "RecordModifiedAt": "2026-08-05T04:36:53.352Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924408886731300",
    "FlightUTCScheduledDepartureAt": null,
    "FlightUTCScheduledArrivalAt": null,
    "AircraftEquipmentTypeCode": "320"
  },
  {
    "FlightOperatingCarrierCode": "AC",
    "FlightOperatingNumber": "8036",
    "FlightLocalOriginScheduledAt": "2026-11-17T18:30:00.000Z",
    "FlightDepartureAirportCode": "YYZ",
    "FlightArrivalAirportCode": "YOW",
    "EntityName": "Seat",
    "AggregationTypeCode": "OperationalSaleableConfiguration",
    "AggregationValue": "Y",
    "CurrentValue": 156,
    "CurrentValueUpdatedAt": "2026-08-05T04:36:53.352Z",
    "PreviousValue": null,
    "PreviousValueUpdatedAt": null,
    "RecordCreatedAt": "2026-08-05T04:29:35.898Z",
    "RecordModifiedAt": "2026-08-05T04:36:53.352Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924408886731300",
    "FlightUTCScheduledDepartureAt": null,
    "FlightUTCScheduledArrivalAt": null,
    "AircraftEquipmentTypeCode": "320"
  },
  {
    "FlightOperatingCarrierCode": "AC",
    "FlightOperatingNumber": "8036",
    "FlightLocalOriginScheduledAt": "2026-11-17T18:30:00.000Z",
    "FlightDepartureAirportCode": "YYZ",
    "FlightArrivalAirportCode": "YOW",
    "EntityName": "Seat",
    "AggregationTypeCode": "ScheduledSaleableConfiguration",
    "AggregationValue": "J",
    "CurrentValue": 14,
    "CurrentValueUpdatedAt": "2026-08-05T04:36:53.352Z",
    "PreviousValue": null,
    "PreviousValueUpdatedAt": null,
    "RecordCreatedAt": "2026-08-05T04:29:35.898Z",
    "RecordModifiedAt": "2026-08-05T04:36:53.352Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924408886731300",
    "FlightUTCScheduledDepartureAt": null,
    "FlightUTCScheduledArrivalAt": null,
    "AircraftEquipmentTypeCode": "320"
  },
  {
    "FlightOperatingCarrierCode": "AC",
    "FlightOperatingNumber": "8036",
    "FlightLocalOriginScheduledAt": "2026-11-17T18:30:00.000Z",
    "FlightDepartureAirportCode": "YYZ",
    "FlightArrivalAirportCode": "YOW",
    "EntityName": "Seat",
    "AggregationTypeCode": "ScheduledSaleableConfiguration",
    "AggregationValue": "Y",
    "CurrentValue": 156,
    "CurrentValueUpdatedAt": "2026-08-05T04:36:53.352Z",
    "PreviousValue": null,
    "PreviousValueUpdatedAt": null,
    "RecordCreatedAt": "2026-08-05T04:29:35.898Z",
    "RecordModifiedAt": "2026-08-05T04:36:53.352Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924408886731300",
    "FlightUTCScheduledDepartureAt": null,
    "FlightUTCScheduledArrivalAt": null,
    "AircraftEquipmentTypeCode": "320"
  },
  {
    "FlightOperatingCarrierCode": "AC",
    "FlightOperatingNumber": "8036",
    "FlightLocalOriginScheduledAt": "2026-11-17T18:30:00.000Z",
    "FlightDepartureAirportCode": "YYZ",
    "FlightArrivalAirportCode": "YOW",
    "EntityName": "Seat",
    "AggregationTypeCode": "OperationalFittedConfiguration",
    "AggregationValue": "J",
    "CurrentValue": 14,
    "CurrentValueUpdatedAt": "2026-08-05T04:36:53.352Z",
    "PreviousValue": null,
    "PreviousValueUpdatedAt": null,
    "RecordCreatedAt": "2026-08-05T04:29:35.898Z",
    "RecordModifiedAt": "2026-08-05T04:36:53.352Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924408886731300",
    "FlightUTCScheduledDepartureAt": null,
    "FlightUTCScheduledArrivalAt": null,
    "AircraftEquipmentTypeCode": "320"
  },
  {
    "FlightOperatingCarrierCode": "AC",
    "FlightOperatingNumber": "8036",
    "FlightLocalOriginScheduledAt": "2026-11-17T18:30:00.000Z",
    "FlightDepartureAirportCode": "YYZ",
    "FlightArrivalAirportCode": "YOW",
    "EntityName": "Seat",
    "AggregationTypeCode": "OperationalFittedConfiguration",
    "AggregationValue": "Y",
    "CurrentValue": 156,
    "CurrentValueUpdatedAt": "2026-08-05T04:36:53.352Z",
    "PreviousValue": null,
    "PreviousValueUpdatedAt": null,
    "RecordCreatedAt": "2026-08-05T04:29:35.898Z",
    "RecordModifiedAt": "2026-08-05T04:36:53.352Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924408886731300",
    "FlightUTCScheduledDepartureAt": null,
    "FlightUTCScheduledArrivalAt": null,
    "AircraftEquipmentTypeCode": "320"
  },
  {
    "FlightOperatingCarrierCode": "AC",
    "FlightOperatingNumber": "8036",
    "FlightLocalOriginScheduledAt": "2026-11-17T18:30:00.000Z",
    "FlightDepartureAirportCode": "YYZ",
    "FlightArrivalAirportCode": "YOW",
    "EntityName": "Seat",
    "AggregationTypeCode": "ScheduledFittedTotalSeatCapacity",
    "AggregationValue": "",
    "CurrentValue": 170,
    "CurrentValueUpdatedAt": "2026-08-05T04:36:53.352Z",
    "PreviousValue": null,
    "PreviousValueUpdatedAt": null,
    "RecordCreatedAt": "2026-08-05T04:29:35.898Z",
    "RecordModifiedAt": "2026-08-05T04:36:53.352Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924408886731300",
    "FlightUTCScheduledDepartureAt": null,
    "FlightUTCScheduledArrivalAt": null,
    "AircraftEquipmentTypeCode": "320"
  }
]
```

## Assertions

✅ **Lambda success**: ✅ PASS
✅ **InventoryFlight record exists**: ✅ PASS
✅ **InventoryFlightLeg record exists**: ✅ PASS
✅ **InventoryFlightPlace records exist**: ✅ PASS
✅ **InventoryFlightSegment record exists**: ✅ PASS
✅ **FlightState record exists**: ✅ PASS
✅ **FlightLoadCount record(s) exist**: ✅ PASS

---
## Final Verdict: ✅ PASSED