# TC-19 - Verify audit fields are populated correctly on every ingested record

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T07:57:58.855Z
**Result:** ✅ PASSED
**Duration:** 8874ms

## Test Description
Ingest valid event. Check RecordCreatedAt, RecordModifiedAt, RecordCorrelationId in InventoryFlight/Leg. Check SourceCreatedBy in FlightState (only FlightState has that column).

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785916672127-29ta51805"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8019-2026-11-17",
    "version": "1785916672127651695",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8019"
    },
    "scheduledDepartureDate": "2026-11-17",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-17T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YOW_2",
        "iataCode": "YOW",
        "city": "YOW",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-17T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-17-YYZ-YOW",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YOW_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YOW",
        "scheduledDepartureDateTime": "2026-11-17T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-17T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-17T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-17T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YOW"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-YOW",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YOW_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YOW",
        "scheduledDepartureDateTime": "2026-11-17T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-17T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-17T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-17T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8019-2026-11-17",
    "originFeedTimeStamp": "2026-08-05T07:57:52.127Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2461 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T07:57:52.127Z

## Database Verification

### Query 1: InventoryFlight (audit fields)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8019-2026-11-17"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8019-2026-11-17",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8019",
    "OperatingNumber": "8019",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-16T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8EVMP6DNFV7VD6XNR6DVGM",
    "RecordCreatedAt": "2026-08-05T07:57:54.758Z",
    "RecordModifiedAt": "2026-08-05T07:57:54.758Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785916672127651600"
  }
]
```

### Query 2: InventoryFlightLeg (audit fields)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8019-2026-11-17"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8019-2026-11-17",
    "Id": "YYZ-YOW",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8019",
    "OperatingNumber": "8019",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YOW_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YOW",
    "LocalDepartureScheduleAt": "2026-11-17T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-17T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-17T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-17T14:30:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "320",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 170,
    "ScheduledFittedAircraftConfigurationCode": "321",
    "ScheduledFittedBusinessSeatCapacity": 14,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 156,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 14,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 156,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 14,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 156,
    "OperationalFittedAircraftConfigurationCode": "321",
    "OperationalFittedBusinessSeatCapacity": 14,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 156,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T07:57:54.758Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T07:57:54.758Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T07:57:54.758Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T07:57:54.758Z",
    "RecordCorrelationId": "01KZ8EVMP6DNFV7VD6XNR6DVGM",
    "RecordCreatedAt": "2026-08-05T07:57:54.758Z",
    "RecordModifiedAt": "2026-08-05T07:57:54.758Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785916672127651600"
  }
]
```

### Query 3: FlightState (audit fields + SourceCreatedBy)
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT 
      "OperatingCarrierCode",
      "OperatingFlightNumber",
      "DepartureAirportIATACode",
      "ArrivalAirportIATACode",
      "LocalDepartureScheduledDate",
      "CurrentFlightAcceptanceStatusCode",
      "CurrentFlightGeneralStatusCode",
      "CurrentFlightLoadControlStatusCode",
      "CurrentFlightBoardingStatusCode",
      "PreviousFlightAcceptanceStatusCode",
      "PreviousFlightGeneralStatusCode",
      "PreviousFlightLoadControlStatusCode",
      "PreviousFlightBoardingStatusCode",
      "UTCFlightAcceptanceStatusModifiedAt",
      "UTCFlightGeneralStatusModifiedAt",
      "UTCFlightLoadControlStatusModifiedAt",
      "UTCFlightBoardingStatusModifiedAt",
      "RecordCreatedAt",
      "RecordModifiedAt",
      "RecordVersion",
      "SourceCreatedBy"
    FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8019","YYZ","2026-11-17"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8019",
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YOW",
    "LocalDepartureScheduledDate": "2026-11-16T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T07:57:54.758Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T07:57:54.758Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T07:57:54.758Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T07:57:54.758Z",
    "RecordCreatedAt": "2026-08-05T07:57:54.758Z",
    "RecordModifiedAt": "2026-08-05T07:57:54.758Z",
    "RecordVersion": "1785916672127651600",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

## Assertions

✅ **Lambda success**: ✅ PASS
✅ **InventoryFlight record exists**: ✅ PASS
✅ **InventoryFlight.RecordCreatedAt populated**: ✅ PASS
✅ **InventoryFlight.RecordModifiedAt populated**: ✅ PASS
✅ **InventoryFlight.RecordCorrelationId populated (ULID)**: ✅ PASS
✅ **InventoryFlight.RecordVersion populated**: ✅ PASS
✅ **InventoryFlightLeg.RecordCreatedAt populated**: ✅ PASS
✅ **InventoryFlightLeg.RecordModifiedAt populated**: ✅ PASS
✅ **InventoryFlightLeg.RecordCorrelationId populated**: ✅ PASS
✅ **FlightState.RecordCreatedAt populated**: ✅ PASS
✅ **FlightState.RecordModifiedAt populated**: ✅ PASS
✅ **FlightState.SourceCreatedBy = ALTEA-SKD**: ✅ PASS
✅ **FlightState.RecordVersion populated**: ✅ PASS

---
## Final Verdict: ✅ PASSED