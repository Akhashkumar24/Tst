# TC-04 - Verify duplicate event does not create duplicate records (idempotency)

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T07:27:31.825Z
**Result:** ✅ PASSED
**Duration:** 7432ms

## Test Description
Ingest a valid event, re-ingest the identical event, check row count unchanged.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785914844393-477erhkrk"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8004-2026-11-15",
    "version": "1785914844393941840",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8004"
    },
    "scheduledDepartureDate": "2026-11-15",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-15T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YVR_2",
        "iataCode": "YVR",
        "city": "YVR",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-15T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-15-YYZ-YVR",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YVR_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YVR",
        "scheduledDepartureDateTime": "2026-11-15T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-15T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-15T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-15T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YVR"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-YVR",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YVR_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YVR",
        "scheduledDepartureDateTime": "2026-11-15T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-15T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-15T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-15T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8004-2026-11-15",
    "originFeedTimeStamp": "2026-08-05T07:27:24.393Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2461 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T07:27:28.138Z

## Database Verification

### Query 1: Row counts after 1st ingestion
**Database:** CustomerDataMart
**SQL:**
```sql

    SELECT 
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1)::int AS flight_count,
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1)::int AS leg_count,
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlightSegment" WHERE "InventoryFlightId" = $1)::int AS segment_count,
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlightPlace" WHERE "InventoryFlightId" = $1)::int AS place_count,
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlightSegmentAlias" WHERE "InventoryFlightId" = $1)::int AS alias_count
  
```
**Parameters:** ["AC-8004-2026-11-15"]
**Row Count:** 1
**Results:**
```json
[
  {
    "flight_count": 1,
    "leg_count": 1,
    "segment_count": 1,
    "place_count": 2,
    "alias_count": 0
  }
]
```

### Query 2: Row counts after 2nd ingestion (duplicate)
**Database:** CustomerDataMart
**SQL:**
```sql

    SELECT 
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1)::int AS flight_count,
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1)::int AS leg_count,
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlightSegment" WHERE "InventoryFlightId" = $1)::int AS segment_count,
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlightPlace" WHERE "InventoryFlightId" = $1)::int AS place_count,
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlightSegmentAlias" WHERE "InventoryFlightId" = $1)::int AS alias_count
  
```
**Parameters:** ["AC-8004-2026-11-15"]
**Row Count:** 1
**Results:**
```json
[
  {
    "flight_count": 1,
    "leg_count": 1,
    "segment_count": 1,
    "place_count": 2,
    "alias_count": 0
  }
]
```

## Assertions

✅ **Lambda success**: ✅ PASS
✅ **Flight row count unchanged**: ✅ PASS
✅ **Leg row count unchanged**: ✅ PASS
✅ **Segment row count unchanged**: ✅ PASS

---
## Final Verdict: ✅ PASSED