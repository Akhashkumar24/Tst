# TC-59 - Validate aircraft equipment per leg and cabin capacities

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T10:24:38.433Z
**Result:** ✅ PASSED
**Duration:** 7245ms

## Test Description
Multi-leg: Leg1=320 (J/Y), Leg2=321 (J/W/Y). Verify EquipmentTypeCode and seat capacities independent per leg in InventoryFlightLeg.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785925474584-vx3avmuvp"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8059-2026-11-20",
    "version": "1785925474584114822",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8059"
    },
    "scheduledDepartureDate": "2026-11-20",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "INTERNATIONAL"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-20T19:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YHZ_2",
        "iataCode": "YHZ",
        "city": "YHZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-20T23:05:00"
            }
          ]
        },
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-20T22:09:00"
            }
          ]
        }
      },
      {
        "id": "LHR_3",
        "iataCode": "LHR",
        "city": "LON",
        "country": "GB",
        "region": "EUROP",
        "continent": "ITC2",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-16T09:00:00"
            }
          ],
          "terminals": [
            {
              "code": "2"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-20-YYZ-YHZ",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YHZ_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YHZ",
        "scheduledDepartureDateTime": "2026-11-20T19:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-20T23:00:00Z",
        "scheduledArrivalDateTime": "2026-11-20T22:09:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T01:09:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YHZ"
        ]
      },
      {
        "id": "2026-11-20-YYZ-LHR",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "LHR_3",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "LHR",
        "scheduledDepartureDateTime": "2026-11-20T19:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-20T23:00:00Z",
        "scheduledArrivalDateTime": "2026-11-16T09:00:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T08:00:00Z",
        "numberOfLegs": 2,
        "legIds": [
          "YYZ-YHZ",
          "YHZ-LHR"
        ]
      },
      {
        "id": "2026-11-20-YHZ-LHR",
        "boardFlightPointId": "YHZ_2",
        "offFlightPointId": "LHR_3",
        "boardPointIataCode": "YHZ",
        "offPointIataCode": "LHR",
        "scheduledDepartureDateTime": "2026-11-20T23:05:00",
        "scheduledDepartureDateTimeUtc": "2026-11-16T02:05:00Z",
        "scheduledArrivalDateTime": "2026-11-16T09:00:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T08:00:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YHZ-LHR"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-YHZ",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YHZ_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YHZ",
        "scheduledDepartureDateTime": "2026-11-20T19:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-20T23:00:00Z",
        "scheduledArrivalDateTime": "2026-11-20T22:09:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T01:09:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "7M1",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "7M1",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      },
      {
        "id": "YHZ-LHR",
        "boardFlightPointId": "YHZ_2",
        "offFlightPointId": "LHR_3",
        "boardPointIataCode": "YHZ",
        "offPointIataCode": "LHR",
        "scheduledDepartureDateTime": "2026-11-20T23:05:00",
        "scheduledDepartureDateTimeUtc": "2026-11-16T02:05:00Z",
        "scheduledArrivalDateTime": "2026-11-16T09:00:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T08:00:00Z",
        "routingOrder": 2,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "321",
          "scheduledFittedConfiguration": {
            "code": "7M1",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "W",
                "capacity": 21
              },
              {
                "cabin": "Y",
                "capacity": 163
              }
            ]
          },
          "acvTotalCapacity": 200,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "W",
                "capacity": 21
              },
              {
                "cabin": "Y",
                "capacity": 163
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "W",
                "capacity": 21
              },
              {
                "cabin": "Y",
                "capacity": 163
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "7M1",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "W",
                "capacity": 21
              },
              {
                "cabin": "Y",
                "capacity": 163
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8059-2026-11-20",
    "originFeedTimeStamp": "2026-08-05T10:24:34.584Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 4679 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T10:24:34.584Z

## Database Verification

### Query 1: InventoryFlightLeg (different aircraft per leg)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8059-2026-11-20"]
**Row Count:** 2
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8059-2026-11-20",
    "Id": "YYZ-YHZ",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8059",
    "OperatingNumber": "8059",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YHZ_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YHZ",
    "LocalDepartureScheduleAt": "2026-11-20T13:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-20T23:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-20T16:39:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-16T01:09:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "320",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 170,
    "ScheduledFittedAircraftConfigurationCode": "7M1",
    "ScheduledFittedBusinessSeatCapacity": 14,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 156,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 14,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 156,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 14,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 156,
    "OperationalFittedAircraftConfigurationCode": "7M1",
    "OperationalFittedBusinessSeatCapacity": 14,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 156,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T10:24:34.782Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T10:24:34.782Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T10:24:34.782Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T10:24:34.782Z",
    "RecordCorrelationId": "01KZ8Q86EYQJRN6BPV8MX85867",
    "RecordCreatedAt": "2026-08-05T10:24:34.782Z",
    "RecordModifiedAt": "2026-08-05T10:24:34.782Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785925474584115000"
  },
  {
    "InventoryFlightId": "AC-8059-2026-11-20",
    "Id": "YHZ-LHR",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8059",
    "OperatingNumber": "8059",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YHZ_2",
    "OffInventoryPlaceId": "LHR_3",
    "BoardPlaceIATACode": "YHZ",
    "OffPlaceIATACode": "LHR",
    "LocalDepartureScheduleAt": "2026-11-20T17:35:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-16T02:05:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-16T03:30:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-16T08:00:00.000Z",
    "SequenceNumber": 2,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "321",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 200,
    "ScheduledFittedAircraftConfigurationCode": "7M1",
    "ScheduledFittedBusinessSeatCapacity": 16,
    "ScheduledFittedPremiumEconomySeatCapacity": 21,
    "ScheduledFittedEconomySeatCapacity": 163,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 16,
    "OperationalSaleablePremiumEconomySeatCapacity": 21,
    "OperationalSaleableEconomySeatCapacity": 163,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 16,
    "ScheduledSaleablePremiumEconomySeatCapacity": 21,
    "ScheduledSaleableEconomySeatCapacity": 163,
    "OperationalFittedAircraftConfigurationCode": "7M1",
    "OperationalFittedBusinessSeatCapacity": 16,
    "OperationalFittedPremiumEconomySeatCapacity": 21,
    "OperationalFittedEconomySeatCapacity": 163,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T10:24:34.782Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T10:24:34.782Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T10:24:34.782Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T10:24:34.782Z",
    "RecordCorrelationId": "01KZ8Q86EYQJRN6BPV8MX85867",
    "RecordCreatedAt": "2026-08-05T10:24:34.782Z",
    "RecordModifiedAt": "2026-08-05T10:24:34.782Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785925474584115000"
  }
]
```

## Assertions

✅ **Lambda success**: ✅ PASS
✅ **2 legs created**: ✅ PASS
✅ **Leg1 EquipmentTypeCode=320**: ✅ PASS
✅ **Leg1 TotalSeatCapacity=170**: ✅ PASS
✅ **Leg2 EquipmentTypeCode=321**: ✅ PASS
✅ **Leg2 TotalSeatCapacity=200**: ✅ PASS
✅ **Leg2 ScheduledFittedPremiumEconomySeatCapacity=21 (W cabin)**: ✅ PASS

---
## Final Verdict: ✅ PASSED