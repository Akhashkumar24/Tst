# TC-23 - Verify out-of-order (stale) event handling — per-database behavior

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T08:04:15.322Z
**Result:** ✅ PASSED
**Duration:** 13452ms

## Test Description
Ingest newer event (version 9000000002, terminal=5), then older event (version 9000000001, terminal=1). Verify: CustomerDataMart rejects stale (version-protected). FlightState may accept stale (last-write-wins — document finding).

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785917051049-f75nylkd5"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8023-2026-11-17",
    "version": "9000000001",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8023"
    },
    "scheduledDepartureDate": "2026-11-17",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-17T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YUL_2",
        "iataCode": "YUL",
        "city": "YUL",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-17T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-17-YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-17T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-17T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-17T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-17T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YUL"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-17T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-17T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-17T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-17T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8023-2026-11-17",
    "originFeedTimeStamp": "2026-11-17T09:00:00.000000001Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "UPDATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2458 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T08:04:11.049Z

## Database Verification

### Query 1: InventoryFlightPlace after NEWER event (terminal=5)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightPlace" WHERE "InventoryFlightId" = $1
```
**Parameters:** ["AC-8023-2026-11-17"]
**Row Count:** 2
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8023-2026-11-17",
    "InventoryPlaceId": "YYZ_1",
    "PlaceIATACode": "YYZ",
    "PlaceCityCode": "YYZ",
    "CountryCode": "CA",
    "InventoryPlaceRegionCode": "NAMER",
    "InventoryPlaceContinentCode": "ITC1",
    "LocalScheduledDepartureAt": "2026-11-17T02:30:00.000Z",
    "LocalScheduledArrivalAt": null,
    "LocalEstimatedOffBlockAt": null,
    "LocalEstimatedTakeOffAt": null,
    "LocalEstimatedTouchdownAt": null,
    "LocalEstimatedOnBlockAt": null,
    "LocalActualOffBlockAt": null,
    "LocalActualTakeOffAt": null,
    "LocalActualTouchdownAt": null,
    "LocalActualOnBlockAt": null,
    "Terminals": [
      {
        "code": "5"
      }
    ],
    "RecordCorrelationId": "01KZ8F702M52Q17Q2TH31FJCTY",
    "RecordCreatedAt": "2026-08-05T08:04:06.868Z",
    "RecordModifiedAt": "2026-08-05T08:04:06.868Z",
    "RecordExpiredAt": null,
    "RecordVersion": "9000000002"
  },
  {
    "InventoryFlightId": "AC-8023-2026-11-17",
    "InventoryPlaceId": "YUL_2",
    "PlaceIATACode": "YUL",
    "PlaceCityCode": "YUL",
    "CountryCode": "CA",
    "InventoryPlaceRegionCode": "NAMER",
    "InventoryPlaceContinentCode": "ITC1",
    "LocalScheduledDepartureAt": null,
    "LocalScheduledArrivalAt": "2026-11-17T05:00:00.000Z",
    "LocalEstimatedOffBlockAt": null,
    "LocalEstimatedTakeOffAt": null,
    "LocalEstimatedTouchdownAt": null,
    "LocalEstimatedOnBlockAt": null,
    "LocalActualOffBlockAt": null,
    "LocalActualTakeOffAt": null,
    "LocalActualTouchdownAt": null,
    "LocalActualOnBlockAt": null,
    "Terminals": [
      {
        "code": "1"
      }
    ],
    "RecordCorrelationId": "01KZ8F702M52Q17Q2TH31FJCTY",
    "RecordCreatedAt": "2026-08-05T08:04:06.868Z",
    "RecordModifiedAt": "2026-08-05T08:04:06.868Z",
    "RecordExpiredAt": null,
    "RecordVersion": "9000000002"
  }
]
```

### Query 2: InventoryFlight after NEWER event (version=9000000002)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8023-2026-11-17"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8023-2026-11-17",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8023",
    "OperatingNumber": "8023",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-16T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8F702M52Q17Q2TH31FJCTY",
    "RecordCreatedAt": "2026-08-05T08:04:06.868Z",
    "RecordModifiedAt": "2026-08-05T08:04:06.868Z",
    "RecordExpiredAt": null,
    "RecordVersion": "9000000002"
  }
]
```

### Query 3: FlightState after NEWER event
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT 
      "OperatingCarrierCode",
      "OperatingFlightNumber",
      "DepartureAirportIATACode",
      "ArrivalAirportIATACode",
      "LocalDepartureScheduledDate",
      "CurrentFlightAcceptanceStatusCode",
      "CurrentFlightGeneralStatusCode",
      "CurrentFlightLoadControlStatusCode",
      "CurrentFlightBoardingStatusCode",
      "PreviousFlightAcceptanceStatusCode",
      "PreviousFlightGeneralStatusCode",
      "PreviousFlightLoadControlStatusCode",
      "PreviousFlightBoardingStatusCode",
      "UTCFlightAcceptanceStatusModifiedAt",
      "UTCFlightGeneralStatusModifiedAt",
      "UTCFlightLoadControlStatusModifiedAt",
      "UTCFlightBoardingStatusModifiedAt",
      "RecordCreatedAt",
      "RecordModifiedAt",
      "RecordVersion",
      "SourceCreatedBy"
    FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8023","YYZ","2026-11-17"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8023",
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YUL",
    "LocalDepartureScheduledDate": "2026-11-16T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T08:04:06.868Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T08:04:06.868Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T08:04:06.868Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T08:04:06.868Z",
    "RecordCreatedAt": "2026-08-05T08:04:06.868Z",
    "RecordModifiedAt": "2026-08-05T08:04:06.868Z",
    "RecordVersion": "9000000002",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

### Query 4: InventoryFlightPlace after STALE event (should still be terminal=5)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightPlace" WHERE "InventoryFlightId" = $1
```
**Parameters:** ["AC-8023-2026-11-17"]
**Row Count:** 2
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8023-2026-11-17",
    "InventoryPlaceId": "YYZ_1",
    "PlaceIATACode": "YYZ",
    "PlaceCityCode": "YYZ",
    "CountryCode": "CA",
    "InventoryPlaceRegionCode": "NAMER",
    "InventoryPlaceContinentCode": "ITC1",
    "LocalScheduledDepartureAt": "2026-11-17T02:30:00.000Z",
    "LocalScheduledArrivalAt": null,
    "LocalEstimatedOffBlockAt": null,
    "LocalEstimatedTakeOffAt": null,
    "LocalEstimatedTouchdownAt": null,
    "LocalEstimatedOnBlockAt": null,
    "LocalActualOffBlockAt": null,
    "LocalActualTakeOffAt": null,
    "LocalActualTouchdownAt": null,
    "LocalActualOnBlockAt": null,
    "Terminals": [
      {
        "code": "5"
      }
    ],
    "RecordCorrelationId": "01KZ8F702M52Q17Q2TH31FJCTY",
    "RecordCreatedAt": "2026-08-05T08:04:06.868Z",
    "RecordModifiedAt": "2026-08-05T08:04:06.868Z",
    "RecordExpiredAt": null,
    "RecordVersion": "9000000002"
  },
  {
    "InventoryFlightId": "AC-8023-2026-11-17",
    "InventoryPlaceId": "YUL_2",
    "PlaceIATACode": "YUL",
    "PlaceCityCode": "YUL",
    "CountryCode": "CA",
    "InventoryPlaceRegionCode": "NAMER",
    "InventoryPlaceContinentCode": "ITC1",
    "LocalScheduledDepartureAt": null,
    "LocalScheduledArrivalAt": "2026-11-17T05:00:00.000Z",
    "LocalEstimatedOffBlockAt": null,
    "LocalEstimatedTakeOffAt": null,
    "LocalEstimatedTouchdownAt": null,
    "LocalEstimatedOnBlockAt": null,
    "LocalActualOffBlockAt": null,
    "LocalActualTakeOffAt": null,
    "LocalActualTouchdownAt": null,
    "LocalActualOnBlockAt": null,
    "Terminals": [
      {
        "code": "1"
      }
    ],
    "RecordCorrelationId": "01KZ8F702M52Q17Q2TH31FJCTY",
    "RecordCreatedAt": "2026-08-05T08:04:06.868Z",
    "RecordModifiedAt": "2026-08-05T08:04:06.868Z",
    "RecordExpiredAt": null,
    "RecordVersion": "9000000002"
  }
]
```

### Query 5: InventoryFlight after STALE event (version should stay 9000000002)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8023-2026-11-17"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8023-2026-11-17",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8023",
    "OperatingNumber": "8023",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-16T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8F702M52Q17Q2TH31FJCTY",
    "RecordCreatedAt": "2026-08-05T08:04:06.868Z",
    "RecordModifiedAt": "2026-08-05T08:04:06.868Z",
    "RecordExpiredAt": null,
    "RecordVersion": "9000000002"
  }
]
```

### Query 6: FlightState after STALE event (check if version regressed)
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT 
      "OperatingCarrierCode",
      "OperatingFlightNumber",
      "DepartureAirportIATACode",
      "ArrivalAirportIATACode",
      "LocalDepartureScheduledDate",
      "CurrentFlightAcceptanceStatusCode",
      "CurrentFlightGeneralStatusCode",
      "CurrentFlightLoadControlStatusCode",
      "CurrentFlightBoardingStatusCode",
      "PreviousFlightAcceptanceStatusCode",
      "PreviousFlightGeneralStatusCode",
      "PreviousFlightLoadControlStatusCode",
      "PreviousFlightBoardingStatusCode",
      "UTCFlightAcceptanceStatusModifiedAt",
      "UTCFlightGeneralStatusModifiedAt",
      "UTCFlightLoadControlStatusModifiedAt",
      "UTCFlightBoardingStatusModifiedAt",
      "RecordCreatedAt",
      "RecordModifiedAt",
      "RecordVersion",
      "SourceCreatedBy"
    FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8023","YYZ","2026-11-17"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8023",
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YUL",
    "LocalDepartureScheduledDate": "2026-11-16T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T08:04:06.868Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T08:04:06.868Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T08:04:06.868Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T08:04:06.868Z",
    "RecordCreatedAt": "2026-08-05T08:04:06.868Z",
    "RecordModifiedAt": "2026-08-05T08:04:11.269Z",
    "RecordVersion": "9000000001",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

## Assertions

✅ **Lambda handled stale event without crash (200)**: ✅ PASS
✅ **CustomerDataMart: InventoryFlight.RecordVersion NOT regressed (version protection works)**: ✅ PASS
✅ **CustomerDataMart: Terminals still "5" (stale terminal=1 rejected)**: ✅ PASS
✅ **⚠️ FINDING: FlightState.RecordVersion REGRESSED (no version protection — last-write-wins)**: ✅ PASS
✅ **⚠️ FINDING: FlightState uses last-write-wins, NOT version-based upsert**: ✅ PASS

---
## Final Verdict: ✅ PASSED