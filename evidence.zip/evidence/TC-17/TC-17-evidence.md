# TC-17 - Validate leap year date handling (Feb 29)

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T07:47:58.790Z
**Result:** ✅ PASSED
**Duration:** 9566ms

## Test Description
Valid: 2028-02-29 (leap year) should persist correctly. Invalid: 2026-02-29 (non-leap year) — verify writer or DB rejects.

## Payload Sent to Lambda
```json
{
  "validPayload": {
    "meta": {
      "triggerEventLog": {
        "id": "tc-1785916072755-14j20kpu3"
      },
      "version": "1.3.0"
    },
    "scheduleProcessedFlight": {
      "type": "dated-flight",
      "id": "AC-8017-2028-02-29",
      "version": "1785916072755949902",
      "flightDesignator": {
        "carrierCode": "AC",
        "flightNumber": "8017"
      },
      "scheduledDepartureDate": "2028-02-29",
      "dayOfOperation": "WED",
      "isCancelled": false,
      "characteristics": [
        "DOMESTIC"
      ],
      "codeshare": "OPERATING",
      "flightPoints": [
        {
          "id": "YYZ_1",
          "iataCode": "YYZ",
          "city": "YYZ",
          "country": "CA",
          "region": "NAMER",
          "continent": "ITC1",
          "departure": {
            "timings": [
              {
                "qualifier": "STD",
                "value": "2028-02-29T08:00:00"
              }
            ],
            "terminals": [
              {
                "code": "1"
              }
            ]
          }
        },
        {
          "id": "YUL_2",
          "iataCode": "YUL",
          "city": "YUL",
          "country": "CA",
          "region": "NAMER",
          "continent": "ITC1",
          "arrival": {
            "timings": [
              {
                "qualifier": "STA",
                "value": "2028-02-29T10:30:00"
              }
            ],
            "terminals": [
              {
                "code": "1"
              }
            ]
          }
        }
      ],
      "segments": [
        {
          "id": "2028-02-29-YYZ-YUL",
          "boardFlightPointId": "YYZ_1",
          "offFlightPointId": "YUL_2",
          "boardPointIataCode": "YYZ",
          "offPointIataCode": "YUL",
          "scheduledDepartureDateTime": "2028-02-29T08:00:00",
          "scheduledDepartureDateTimeUtc": "2028-02-29T12:00:00Z",
          "scheduledArrivalDateTime": "2028-02-29T10:30:00",
          "scheduledArrivalDateTimeUtc": "2028-02-29T14:30:00Z",
          "numberOfLegs": 1,
          "legIds": [
            "YYZ-YUL"
          ]
        }
      ],
      "legs": [
        {
          "id": "YYZ-YUL",
          "boardFlightPointId": "YYZ_1",
          "offFlightPointId": "YUL_2",
          "boardPointIataCode": "YYZ",
          "offPointIataCode": "YUL",
          "scheduledDepartureDateTime": "2028-02-29T08:00:00",
          "scheduledDepartureDateTimeUtc": "2028-02-29T12:00:00Z",
          "scheduledArrivalDateTime": "2028-02-29T10:30:00",
          "scheduledArrivalDateTimeUtc": "2028-02-29T14:30:00Z",
          "routingOrder": 1,
          "serviceType": "J",
          "aircraftEquipment": {
            "aircraftType": "320",
            "scheduledFittedConfiguration": {
              "code": "321",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            },
            "acvTotalCapacity": 170,
            "operationalSaleableConfiguration": {
              "code": "001",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            },
            "scheduledSaleableConfiguration": {
              "code": "001",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            },
            "operationalFittedConfiguration": {
              "code": "321",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            }
          },
          "legDCSStatuses": {
            "acceptanceStatus": "OPEN",
            "generalStatus": "OPEN",
            "loadControlStatus": "OPEN",
            "boardingStatus": "NOT_OPEN"
          }
        }
      ]
    },
    "events": {
      "recordDomain": "SCHEDULE",
      "recordId": "AC-8017-2028-02-29",
      "originFeedTimeStamp": "2026-08-05T07:47:52.755Z",
      "events": [
        {
          "origin": "COMPARISON",
          "eventType": "CREATED"
        }
      ]
    }
  },
  "invalidPayload": {
    "meta": {
      "triggerEventLog": {
        "id": "tc-1785916076161-rv0yqer8i"
      },
      "version": "1.3.0"
    },
    "scheduleProcessedFlight": {
      "type": "dated-flight",
      "id": "AC-8117-2026-02-29",
      "version": "1785916076161161567",
      "flightDesignator": {
        "carrierCode": "AC",
        "flightNumber": "8117"
      },
      "scheduledDepartureDate": "2026-02-29",
      "dayOfOperation": "WED",
      "isCancelled": false,
      "characteristics": [
        "DOMESTIC"
      ],
      "codeshare": "OPERATING",
      "flightPoints": [
        {
          "id": "YYZ_1",
          "iataCode": "YYZ",
          "city": "YYZ",
          "country": "CA",
          "region": "NAMER",
          "continent": "ITC1",
          "departure": {
            "timings": [
              {
                "qualifier": "STD",
                "value": "2026-02-29T08:00:00"
              }
            ],
            "terminals": [
              {
                "code": "1"
              }
            ]
          }
        },
        {
          "id": "YUL_2",
          "iataCode": "YUL",
          "city": "YUL",
          "country": "CA",
          "region": "NAMER",
          "continent": "ITC1",
          "arrival": {
            "timings": [
              {
                "qualifier": "STA",
                "value": "2026-02-29T10:30:00"
              }
            ],
            "terminals": [
              {
                "code": "1"
              }
            ]
          }
        }
      ],
      "segments": [
        {
          "id": "2026-02-29-YYZ-YUL",
          "boardFlightPointId": "YYZ_1",
          "offFlightPointId": "YUL_2",
          "boardPointIataCode": "YYZ",
          "offPointIataCode": "YUL",
          "scheduledDepartureDateTime": "2026-02-29T08:00:00",
          "scheduledDepartureDateTimeUtc": "2026-02-29T12:00:00Z",
          "scheduledArrivalDateTime": "2026-02-29T10:30:00",
          "scheduledArrivalDateTimeUtc": "2026-02-29T14:30:00Z",
          "numberOfLegs": 1,
          "legIds": [
            "YYZ-YUL"
          ]
        }
      ],
      "legs": [
        {
          "id": "YYZ-YUL",
          "boardFlightPointId": "YYZ_1",
          "offFlightPointId": "YUL_2",
          "boardPointIataCode": "YYZ",
          "offPointIataCode": "YUL",
          "scheduledDepartureDateTime": "2026-02-29T08:00:00",
          "scheduledDepartureDateTimeUtc": "2026-02-29T12:00:00Z",
          "scheduledArrivalDateTime": "2026-02-29T10:30:00",
          "scheduledArrivalDateTimeUtc": "2026-02-29T14:30:00Z",
          "routingOrder": 1,
          "serviceType": "J",
          "aircraftEquipment": {
            "aircraftType": "320",
            "scheduledFittedConfiguration": {
              "code": "321",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            },
            "acvTotalCapacity": 170,
            "operationalSaleableConfiguration": {
              "code": "001",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            },
            "scheduledSaleableConfiguration": {
              "code": "001",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            },
            "operationalFittedConfiguration": {
              "code": "321",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            }
          },
          "legDCSStatuses": {
            "acceptanceStatus": "OPEN",
            "generalStatus": "OPEN",
            "loadControlStatus": "OPEN",
            "boardingStatus": "NOT_OPEN"
          }
        }
      ]
    },
    "events": {
      "recordDomain": "SCHEDULE",
      "recordId": "AC-8117-2026-02-29",
      "originFeedTimeStamp": "2026-08-05T07:47:56.161Z",
      "events": [
        {
          "origin": "COMPARISON",
          "eventType": "CREATED"
        }
      ]
    }
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 4957 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** N/A
- **Function Error:** None
- **Invoked At:** N/A

## Database Verification

### Query 1: Leap year 2028-02-29 — InventoryFlight
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8017-2028-02-29"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8017-2028-02-29",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8017",
    "OperatingNumber": "8017",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2028-02-28T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8E9905WYMA184D5SK635YW",
    "RecordCreatedAt": "2026-08-05T07:47:52.966Z",
    "RecordModifiedAt": "2026-08-05T07:47:52.966Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785916072755949800"
  }
]
```

### Query 2: Leap year 2028-02-29 — FlightState
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8017","YYZ","2028-02-29"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8017",
    "OperationalSuffix": null,
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YUL",
    "LocalDepartureScheduledDate": "2028-02-28T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T07:47:52.966Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T07:47:52.966Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T07:47:52.966Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T07:47:52.966Z",
    "CurrentBagFlightLoadStatusCode": null,
    "PreviousBagFlightLoadStatusCode": null,
    "UTCBagFlightLoadStatusModifiedAt": null,
    "RecordCorrelationId": "01KZ8E9905WYMA184D5SK635YW",
    "RecordCreatedAt": "2026-08-05T07:47:52.966Z",
    "RecordModifiedAt": "2026-08-05T07:47:52.966Z",
    "RecordExpiredAt": "2027-08-05T07:47:52.966Z",
    "RecordVersion": "1785916072755949800",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

### Query 3: Non-leap 2026-02-29 — InventoryFlight
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8117-2026-02-29"]
**Row Count:** 0
**Results:**
```json
[]
```

## Assertions

✅ **Lambda 200 for valid leap year**: ✅ PASS
✅ **Leap year 2028-02-29 — InventoryFlight created**: ✅ PASS
✅ **Leap year 2028-02-29 — FlightState created**: ✅ PASS
✅ **Lambda handled non-leap 2026-02-29 (no crash)**: ✅ PASS
✅ **Non-leap 2026-02-29 rejected (DB date constraint)**: ✅ PASS

---
## Final Verdict: ✅ PASSED