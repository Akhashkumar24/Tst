# TC-18 - Verify carrier/airport code case normalization at writer level

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T07:48:08.586Z
**Result:** ✅ PASSED
**Duration:** 9791ms

## Test Description
Ingest with lowercase 'ac'/'yyz'. Verify whether writer normalizes to uppercase or stores as-is. Document actual normalization behavior.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785916085026-py0m8ovno"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "ac-8018-2026-11-16",
    "version": "1785916085026721109",
    "flightDesignator": {
      "carrierCode": "ac",
      "flightNumber": "8018"
    },
    "scheduledDepartureDate": "2026-11-16",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "yyz_1",
        "iataCode": "yyz",
        "city": "yyz",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-16T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "yul_2",
        "iataCode": "yul",
        "city": "yul",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-16T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-16-yyz-yul",
        "boardFlightPointId": "yyz_1",
        "offFlightPointId": "yul_2",
        "boardPointIataCode": "yyz",
        "offPointIataCode": "yul",
        "scheduledDepartureDateTime": "2026-11-16T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-16T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-16T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "yyz-yul"
        ]
      }
    ],
    "legs": [
      {
        "id": "yyz-yul",
        "boardFlightPointId": "yyz_1",
        "offFlightPointId": "yul_2",
        "boardPointIataCode": "yyz",
        "offPointIataCode": "yul",
        "scheduledDepartureDateTime": "2026-11-16T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-16T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-16T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "ac-8018-2026-11-16",
    "originFeedTimeStamp": "2026-08-05T07:48:05.026Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2461 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T07:48:05.027Z

## Database Verification

### Query 1: Uppercase key AC-8018 — InventoryFlight
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8018-2026-11-16"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8018-2026-11-16",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8018",
    "OperatingNumber": "8018",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-15T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8E9JKGG0HTQ2GWK5X3E09S",
    "RecordCreatedAt": "2026-08-05T07:48:02.800Z",
    "RecordModifiedAt": "2026-08-05T07:48:02.800Z",
    "RecordExpiredAt": null,
    "RecordVersion": "178591608261681400"
  }
]
```

### Query 2: Lowercase key ac-8018 — InventoryFlight
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["ac-8018-2026-11-16"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "ac-8018-2026-11-16",
    "MarketingCarrierCode": "ac",
    "OperatingCarrierCode": "ac",
    "MarketingNumber": "8018",
    "OperatingNumber": "8018",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-15T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8E9MYTVFVQZM6B0C8Y7DZJ",
    "RecordCreatedAt": "2026-08-05T07:48:05.210Z",
    "RecordModifiedAt": "2026-08-05T07:48:05.210Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785916085026721000"
  }
]
```

### Query 3: FlightState uppercase lookup (AC/YYZ)
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8018","YYZ","2026-11-16"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8018",
    "OperationalSuffix": null,
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YUL",
    "LocalDepartureScheduledDate": "2026-11-15T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T07:48:02.800Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T07:48:02.800Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T07:48:02.800Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T07:48:02.800Z",
    "CurrentBagFlightLoadStatusCode": null,
    "PreviousBagFlightLoadStatusCode": null,
    "UTCBagFlightLoadStatusModifiedAt": null,
    "RecordCorrelationId": "01KZ8E9JKGG0HTQ2GWK5X3E09S",
    "RecordCreatedAt": "2026-08-05T07:48:02.800Z",
    "RecordModifiedAt": "2026-08-05T07:48:02.800Z",
    "RecordExpiredAt": "2027-08-05T07:48:02.800Z",
    "RecordVersion": "178591608261681400",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

### Query 4: FlightState lowercase lookup (ac/yyz)
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["ac","8018","yyz","2026-11-16"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "ac",
    "OperatingFlightNumber": "8018",
    "OperationalSuffix": null,
    "DepartureAirportIATACode": "yyz",
    "ArrivalAirportIATACode": "yul",
    "LocalDepartureScheduledDate": "2026-11-15T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T07:48:05.210Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T07:48:05.210Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T07:48:05.210Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T07:48:05.210Z",
    "CurrentBagFlightLoadStatusCode": null,
    "PreviousBagFlightLoadStatusCode": null,
    "UTCBagFlightLoadStatusModifiedAt": null,
    "RecordCorrelationId": "01KZ8E9MYTVFVQZM6B0C8Y7DZJ",
    "RecordCreatedAt": "2026-08-05T07:48:05.210Z",
    "RecordModifiedAt": "2026-08-05T07:48:05.210Z",
    "RecordExpiredAt": "2027-08-05T07:48:05.210Z",
    "RecordVersion": "1785916085026721000",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

## Assertions

✅ **Lambda 200 for uppercase input**: ✅ PASS
✅ **Lambda 200 for lowercase input**: ✅ PASS
✅ **No normalization — separate records for AC-8018 and ac-8018**: ✅ PASS
✅ **FlightState records exist (at least one lookup finds data)**: ✅ PASS

---
## Final Verdict: ✅ PASSED