# TC-54 - Validate scheduledFittedConfiguration type variants map to the correct configuration type columns

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T16:01:20.465Z
**Result:** ✅ PASSED
**Duration:** 9215ms

## Test Description
Ingest one event with all 4 configuration types populated with distinct codes and capacities. Verify each maps to its correct column pair in BookingInventoryDataStore.InventoryFlightLeg: ScheduledFitted, OperationalFitted, ScheduledSaleable, OperationalSaleable.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785945673724-gcbng0ne3"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8054-2026-11-21",
    "version": "540001",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8054"
    },
    "scheduledDepartureDate": "2026-11-21",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-21T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YUL_2",
        "iataCode": "YUL",
        "city": "YUL",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-21T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-21-YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-21T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-21T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-21T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-21T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YUL"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-21T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-21T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-21T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-21T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "acvTotalCapacity": 170,
          "scheduledFittedConfiguration": {
            "code": "SF1",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 10
              },
              {
                "cabin": "Y",
                "capacity": 100
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "OF2",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 12
              },
              {
                "cabin": "Y",
                "capacity": 110
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "SS3",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 120
              }
            ]
          },
          "operationalSaleableConfiguration": {
            "code": "OS4",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 130
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8054-2026-11-21",
    "originFeedTimeStamp": "2026-08-05T16:01:13.725Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2448 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T16:01:13.726Z

## Database Verification

### Query 1: InventoryFlightLeg (all 4 config types)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8054-2026-11-21"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8054-2026-11-21",
    "Id": "YYZ-YUL",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8054",
    "OperatingNumber": "8054",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YUL_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YUL",
    "LocalDepartureScheduleAt": "2026-11-21T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-21T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-21T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-21T14:30:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "320",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 170,
    "ScheduledFittedAircraftConfigurationCode": "SF1",
    "ScheduledFittedBusinessSeatCapacity": 10,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 100,
    "OperationalSaleableAircraftConfigurationCode": "OS4",
    "OperationalSaleableBusinessSeatCapacity": 16,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 130,
    "ScheduledSaleableAircraftConfigurationCode": "SS3",
    "ScheduledSaleableBusinessSeatCapacity": 14,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 120,
    "OperationalFittedAircraftConfigurationCode": "OF2",
    "OperationalFittedBusinessSeatCapacity": 12,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 110,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T16:01:16.702Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T16:01:16.702Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T16:01:16.702Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T16:01:16.702Z",
    "RecordCorrelationId": "01KZ9AGPWYT7YRZFDBK7NA75NT",
    "RecordCreatedAt": "2026-08-05T16:01:16.702Z",
    "RecordModifiedAt": "2026-08-05T16:01:16.702Z",
    "RecordExpiredAt": null,
    "RecordVersion": "540001"
  }
]
```

### Query 2: InventoryFlight
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8054-2026-11-21"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8054-2026-11-21",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8054",
    "OperatingNumber": "8054",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-20T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ9AGPWYT7YRZFDBK7NA75NT",
    "RecordCreatedAt": "2026-08-05T16:01:16.702Z",
    "RecordModifiedAt": "2026-08-05T16:01:16.702Z",
    "RecordExpiredAt": null,
    "RecordVersion": "540001"
  }
]
```

## Assertions

✅ **Lambda success**: ✅ PASS
✅ **InventoryFlightLeg record exists**: ✅ PASS
✅ **ScheduledFittedAircraftConfigurationCode = SF1**: ✅ PASS
✅ **ScheduledFittedBusinessSeatCapacity = 10 (J cabin)**: ✅ PASS
✅ **ScheduledFittedEconomySeatCapacity = 100 (Y cabin)**: ✅ PASS
✅ **OperationalFittedAircraftConfigurationCode = OF2**: ✅ PASS
✅ **OperationalFittedBusinessSeatCapacity = 12 (J cabin)**: ✅ PASS
✅ **OperationalFittedEconomySeatCapacity = 110 (Y cabin)**: ✅ PASS
✅ **ScheduledSaleableAircraftConfigurationCode = SS3**: ✅ PASS
✅ **ScheduledSaleableBusinessSeatCapacity = 14 (J cabin)**: ✅ PASS
✅ **ScheduledSaleableEconomySeatCapacity = 120 (Y cabin)**: ✅ PASS
✅ **OperationalSaleableAircraftConfigurationCode = OS4**: ✅ PASS
✅ **OperationalSaleableBusinessSeatCapacity = 16 (J cabin)**: ✅ PASS
✅ **OperationalSaleableEconomySeatCapacity = 130 (Y cabin)**: ✅ PASS
✅ **No cross-mapping: OperationalFitted code ≠ ScheduledFitted code**: ✅ PASS
✅ **No cross-mapping: ScheduledSaleable code ≠ ScheduledFitted code**: ✅ PASS

---
## Final Verdict: ✅ PASSED