# TC-02 - Validate insert of a new flight record (upsert-insert)

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T07:31:20.930Z
**Result:** ✅ PASSED
**Duration:** 8156ms

## Test Description
Ingest event for a flight key not in DB, verify new record inserted with all fields correctly mapped.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785915072775-u046ttxkv"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8002-2026-11-15",
    "version": "1785915072775247293",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8002"
    },
    "scheduledDepartureDate": "2026-11-15",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YVR_1",
        "iataCode": "YVR",
        "city": "YVR",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-15T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YYC_2",
        "iataCode": "YYC",
        "city": "YYC",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-15T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-15-YVR-YYC",
        "boardFlightPointId": "YVR_1",
        "offFlightPointId": "YYC_2",
        "boardPointIataCode": "YVR",
        "offPointIataCode": "YYC",
        "scheduledDepartureDateTime": "2026-11-15T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-15T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-15T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-15T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YVR-YYC"
        ]
      }
    ],
    "legs": [
      {
        "id": "YVR-YYC",
        "boardFlightPointId": "YVR_1",
        "offFlightPointId": "YYC_2",
        "boardPointIataCode": "YVR",
        "offPointIataCode": "YYC",
        "scheduledDepartureDateTime": "2026-11-15T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-15T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-15T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-15T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8002-2026-11-15",
    "originFeedTimeStamp": "2026-08-05T07:31:12.775Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2461 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T07:31:15.189Z

## Database Verification

### Query 1: Pre-check InventoryFlight (should be empty)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8002-2026-11-15"]
**Row Count:** 0
**Results:**
```json
[]
```

### Query 2: Post-ingest InventoryFlight
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8002-2026-11-15"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8002-2026-11-15",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8002",
    "OperatingNumber": "8002",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-14T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8DAVEFXKN92XRYNFFS7Y31",
    "RecordCreatedAt": "2026-08-05T07:31:16.067Z",
    "RecordModifiedAt": "2026-08-05T07:31:16.067Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785915072775247400"
  }
]
```

### Query 3: Post-ingest InventoryFlightLeg
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8002-2026-11-15"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8002-2026-11-15",
    "Id": "YVR-YYC",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8002",
    "OperatingNumber": "8002",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YVR_1",
    "OffInventoryPlaceId": "YYC_2",
    "BoardPlaceIATACode": "YVR",
    "OffPlaceIATACode": "YYC",
    "LocalDepartureScheduleAt": "2026-11-15T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-15T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-15T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-15T14:30:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "320",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 170,
    "ScheduledFittedAircraftConfigurationCode": "321",
    "ScheduledFittedBusinessSeatCapacity": 14,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 156,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 14,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 156,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 14,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 156,
    "OperationalFittedAircraftConfigurationCode": "321",
    "OperationalFittedBusinessSeatCapacity": 14,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 156,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T07:31:16.067Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T07:31:16.067Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T07:31:16.067Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T07:31:16.067Z",
    "RecordCorrelationId": "01KZ8DAVEFXKN92XRYNFFS7Y31",
    "RecordCreatedAt": "2026-08-05T07:31:16.067Z",
    "RecordModifiedAt": "2026-08-05T07:31:16.067Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785915072775247400"
  }
]
```

### Query 4: FlightState
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8002","YVR","2026-11-15"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8002",
    "OperationalSuffix": null,
    "DepartureAirportIATACode": "YVR",
    "ArrivalAirportIATACode": "YYC",
    "LocalDepartureScheduledDate": "2026-11-14T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T07:31:16.067Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T07:31:16.067Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T07:31:16.067Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T07:31:16.067Z",
    "CurrentBagFlightLoadStatusCode": null,
    "PreviousBagFlightLoadStatusCode": null,
    "UTCBagFlightLoadStatusModifiedAt": null,
    "RecordCorrelationId": "01KZ8DAVEFXKN92XRYNFFS7Y31",
    "RecordCreatedAt": "2026-08-05T07:31:16.067Z",
    "RecordModifiedAt": "2026-08-05T07:31:16.067Z",
    "RecordExpiredAt": "2027-08-05T07:31:16.067Z",
    "RecordVersion": "1785915072775247400",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

## Assertions

✅ **No record before ingestion**: ✅ PASS
✅ **Lambda success**: ✅ PASS
✅ **Record inserted after ingestion**: ✅ PASS
✅ **Leg inserted**: ✅ PASS
✅ **FlightState inserted**: ✅ PASS
✅ **FlightState.OperatingCarrierCode=AC**: ✅ PASS
✅ **FlightState.DepartureAirportIATACode=YVR**: ✅ PASS
✅ **FlightState.ArrivalAirportIATACode=YYC**: ✅ PASS

---
## Final Verdict: ✅ PASSED