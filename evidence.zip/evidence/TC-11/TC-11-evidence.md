# TC-11 - Verify flight number format handling at writer level

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T07:45:47.735Z
**Result:** ✅ PASSED
**Duration:** 13570ms

## Test Description
Writer does not validate flight number format. Valid '835' persists. 'ABCD' and '-835' are also accepted by writer. Documents actual behavior.

## Payload Sent to Lambda
```json
{
  "validPayload": {
    "meta": {
      "triggerEventLog": {
        "id": "tc-1785915939073-prp3tripe"
      },
      "version": "1.3.0"
    },
    "scheduleProcessedFlight": {
      "type": "dated-flight",
      "id": "AC-835-2026-11-16",
      "version": "1785915939073293269",
      "flightDesignator": {
        "carrierCode": "AC",
        "flightNumber": "835"
      },
      "scheduledDepartureDate": "2026-11-16",
      "dayOfOperation": "WED",
      "isCancelled": false,
      "characteristics": [
        "DOMESTIC"
      ],
      "codeshare": "OPERATING",
      "flightPoints": [
        {
          "id": "YYZ_1",
          "iataCode": "YYZ",
          "city": "YYZ",
          "country": "CA",
          "region": "NAMER",
          "continent": "ITC1",
          "departure": {
            "timings": [
              {
                "qualifier": "STD",
                "value": "2026-11-16T08:00:00"
              }
            ],
            "terminals": [
              {
                "code": "1"
              }
            ]
          }
        },
        {
          "id": "YUL_2",
          "iataCode": "YUL",
          "city": "YUL",
          "country": "CA",
          "region": "NAMER",
          "continent": "ITC1",
          "arrival": {
            "timings": [
              {
                "qualifier": "STA",
                "value": "2026-11-16T10:30:00"
              }
            ],
            "terminals": [
              {
                "code": "1"
              }
            ]
          }
        }
      ],
      "segments": [
        {
          "id": "2026-11-16-YYZ-YUL",
          "boardFlightPointId": "YYZ_1",
          "offFlightPointId": "YUL_2",
          "boardPointIataCode": "YYZ",
          "offPointIataCode": "YUL",
          "scheduledDepartureDateTime": "2026-11-16T08:00:00",
          "scheduledDepartureDateTimeUtc": "2026-11-16T12:00:00Z",
          "scheduledArrivalDateTime": "2026-11-16T10:30:00",
          "scheduledArrivalDateTimeUtc": "2026-11-16T14:30:00Z",
          "numberOfLegs": 1,
          "legIds": [
            "YYZ-YUL"
          ]
        }
      ],
      "legs": [
        {
          "id": "YYZ-YUL",
          "boardFlightPointId": "YYZ_1",
          "offFlightPointId": "YUL_2",
          "boardPointIataCode": "YYZ",
          "offPointIataCode": "YUL",
          "scheduledDepartureDateTime": "2026-11-16T08:00:00",
          "scheduledDepartureDateTimeUtc": "2026-11-16T12:00:00Z",
          "scheduledArrivalDateTime": "2026-11-16T10:30:00",
          "scheduledArrivalDateTimeUtc": "2026-11-16T14:30:00Z",
          "routingOrder": 1,
          "serviceType": "J",
          "aircraftEquipment": {
            "aircraftType": "320",
            "scheduledFittedConfiguration": {
              "code": "321",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            },
            "acvTotalCapacity": 170,
            "operationalSaleableConfiguration": {
              "code": "001",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            },
            "scheduledSaleableConfiguration": {
              "code": "001",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            },
            "operationalFittedConfiguration": {
              "code": "321",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            }
          },
          "legDCSStatuses": {
            "acceptanceStatus": "OPEN",
            "generalStatus": "OPEN",
            "loadControlStatus": "OPEN",
            "boardingStatus": "NOT_OPEN"
          }
        }
      ]
    },
    "events": {
      "recordDomain": "SCHEDULE",
      "recordId": "AC-835-2026-11-16",
      "originFeedTimeStamp": "2026-08-05T07:45:39.074Z",
      "events": [
        {
          "origin": "COMPARISON",
          "eventType": "CREATED"
        }
      ]
    }
  },
  "invalidPayloads": [
    {
      "meta": {
        "triggerEventLog": {
          "id": "tc-1785915942109-oz81xq7ov"
        },
        "version": "1.3.0"
      },
      "scheduleProcessedFlight": {
        "type": "dated-flight",
        "id": "AC-ABCD-2026-11-16",
        "version": "1785915942109570987",
        "flightDesignator": {
          "carrierCode": "AC",
          "flightNumber": "ABCD"
        },
        "scheduledDepartureDate": "2026-11-16",
        "dayOfOperation": "WED",
        "isCancelled": false,
        "characteristics": [
          "DOMESTIC"
        ],
        "codeshare": "OPERATING",
        "flightPoints": [
          {
            "id": "YYZ_1",
            "iataCode": "YYZ",
            "city": "YYZ",
            "country": "CA",
            "region": "NAMER",
            "continent": "ITC1",
            "departure": {
              "timings": [
                {
                  "qualifier": "STD",
                  "value": "2026-11-16T08:00:00"
                }
              ],
              "terminals": [
                {
                  "code": "1"
                }
              ]
            }
          },
          {
            "id": "YUL_2",
            "iataCode": "YUL",
            "city": "YUL",
            "country": "CA",
            "region": "NAMER",
            "continent": "ITC1",
            "arrival": {
              "timings": [
                {
                  "qualifier": "STA",
                  "value": "2026-11-16T10:30:00"
                }
              ],
              "terminals": [
                {
                  "code": "1"
                }
              ]
            }
          }
        ],
        "segments": [
          {
            "id": "2026-11-16-YYZ-YUL",
            "boardFlightPointId": "YYZ_1",
            "offFlightPointId": "YUL_2",
            "boardPointIataCode": "YYZ",
            "offPointIataCode": "YUL",
            "scheduledDepartureDateTime": "2026-11-16T08:00:00",
            "scheduledDepartureDateTimeUtc": "2026-11-16T12:00:00Z",
            "scheduledArrivalDateTime": "2026-11-16T10:30:00",
            "scheduledArrivalDateTimeUtc": "2026-11-16T14:30:00Z",
            "numberOfLegs": 1,
            "legIds": [
              "YYZ-YUL"
            ]
          }
        ],
        "legs": [
          {
            "id": "YYZ-YUL",
            "boardFlightPointId": "YYZ_1",
            "offFlightPointId": "YUL_2",
            "boardPointIataCode": "YYZ",
            "offPointIataCode": "YUL",
            "scheduledDepartureDateTime": "2026-11-16T08:00:00",
            "scheduledDepartureDateTimeUtc": "2026-11-16T12:00:00Z",
            "scheduledArrivalDateTime": "2026-11-16T10:30:00",
            "scheduledArrivalDateTimeUtc": "2026-11-16T14:30:00Z",
            "routingOrder": 1,
            "serviceType": "J",
            "aircraftEquipment": {
              "aircraftType": "320",
              "scheduledFittedConfiguration": {
                "code": "321",
                "configurationContents": [
                  {
                    "cabin": "J",
                    "capacity": 14
                  },
                  {
                    "cabin": "Y",
                    "capacity": 156
                  }
                ]
              },
              "acvTotalCapacity": 170,
              "operationalSaleableConfiguration": {
                "code": "001",
                "configurationContents": [
                  {
                    "cabin": "J",
                    "capacity": 14
                  },
                  {
                    "cabin": "Y",
                    "capacity": 156
                  }
                ]
              },
              "scheduledSaleableConfiguration": {
                "code": "001",
                "configurationContents": [
                  {
                    "cabin": "J",
                    "capacity": 14
                  },
                  {
                    "cabin": "Y",
                    "capacity": 156
                  }
                ]
              },
              "operationalFittedConfiguration": {
                "code": "321",
                "configurationContents": [
                  {
                    "cabin": "J",
                    "capacity": 14
                  },
                  {
                    "cabin": "Y",
                    "capacity": 156
                  }
                ]
              }
            },
            "legDCSStatuses": {
              "acceptanceStatus": "OPEN",
              "generalStatus": "OPEN",
              "loadControlStatus": "OPEN",
              "boardingStatus": "NOT_OPEN"
            }
          }
        ]
      },
      "events": {
        "recordDomain": "SCHEDULE",
        "recordId": "AC-ABCD-2026-11-16",
        "originFeedTimeStamp": "2026-08-05T07:45:42.109Z",
        "events": [
          {
            "origin": "COMPARISON",
            "eventType": "CREATED"
          }
        ]
      }
    },
    {
      "meta": {
        "triggerEventLog": {
          "id": "tc-1785915944896-h6re9tytc"
        },
        "version": "1.3.0"
      },
      "scheduleProcessedFlight": {
        "type": "dated-flight",
        "id": "AC--835-2026-11-16",
        "version": "1785915944896858347",
        "flightDesignator": {
          "carrierCode": "AC",
          "flightNumber": "-835"
        },
        "scheduledDepartureDate": "2026-11-16",
        "dayOfOperation": "WED",
        "isCancelled": false,
        "characteristics": [
          "DOMESTIC"
        ],
        "codeshare": "OPERATING",
        "flightPoints": [
          {
            "id": "YYZ_1",
            "iataCode": "YYZ",
            "city": "YYZ",
            "country": "CA",
            "region": "NAMER",
            "continent": "ITC1",
            "departure": {
              "timings": [
                {
                  "qualifier": "STD",
                  "value": "2026-11-16T08:00:00"
                }
              ],
              "terminals": [
                {
                  "code": "1"
                }
              ]
            }
          },
          {
            "id": "YUL_2",
            "iataCode": "YUL",
            "city": "YUL",
            "country": "CA",
            "region": "NAMER",
            "continent": "ITC1",
            "arrival": {
              "timings": [
                {
                  "qualifier": "STA",
                  "value": "2026-11-16T10:30:00"
                }
              ],
              "terminals": [
                {
                  "code": "1"
                }
              ]
            }
          }
        ],
        "segments": [
          {
            "id": "2026-11-16-YYZ-YUL",
            "boardFlightPointId": "YYZ_1",
            "offFlightPointId": "YUL_2",
            "boardPointIataCode": "YYZ",
            "offPointIataCode": "YUL",
            "scheduledDepartureDateTime": "2026-11-16T08:00:00",
            "scheduledDepartureDateTimeUtc": "2026-11-16T12:00:00Z",
            "scheduledArrivalDateTime": "2026-11-16T10:30:00",
            "scheduledArrivalDateTimeUtc": "2026-11-16T14:30:00Z",
            "numberOfLegs": 1,
            "legIds": [
              "YYZ-YUL"
            ]
          }
        ],
        "legs": [
          {
            "id": "YYZ-YUL",
            "boardFlightPointId": "YYZ_1",
            "offFlightPointId": "YUL_2",
            "boardPointIataCode": "YYZ",
            "offPointIataCode": "YUL",
            "scheduledDepartureDateTime": "2026-11-16T08:00:00",
            "scheduledDepartureDateTimeUtc": "2026-11-16T12:00:00Z",
            "scheduledArrivalDateTime": "2026-11-16T10:30:00",
            "scheduledArrivalDateTimeUtc": "2026-11-16T14:30:00Z",
            "routingOrder": 1,
            "serviceType": "J",
            "aircraftEquipment": {
              "aircraftType": "320",
              "scheduledFittedConfiguration": {
                "code": "321",
                "configurationContents": [
                  {
                    "cabin": "J",
                    "capacity": 14
                  },
                  {
                    "cabin": "Y",
                    "capacity": 156
                  }
                ]
              },
              "acvTotalCapacity": 170,
              "operationalSaleableConfiguration": {
                "code": "001",
                "configurationContents": [
                  {
                    "cabin": "J",
                    "capacity": 14
                  },
                  {
                    "cabin": "Y",
                    "capacity": 156
                  }
                ]
              },
              "scheduledSaleableConfiguration": {
                "code": "001",
                "configurationContents": [
                  {
                    "cabin": "J",
                    "capacity": 14
                  },
                  {
                    "cabin": "Y",
                    "capacity": 156
                  }
                ]
              },
              "operationalFittedConfiguration": {
                "code": "321",
                "configurationContents": [
                  {
                    "cabin": "J",
                    "capacity": 14
                  },
                  {
                    "cabin": "Y",
                    "capacity": 156
                  }
                ]
              }
            },
            "legDCSStatuses": {
              "acceptanceStatus": "OPEN",
              "generalStatus": "OPEN",
              "loadControlStatus": "OPEN",
              "boardingStatus": "NOT_OPEN"
            }
          }
        ]
      },
      "events": {
        "recordDomain": "SCHEDULE",
        "recordId": "AC--835-2026-11-16",
        "originFeedTimeStamp": "2026-08-05T07:45:44.896Z",
        "events": [
          {
            "origin": "COMPARISON",
            "eventType": "CREATED"
          }
        ]
      }
    }
  ]
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 7419 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** N/A
- **Function Error:** None
- **Invoked At:** N/A

## Database Verification

### Query 1: Valid flightNumber '835' — InventoryFlight
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-835-2026-11-16"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-835-2026-11-16",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "835",
    "OperatingNumber": "835",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-15T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8E56E706CSMPB3QS7YWM6R",
    "RecordCreatedAt": "2026-08-05T07:45:39.271Z",
    "RecordModifiedAt": "2026-08-05T07:45:39.271Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785915939073293300"
  }
]
```

### Query 2: Valid flightNumber '835' — FlightState
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","835","YYZ","2026-11-16"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "835",
    "OperationalSuffix": null,
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YUL",
    "LocalDepartureScheduledDate": "2026-11-15T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T07:45:39.271Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T07:45:39.271Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T07:45:39.271Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T07:45:39.271Z",
    "CurrentBagFlightLoadStatusCode": null,
    "PreviousBagFlightLoadStatusCode": null,
    "UTCBagFlightLoadStatusModifiedAt": null,
    "RecordCorrelationId": "01KZ8E56E706CSMPB3QS7YWM6R",
    "RecordCreatedAt": "2026-08-05T07:45:39.271Z",
    "RecordModifiedAt": "2026-08-05T07:45:39.271Z",
    "RecordExpiredAt": "2027-08-05T07:45:39.271Z",
    "RecordVersion": "1785915939073293300",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

### Query 3: FlightNumber 'ABCD' — InventoryFlight
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-ABCD-2026-11-16"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-ABCD-2026-11-16",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "ABCD",
    "OperatingNumber": "ABCD",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-15T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8E59D5DQYCVD5NCY3NEWFD",
    "RecordCreatedAt": "2026-08-05T07:45:42.309Z",
    "RecordModifiedAt": "2026-08-05T07:45:42.309Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785915942109571000"
  }
]
```

### Query 4: FlightNumber '-835' — InventoryFlight
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC--835-2026-11-16"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC--835-2026-11-16",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "-835",
    "OperatingNumber": "-835",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-15T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8E5C3KH0QPYTDJ9MYGJ0K9",
    "RecordCreatedAt": "2026-08-05T07:45:45.076Z",
    "RecordModifiedAt": "2026-08-05T07:45:45.076Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785915944896858400"
  }
]
```

## Assertions

✅ **Lambda 200 for valid flightNumber 835**: ✅ PASS
✅ **Valid flightNumber 835 — InventoryFlight created**: ✅ PASS
✅ **Valid flightNumber 835 — FlightState created**: ✅ PASS
✅ **Lambda 200 for 'ABCD' (no crash)**: ✅ PASS
✅ **Lambda 200 for '-835' (no crash)**: ✅ PASS
✅ **'ABCD' persistence documented**: ✅ PASS
✅ **'-835' persistence documented**: ✅ PASS

---
## Final Verdict: ✅ PASSED