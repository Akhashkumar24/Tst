# TC-68 - Validate codeshare/partnership update (add marketing flights)

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T10:25:58.100Z
**Result:** ✅ PASSED
**Duration:** 8418ms

## Test Description
Add marketing flight BR-3083, then add CX-1533. Verify both reflected in BookingInventoryDataStore.InventoryFlightSegmentAlias.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785925554334-k0ggxxwyk"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8068-2026-11-20",
    "version": "1785925554334177030",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8068"
    },
    "scheduledDepartureDate": "2026-11-20",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-20T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YVR_2",
        "iataCode": "YVR",
        "city": "YVR",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-20T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-20-YYZ-YVR",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YVR_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YVR",
        "scheduledDepartureDateTime": "2026-11-20T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-20T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-20T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-20T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YVR"
        ],
        "partnership": {
          "marketingFlights": [
            {
              "id": "BR-3083-2026-11-20",
              "flightDesignator": {
                "carrierCode": "BR",
                "flightNumber": "3083"
              }
            },
            {
              "id": "CX-1533-2026-11-20",
              "flightDesignator": {
                "carrierCode": "CX",
                "flightNumber": "1533"
              }
            }
          ]
        }
      }
    ],
    "legs": [
      {
        "id": "YYZ-YVR",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YVR_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YVR",
        "scheduledDepartureDateTime": "2026-11-20T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-20T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-20T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-20T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8068-2026-11-20",
    "originFeedTimeStamp": "2026-08-05T10:25:59.334Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "UPDATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2678 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T10:25:54.335Z

## Database Verification

### Query 1: InventoryFlightSegmentAlias after adding CX
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightSegmentAlias" WHERE "InventoryFlightId" = $1
```
**Parameters:** ["AC-8068-2026-11-20"]
**Row Count:** 2
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8068-2026-11-20",
    "InventoryFlightSegmentId": "2026-11-20-YYZ-YVR",
    "Id": "BR-3083-2026-11-20",
    "FlightLegAliasTypeCode": "MARKETING",
    "CarrierCode": "BR",
    "Number": "3083",
    "RecordCorrelationId": "01KZ8QAMAR5HTN8TRMDEGYRMQ2",
    "RecordCreatedAt": "2026-08-05T10:25:52.102Z",
    "RecordModifiedAt": "2026-08-05T10:25:54.520Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785925554334177000"
  },
  {
    "InventoryFlightId": "AC-8068-2026-11-20",
    "InventoryFlightSegmentId": "2026-11-20-YYZ-YVR",
    "Id": "CX-1533-2026-11-20",
    "FlightLegAliasTypeCode": "MARKETING",
    "CarrierCode": "CX",
    "Number": "1533",
    "RecordCorrelationId": "01KZ8QAMAR5HTN8TRMDEGYRMQ2",
    "RecordCreatedAt": "2026-08-05T10:25:54.520Z",
    "RecordModifiedAt": "2026-08-05T10:25:54.520Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785925554334177000"
  }
]
```

## Assertions

✅ **Lambda success**: ✅ PASS
✅ **2 marketing aliases exist**: ✅ PASS
✅ **Carriers are BR and CX**: ✅ PASS

---
## Final Verdict: ✅ PASSED