# TC-21 - Verify correct final state when two updates for same InventoryFlightLeg processed concurrently

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T15:33:51.299Z
**Result:** ✅ PASSED
**Duration:** 17599ms

## Test Description
Send two near-simultaneous leg updates (STD change + gate change). Verify single leg record remains and reflects latest version.

## Payload Sent to Lambda
```json
{
  "eventA": {
    "meta": {
      "triggerEventLog": {
        "id": "tc-1785944022348-37ol9hx0q"
      },
      "version": "1.3.0"
    },
    "scheduleProcessedFlight": {
      "type": "dated-flight",
      "id": "AC-8021-2026-11-17",
      "version": "2000000002",
      "flightDesignator": {
        "carrierCode": "AC",
        "flightNumber": "8021"
      },
      "scheduledDepartureDate": "2026-11-17",
      "dayOfOperation": "WED",
      "isCancelled": false,
      "characteristics": [
        "DOMESTIC"
      ],
      "codeshare": "OPERATING",
      "flightPoints": [
        {
          "id": "YYZ_1",
          "iataCode": "YYZ",
          "city": "YYZ",
          "country": "CA",
          "region": "NAMER",
          "continent": "ITC1",
          "departure": {
            "timings": [
              {
                "qualifier": "STD",
                "value": "2026-11-17T09:30:00"
              }
            ],
            "terminals": [
              {
                "code": "1"
              }
            ]
          }
        },
        {
          "id": "YUL_2",
          "iataCode": "YUL",
          "city": "YUL",
          "country": "CA",
          "region": "NAMER",
          "continent": "ITC1",
          "arrival": {
            "timings": [
              {
                "qualifier": "STA",
                "value": "2026-11-17T10:30:00"
              }
            ],
            "terminals": [
              {
                "code": "1"
              }
            ]
          }
        }
      ],
      "segments": [
        {
          "id": "2026-11-17-YYZ-YUL",
          "boardFlightPointId": "YYZ_1",
          "offFlightPointId": "YUL_2",
          "boardPointIataCode": "YYZ",
          "offPointIataCode": "YUL",
          "scheduledDepartureDateTime": "2026-11-17T09:30:00",
          "scheduledDepartureDateTimeUtc": "2026-11-17T12:00:00Z",
          "scheduledArrivalDateTime": "2026-11-17T10:30:00",
          "scheduledArrivalDateTimeUtc": "2026-11-17T14:30:00Z",
          "numberOfLegs": 1,
          "legIds": [
            "YYZ-YUL"
          ]
        }
      ],
      "legs": [
        {
          "id": "YYZ-YUL",
          "boardFlightPointId": "YYZ_1",
          "offFlightPointId": "YUL_2",
          "boardPointIataCode": "YYZ",
          "offPointIataCode": "YUL",
          "scheduledDepartureDateTime": "2026-11-17T09:30:00",
          "scheduledDepartureDateTimeUtc": "2026-11-17T12:00:00Z",
          "scheduledArrivalDateTime": "2026-11-17T10:30:00",
          "scheduledArrivalDateTimeUtc": "2026-11-17T14:30:00Z",
          "routingOrder": 1,
          "serviceType": "J",
          "aircraftEquipment": {
            "aircraftType": "320",
            "scheduledFittedConfiguration": {
              "code": "321",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            },
            "acvTotalCapacity": 170,
            "operationalSaleableConfiguration": {
              "code": "001",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            },
            "scheduledSaleableConfiguration": {
              "code": "001",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            },
            "operationalFittedConfiguration": {
              "code": "321",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            }
          },
          "legDCSStatuses": {
            "acceptanceStatus": "OPEN",
            "generalStatus": "OPEN",
            "loadControlStatus": "OPEN",
            "boardingStatus": "NOT_OPEN"
          }
        }
      ]
    },
    "events": {
      "recordDomain": "SCHEDULE",
      "recordId": "AC-8021-2026-11-17",
      "originFeedTimeStamp": "2026-08-05T15:33:43.348Z",
      "events": [
        {
          "origin": "COMPARISON",
          "eventType": "UPDATED"
        }
      ]
    }
  },
  "eventB": {
    "meta": {
      "triggerEventLog": {
        "id": "tc-1785944022348-87tz52bnk"
      },
      "version": "1.3.0"
    },
    "scheduleProcessedFlight": {
      "type": "dated-flight",
      "id": "AC-8021-2026-11-17",
      "version": "2000000003",
      "flightDesignator": {
        "carrierCode": "AC",
        "flightNumber": "8021"
      },
      "scheduledDepartureDate": "2026-11-17",
      "dayOfOperation": "WED",
      "isCancelled": false,
      "characteristics": [
        "DOMESTIC"
      ],
      "codeshare": "OPERATING",
      "flightPoints": [
        {
          "id": "YYZ_1",
          "iataCode": "YYZ",
          "city": "YYZ",
          "country": "CA",
          "region": "NAMER",
          "continent": "ITC1",
          "departure": {
            "timings": [
              {
                "qualifier": "STD",
                "value": "2026-11-17T09:30:00"
              }
            ],
            "terminals": [
              {
                "code": "7"
              }
            ]
          }
        },
        {
          "id": "YUL_2",
          "iataCode": "YUL",
          "city": "YUL",
          "country": "CA",
          "region": "NAMER",
          "continent": "ITC1",
          "arrival": {
            "timings": [
              {
                "qualifier": "STA",
                "value": "2026-11-17T10:30:00"
              }
            ],
            "terminals": [
              {
                "code": "1"
              }
            ]
          }
        }
      ],
      "segments": [
        {
          "id": "2026-11-17-YYZ-YUL",
          "boardFlightPointId": "YYZ_1",
          "offFlightPointId": "YUL_2",
          "boardPointIataCode": "YYZ",
          "offPointIataCode": "YUL",
          "scheduledDepartureDateTime": "2026-11-17T09:30:00",
          "scheduledDepartureDateTimeUtc": "2026-11-17T12:00:00Z",
          "scheduledArrivalDateTime": "2026-11-17T10:30:00",
          "scheduledArrivalDateTimeUtc": "2026-11-17T14:30:00Z",
          "numberOfLegs": 1,
          "legIds": [
            "YYZ-YUL"
          ]
        }
      ],
      "legs": [
        {
          "id": "YYZ-YUL",
          "boardFlightPointId": "YYZ_1",
          "offFlightPointId": "YUL_2",
          "boardPointIataCode": "YYZ",
          "offPointIataCode": "YUL",
          "scheduledDepartureDateTime": "2026-11-17T09:30:00",
          "scheduledDepartureDateTimeUtc": "2026-11-17T12:00:00Z",
          "scheduledArrivalDateTime": "2026-11-17T10:30:00",
          "scheduledArrivalDateTimeUtc": "2026-11-17T14:30:00Z",
          "routingOrder": 1,
          "serviceType": "J",
          "aircraftEquipment": {
            "aircraftType": "320",
            "scheduledFittedConfiguration": {
              "code": "321",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            },
            "acvTotalCapacity": 170,
            "operationalSaleableConfiguration": {
              "code": "001",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            },
            "scheduledSaleableConfiguration": {
              "code": "001",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            },
            "operationalFittedConfiguration": {
              "code": "321",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            }
          },
          "legDCSStatuses": {
            "acceptanceStatus": "OPEN",
            "generalStatus": "OPEN",
            "loadControlStatus": "OPEN",
            "boardingStatus": "NOT_OPEN"
          }
        }
      ]
    },
    "events": {
      "recordDomain": "SCHEDULE",
      "recordId": "AC-8021-2026-11-17",
      "originFeedTimeStamp": "2026-08-05T15:33:44.348Z",
      "events": [
        {
          "origin": "COMPARISON",
          "eventType": "UPDATED"
        }
      ]
    }
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 4925 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** N/A
- **Function Error:** None
- **Invoked At:** N/A

## Database Verification

### Query 1: InventoryFlightLeg after concurrent updates
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8021-2026-11-17"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8021-2026-11-17",
    "Id": "YYZ-YUL",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8021",
    "OperatingNumber": "8021",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YUL_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YUL",
    "LocalDepartureScheduleAt": "2026-11-17T04:00:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-17T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-17T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-17T14:30:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "320",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 170,
    "ScheduledFittedAircraftConfigurationCode": "321",
    "ScheduledFittedBusinessSeatCapacity": 14,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 156,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 14,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 156,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 14,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 156,
    "OperationalFittedAircraftConfigurationCode": "321",
    "OperationalFittedBusinessSeatCapacity": 14,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 156,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T15:33:39.094Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T15:33:39.094Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T15:33:39.094Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T15:33:39.094Z",
    "RecordCorrelationId": "01KZ98YA036580CXGJYW3AWART",
    "RecordCreatedAt": "2026-08-05T15:33:39.094Z",
    "RecordModifiedAt": "2026-08-05T15:33:45.091Z",
    "RecordExpiredAt": null,
    "RecordVersion": "2000000003"
  }
]
```

### Query 2: InventoryFlightPlace (Terminals jsonb)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightPlace" WHERE "InventoryFlightId" = $1
```
**Parameters:** ["AC-8021-2026-11-17"]
**Row Count:** 2
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8021-2026-11-17",
    "InventoryPlaceId": "YYZ_1",
    "PlaceIATACode": "YYZ",
    "PlaceCityCode": "YYZ",
    "CountryCode": "CA",
    "InventoryPlaceRegionCode": "NAMER",
    "InventoryPlaceContinentCode": "ITC1",
    "LocalScheduledDepartureAt": "2026-11-17T04:00:00.000Z",
    "LocalScheduledArrivalAt": null,
    "LocalEstimatedOffBlockAt": null,
    "LocalEstimatedTakeOffAt": null,
    "LocalEstimatedTouchdownAt": null,
    "LocalEstimatedOnBlockAt": null,
    "LocalActualOffBlockAt": null,
    "LocalActualTakeOffAt": null,
    "LocalActualTouchdownAt": null,
    "LocalActualOnBlockAt": null,
    "Terminals": [
      {
        "code": "7"
      }
    ],
    "RecordCorrelationId": "01KZ98YA036580CXGJYW3AWART",
    "RecordCreatedAt": "2026-08-05T15:33:39.094Z",
    "RecordModifiedAt": "2026-08-05T15:33:45.091Z",
    "RecordExpiredAt": null,
    "RecordVersion": "2000000003"
  },
  {
    "InventoryFlightId": "AC-8021-2026-11-17",
    "InventoryPlaceId": "YUL_2",
    "PlaceIATACode": "YUL",
    "PlaceCityCode": "YUL",
    "CountryCode": "CA",
    "InventoryPlaceRegionCode": "NAMER",
    "InventoryPlaceContinentCode": "ITC1",
    "LocalScheduledDepartureAt": null,
    "LocalScheduledArrivalAt": "2026-11-17T05:00:00.000Z",
    "LocalEstimatedOffBlockAt": null,
    "LocalEstimatedTakeOffAt": null,
    "LocalEstimatedTouchdownAt": null,
    "LocalEstimatedOnBlockAt": null,
    "LocalActualOffBlockAt": null,
    "LocalActualTakeOffAt": null,
    "LocalActualTouchdownAt": null,
    "LocalActualOnBlockAt": null,
    "Terminals": [
      {
        "code": "1"
      }
    ],
    "RecordCorrelationId": "01KZ98YA036580CXGJYW3AWART",
    "RecordCreatedAt": "2026-08-05T15:33:39.094Z",
    "RecordModifiedAt": "2026-08-05T15:33:45.091Z",
    "RecordExpiredAt": null,
    "RecordVersion": "2000000003"
  }
]
```

### Query 3: FlightState after concurrent updates
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8021","YYZ","2026-11-17"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8021",
    "OperationalSuffix": null,
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YUL",
    "LocalDepartureScheduledDate": "2026-11-16T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T15:33:39.094Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T15:33:39.094Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T15:33:39.094Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T15:33:39.094Z",
    "CurrentBagFlightLoadStatusCode": null,
    "PreviousBagFlightLoadStatusCode": null,
    "UTCBagFlightLoadStatusModifiedAt": null,
    "RecordCorrelationId": "01KZ98YA036580CXGJYW3AWART",
    "RecordCreatedAt": "2026-08-05T15:33:39.094Z",
    "RecordModifiedAt": "2026-08-05T15:33:45.091Z",
    "RecordExpiredAt": "2027-08-05T15:33:45.091Z",
    "RecordVersion": "2000000003",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

## Assertions

✅ **Both Lambdas returned 200**: ✅ PASS
✅ **Exactly 1 leg record (no dup)**: ✅ PASS
✅ **Leg RecordVersion reflects latest**: ✅ PASS

---
## Final Verdict: ✅ PASSED