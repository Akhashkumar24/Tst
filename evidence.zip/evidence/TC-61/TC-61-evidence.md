# TC-61 - Validate aircraft type change A320→A321 with seat config update

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T10:24:57.690Z
**Result:** ✅ PASSED
**Duration:** 9510ms

## Test Description
EquipmentTypeCode changes 320→321. Verify TotalSeatCapacity and cabin capacities updated.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785925493926-dpn1xxcqr"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8061-2026-11-20",
    "version": "1785925493926680450",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8061"
    },
    "scheduledDepartureDate": "2026-11-20",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-20T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YVR_2",
        "iataCode": "YVR",
        "city": "YVR",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-20T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-20-YYZ-YVR",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YVR_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YVR",
        "scheduledDepartureDateTime": "2026-11-20T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-20T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-20T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-20T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YVR"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-YVR",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YVR_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YVR",
        "scheduledDepartureDateTime": "2026-11-20T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-20T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-20T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-20T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "321",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 184
              }
            ]
          },
          "acvTotalCapacity": 200,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 184
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 184
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 184
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8061-2026-11-20",
    "originFeedTimeStamp": "2026-08-05T10:24:58.926Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "UPDATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2461 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T10:24:53.927Z

## Database Verification

### Query 1: InventoryFlightLeg after type change to 321
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8061-2026-11-20"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8061-2026-11-20",
    "Id": "YYZ-YVR",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8061",
    "OperatingNumber": "8061",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YVR_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YVR",
    "LocalDepartureScheduleAt": "2026-11-20T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-20T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-20T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-20T14:30:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "321",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 200,
    "ScheduledFittedAircraftConfigurationCode": "321",
    "ScheduledFittedBusinessSeatCapacity": 16,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 184,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 16,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 184,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 16,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 184,
    "OperationalFittedAircraftConfigurationCode": "321",
    "OperationalFittedBusinessSeatCapacity": 16,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 184,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T10:24:50.621Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T10:24:50.621Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T10:24:50.621Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T10:24:50.621Z",
    "RecordCorrelationId": "01KZ8Q8SBXXAA2Z8WCKNP69106",
    "RecordCreatedAt": "2026-08-05T10:24:50.621Z",
    "RecordModifiedAt": "2026-08-05T10:24:54.141Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785925493926680600"
  }
]
```

## Assertions

✅ **Lambda success**: ✅ PASS
✅ **Still 1 leg**: ✅ PASS
✅ **EquipmentTypeCode=321**: ✅ PASS
✅ **TotalSeatCapacity=200**: ✅ PASS

---
## Final Verdict: ✅ PASSED