# TC-71 - Validate ModifiedAt timestamp logic — only changed status timestamps update

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T10:26:35.348Z
**Result:** ✅ PASSED
**Duration:** 14026ms

## Test Description
Update1: gate change (no status change). Update2: acceptance→CLOSED. Verify UTCFlightGeneralStatusModifiedAt unchanged after both, UTCFlightAcceptanceStatusModifiedAt changes only after update2.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785925591259-7owz4entf"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8071-2026-11-20",
    "version": "1785925591259864068",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8071"
    },
    "scheduledDepartureDate": "2026-11-20",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-20T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "5"
            }
          ]
        }
      },
      {
        "id": "YUL_2",
        "iataCode": "YUL",
        "city": "YUL",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-20T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-20-YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-20T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-20T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-20T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-20T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YUL"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-20T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-20T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-20T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-20T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "CLOSED",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8071-2026-11-20",
    "originFeedTimeStamp": "2026-08-05T10:26:37.259Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "UPDATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2463 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T10:26:31.259Z

## Database Verification

### Query 1: FlightState initial
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT 
      "OperatingCarrierCode",
      "OperatingFlightNumber",
      "DepartureAirportIATACode",
      "ArrivalAirportIATACode",
      "LocalDepartureScheduledDate",
      "CurrentFlightAcceptanceStatusCode",
      "CurrentFlightGeneralStatusCode",
      "CurrentFlightLoadControlStatusCode",
      "CurrentFlightBoardingStatusCode",
      "PreviousFlightAcceptanceStatusCode",
      "PreviousFlightGeneralStatusCode",
      "PreviousFlightLoadControlStatusCode",
      "PreviousFlightBoardingStatusCode",
      "UTCFlightAcceptanceStatusModifiedAt",
      "UTCFlightGeneralStatusModifiedAt",
      "UTCFlightLoadControlStatusModifiedAt",
      "UTCFlightBoardingStatusModifiedAt",
      "RecordCreatedAt",
      "RecordModifiedAt",
      "RecordVersion",
      "SourceCreatedBy"
    FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8071","YYZ","2026-11-20"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8071",
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YUL",
    "LocalDepartureScheduledDate": "2026-11-19T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T10:26:24.004Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T10:26:24.004Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T10:26:24.004Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T10:26:24.004Z",
    "RecordCreatedAt": "2026-08-05T10:26:24.004Z",
    "RecordModifiedAt": "2026-08-05T10:26:24.004Z",
    "RecordVersion": "1785925583820417500",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

### Query 2: FlightState after gate change (status unchanged)
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT 
      "OperatingCarrierCode",
      "OperatingFlightNumber",
      "DepartureAirportIATACode",
      "ArrivalAirportIATACode",
      "LocalDepartureScheduledDate",
      "CurrentFlightAcceptanceStatusCode",
      "CurrentFlightGeneralStatusCode",
      "CurrentFlightLoadControlStatusCode",
      "CurrentFlightBoardingStatusCode",
      "PreviousFlightAcceptanceStatusCode",
      "PreviousFlightGeneralStatusCode",
      "PreviousFlightLoadControlStatusCode",
      "PreviousFlightBoardingStatusCode",
      "UTCFlightAcceptanceStatusModifiedAt",
      "UTCFlightGeneralStatusModifiedAt",
      "UTCFlightLoadControlStatusModifiedAt",
      "UTCFlightBoardingStatusModifiedAt",
      "RecordCreatedAt",
      "RecordModifiedAt",
      "RecordVersion",
      "SourceCreatedBy"
    FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8071","YYZ","2026-11-20"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8071",
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YUL",
    "LocalDepartureScheduledDate": "2026-11-19T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T10:26:24.004Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T10:26:24.004Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T10:26:24.004Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T10:26:24.004Z",
    "RecordCreatedAt": "2026-08-05T10:26:24.004Z",
    "RecordModifiedAt": "2026-08-05T10:26:27.775Z",
    "RecordVersion": "1785925587588497200",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

### Query 3: FlightState after status change
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT 
      "OperatingCarrierCode",
      "OperatingFlightNumber",
      "DepartureAirportIATACode",
      "ArrivalAirportIATACode",
      "LocalDepartureScheduledDate",
      "CurrentFlightAcceptanceStatusCode",
      "CurrentFlightGeneralStatusCode",
      "CurrentFlightLoadControlStatusCode",
      "CurrentFlightBoardingStatusCode",
      "PreviousFlightAcceptanceStatusCode",
      "PreviousFlightGeneralStatusCode",
      "PreviousFlightLoadControlStatusCode",
      "PreviousFlightBoardingStatusCode",
      "UTCFlightAcceptanceStatusModifiedAt",
      "UTCFlightGeneralStatusModifiedAt",
      "UTCFlightLoadControlStatusModifiedAt",
      "UTCFlightBoardingStatusModifiedAt",
      "RecordCreatedAt",
      "RecordModifiedAt",
      "RecordVersion",
      "SourceCreatedBy"
    FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8071","YYZ","2026-11-20"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8071",
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YUL",
    "LocalDepartureScheduledDate": "2026-11-19T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "CLOSED",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": "OPEN",
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T10:26:31.428Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T10:26:24.004Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T10:26:24.004Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T10:26:24.004Z",
    "RecordCreatedAt": "2026-08-05T10:26:24.004Z",
    "RecordModifiedAt": "2026-08-05T10:26:31.428Z",
    "RecordVersion": "1785925591259864000",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

### Query 4: InventoryFlightLeg final state
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8071-2026-11-20"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8071-2026-11-20",
    "Id": "YYZ-YUL",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8071",
    "OperatingNumber": "8071",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YUL_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YUL",
    "LocalDepartureScheduleAt": "2026-11-20T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-20T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-20T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-20T14:30:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "320",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 170,
    "ScheduledFittedAircraftConfigurationCode": "321",
    "ScheduledFittedBusinessSeatCapacity": 14,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 156,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 14,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 156,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 14,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 156,
    "OperationalFittedAircraftConfigurationCode": "321",
    "OperationalFittedBusinessSeatCapacity": 14,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 156,
    "CurrentFlightAcceptanceStatusCode": "CLOSED",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": "OPEN",
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T10:26:31.428Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T10:26:24.004Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T10:26:24.004Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T10:26:24.004Z",
    "RecordCorrelationId": "01KZ8QBRC3MQS4GRWV0CPBTEVJ",
    "RecordCreatedAt": "2026-08-05T10:26:24.004Z",
    "RecordModifiedAt": "2026-08-05T10:26:31.428Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785925591259864000"
  }
]
```

## Assertions

✅ **Lambda success**: ✅ PASS
✅ **FlightState: UTCFlightGeneralStatusModifiedAt unchanged (no general status change)**: ✅ PASS
✅ **FlightState: UTCFlightAcceptanceStatusModifiedAt updated after status change**: ✅ PASS
✅ **InventoryFlightLeg.CurrentFlightAcceptanceStatusCode=CLOSED**: ✅ PASS
✅ **InventoryFlightLeg.FlightAcceptanceStatusModifiedAt populated**: ✅ PASS

---
## Final Verdict: ✅ PASSED