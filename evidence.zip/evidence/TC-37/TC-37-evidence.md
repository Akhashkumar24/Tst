# TC-37 - Verify RecordCorrelationId is valid ULID and identical across all BookingInventoryDataStore entities

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T09:59:52.079Z
**Result:** ✅ PASSED
**Duration:** 9570ms

## Test Description
Ingest event. Query InventoryFlight, InventoryFlightLeg, InventoryFlightPlace, InventoryFlightSegment. Compare RecordCorrelationId (char column — requires .trim()). Verify all share same ULID.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785923984929-plfbkr1y0"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8037-2026-11-18",
    "version": "1785923984929446999",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8037"
    },
    "scheduledDepartureDate": "2026-11-18",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-18T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YVR_2",
        "iataCode": "YVR",
        "city": "YVR",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-18T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-18-YYZ-YVR",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YVR_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YVR",
        "scheduledDepartureDateTime": "2026-11-18T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-18T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-18T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-18T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YVR"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-YVR",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YVR_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YVR",
        "scheduledDepartureDateTime": "2026-11-18T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-18T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-18T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-18T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8037-2026-11-18",
    "originFeedTimeStamp": "2026-08-05T09:59:44.930Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2461 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T09:59:44.930Z

## Database Verification

### Query 1: InventoryFlight
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8037-2026-11-18"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8037-2026-11-18",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8037",
    "OperatingNumber": "8037",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-17T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8NTQW0BG7HZ2BYDFPEF4P4",
    "RecordCreatedAt": "2026-08-05T09:59:45.280Z",
    "RecordModifiedAt": "2026-08-05T09:59:45.280Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785923984929447000"
  }
]
```

### Query 2: InventoryFlightLeg
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8037-2026-11-18"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8037-2026-11-18",
    "Id": "YYZ-YVR",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8037",
    "OperatingNumber": "8037",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YVR_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YVR",
    "LocalDepartureScheduleAt": "2026-11-18T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-18T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-18T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-18T14:30:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "320",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 170,
    "ScheduledFittedAircraftConfigurationCode": "321",
    "ScheduledFittedBusinessSeatCapacity": 14,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 156,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 14,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 156,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 14,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 156,
    "OperationalFittedAircraftConfigurationCode": "321",
    "OperationalFittedBusinessSeatCapacity": 14,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 156,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T09:59:45.280Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T09:59:45.280Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T09:59:45.280Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T09:59:45.280Z",
    "RecordCorrelationId": "01KZ8NTQW0BG7HZ2BYDFPEF4P4",
    "RecordCreatedAt": "2026-08-05T09:59:45.280Z",
    "RecordModifiedAt": "2026-08-05T09:59:45.280Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785923984929447000"
  }
]
```

### Query 3: InventoryFlightPlace
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightPlace" WHERE "InventoryFlightId" = $1
```
**Parameters:** ["AC-8037-2026-11-18"]
**Row Count:** 2
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8037-2026-11-18",
    "InventoryPlaceId": "YYZ_1",
    "PlaceIATACode": "YYZ",
    "PlaceCityCode": "YYZ",
    "CountryCode": "CA",
    "InventoryPlaceRegionCode": "NAMER",
    "InventoryPlaceContinentCode": "ITC1",
    "LocalScheduledDepartureAt": "2026-11-18T02:30:00.000Z",
    "LocalScheduledArrivalAt": null,
    "LocalEstimatedOffBlockAt": null,
    "LocalEstimatedTakeOffAt": null,
    "LocalEstimatedTouchdownAt": null,
    "LocalEstimatedOnBlockAt": null,
    "LocalActualOffBlockAt": null,
    "LocalActualTakeOffAt": null,
    "LocalActualTouchdownAt": null,
    "LocalActualOnBlockAt": null,
    "Terminals": [
      {
        "code": "1"
      }
    ],
    "RecordCorrelationId": "01KZ8NTQW0BG7HZ2BYDFPEF4P4",
    "RecordCreatedAt": "2026-08-05T09:59:45.280Z",
    "RecordModifiedAt": "2026-08-05T09:59:45.280Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785923984929447000"
  },
  {
    "InventoryFlightId": "AC-8037-2026-11-18",
    "InventoryPlaceId": "YVR_2",
    "PlaceIATACode": "YVR",
    "PlaceCityCode": "YVR",
    "CountryCode": "CA",
    "InventoryPlaceRegionCode": "NAMER",
    "InventoryPlaceContinentCode": "ITC1",
    "LocalScheduledDepartureAt": null,
    "LocalScheduledArrivalAt": "2026-11-18T05:00:00.000Z",
    "LocalEstimatedOffBlockAt": null,
    "LocalEstimatedTakeOffAt": null,
    "LocalEstimatedTouchdownAt": null,
    "LocalEstimatedOnBlockAt": null,
    "LocalActualOffBlockAt": null,
    "LocalActualTakeOffAt": null,
    "LocalActualTouchdownAt": null,
    "LocalActualOnBlockAt": null,
    "Terminals": [
      {
        "code": "1"
      }
    ],
    "RecordCorrelationId": "01KZ8NTQW0BG7HZ2BYDFPEF4P4",
    "RecordCreatedAt": "2026-08-05T09:59:45.280Z",
    "RecordModifiedAt": "2026-08-05T09:59:45.280Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785923984929447000"
  }
]
```

### Query 4: InventoryFlightSegment
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightSegment" WHERE "InventoryFlightId" = $1
```
**Parameters:** ["AC-8037-2026-11-18"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8037-2026-11-18",
    "Id": "2026-11-18-YYZ-YVR",
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YVR_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YVR",
    "LocalDepartureScheduleAt": "2026-11-18T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-18T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-18T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-18T14:30:00.000Z",
    "LegCount": 1,
    "TrafficRestrictions": null,
    "RecordCorrelationId": "01KZ8NTQW0BG7HZ2BYDFPEF4P4",
    "RecordCreatedAt": "2026-08-05T09:59:45.280Z",
    "RecordModifiedAt": "2026-08-05T09:59:45.280Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785923984929447000"
  }
]
```

### Query 5: FlightState (RecordCorrelationId comparison)
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT 
      "OperatingCarrierCode",
      "OperatingFlightNumber",
      "DepartureAirportIATACode",
      "ArrivalAirportIATACode",
      "LocalDepartureScheduledDate",
      "CurrentFlightAcceptanceStatusCode",
      "CurrentFlightGeneralStatusCode",
      "CurrentFlightLoadControlStatusCode",
      "CurrentFlightBoardingStatusCode",
      "PreviousFlightAcceptanceStatusCode",
      "PreviousFlightGeneralStatusCode",
      "PreviousFlightLoadControlStatusCode",
      "PreviousFlightBoardingStatusCode",
      "UTCFlightAcceptanceStatusModifiedAt",
      "UTCFlightGeneralStatusModifiedAt",
      "UTCFlightLoadControlStatusModifiedAt",
      "UTCFlightBoardingStatusModifiedAt",
      "RecordCreatedAt",
      "RecordModifiedAt",
      "RecordVersion",
      "SourceCreatedBy"
    FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8037","YYZ","2026-11-18"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8037",
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YVR",
    "LocalDepartureScheduledDate": "2026-11-17T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T09:59:45.280Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T09:59:45.280Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T09:59:45.280Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T09:59:45.280Z",
    "RecordCreatedAt": "2026-08-05T09:59:45.280Z",
    "RecordModifiedAt": "2026-08-05T09:59:45.280Z",
    "RecordVersion": "1785923984929447000",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

## Assertions

✅ **Lambda success**: ✅ PASS
✅ **All tables have records**: ✅ PASS
✅ **All BookingInventoryDataStore entities share same RecordCorrelationId**: ✅ PASS
✅ **RecordCorrelationId length = 26 (ULID format)**: ✅ PASS
✅ **RecordCorrelationId matches ULID pattern (alphanumeric uppercase)**: ✅ PASS
✅ **⚠️ FlightState.RecordCorrelationId differs from CustomerDataMart (separate write — documented)**: ✅ PASS

---
## Final Verdict: ✅ PASSED