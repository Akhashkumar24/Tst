# TC-65 - Validate multi-leg update only impacts specific leg

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T10:25:28.347Z
**Result:** ✅ PASSED
**Duration:** 11079ms

## Test Description
Update full flight with destination terminal change. Verify 2 legs still exist.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785925524106-2wwga6h2e"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8065-2026-11-20",
    "version": "1785925524106931802",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8065"
    },
    "scheduledDepartureDate": "2026-11-20",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "INTERNATIONAL"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-20T19:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YHZ_2",
        "iataCode": "YHZ",
        "city": "YHZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-20T23:05:00"
            }
          ]
        },
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-20T22:09:00"
            }
          ]
        }
      },
      {
        "id": "LHR_3",
        "iataCode": "LHR",
        "city": "LON",
        "country": "GB",
        "region": "EUROP",
        "continent": "ITC2",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-16T09:00:00"
            }
          ],
          "terminals": [
            {
              "code": "4"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-20-YYZ-YHZ",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YHZ_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YHZ",
        "scheduledDepartureDateTime": "2026-11-20T19:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-20T23:00:00Z",
        "scheduledArrivalDateTime": "2026-11-20T22:09:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T01:09:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YHZ"
        ]
      },
      {
        "id": "2026-11-20-YYZ-LHR",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "LHR_3",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "LHR",
        "scheduledDepartureDateTime": "2026-11-20T19:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-20T23:00:00Z",
        "scheduledArrivalDateTime": "2026-11-16T09:00:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T08:00:00Z",
        "numberOfLegs": 2,
        "legIds": [
          "YYZ-YHZ",
          "YHZ-LHR"
        ]
      },
      {
        "id": "2026-11-20-YHZ-LHR",
        "boardFlightPointId": "YHZ_2",
        "offFlightPointId": "LHR_3",
        "boardPointIataCode": "YHZ",
        "offPointIataCode": "LHR",
        "scheduledDepartureDateTime": "2026-11-20T23:05:00",
        "scheduledDepartureDateTimeUtc": "2026-11-16T02:05:00Z",
        "scheduledArrivalDateTime": "2026-11-16T09:00:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T08:00:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YHZ-LHR"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-YHZ",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YHZ_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YHZ",
        "scheduledDepartureDateTime": "2026-11-20T19:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-20T23:00:00Z",
        "scheduledArrivalDateTime": "2026-11-20T22:09:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T01:09:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "7M8",
          "scheduledFittedConfiguration": {
            "code": "7M1",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 153
              }
            ]
          },
          "acvTotalCapacity": 169,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 153
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 153
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "7M1",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 153
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      },
      {
        "id": "YHZ-LHR",
        "boardFlightPointId": "YHZ_2",
        "offFlightPointId": "LHR_3",
        "boardPointIataCode": "YHZ",
        "offPointIataCode": "LHR",
        "scheduledDepartureDateTime": "2026-11-20T23:05:00",
        "scheduledDepartureDateTimeUtc": "2026-11-16T02:05:00Z",
        "scheduledArrivalDateTime": "2026-11-16T09:00:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T08:00:00Z",
        "routingOrder": 2,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "7M8",
          "scheduledFittedConfiguration": {
            "code": "7M1",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 153
              }
            ]
          },
          "acvTotalCapacity": 169,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 153
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 153
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "7M1",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 16
              },
              {
                "cabin": "Y",
                "capacity": 153
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8065-2026-11-20",
    "originFeedTimeStamp": "2026-08-05T10:25:29.106Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "UPDATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 4567 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T10:25:24.107Z

## Database Verification

### Query 1: InventoryFlightLeg before update
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8065-2026-11-20"]
**Row Count:** 2
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8065-2026-11-20",
    "Id": "YYZ-YHZ",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8065",
    "OperatingNumber": "8065",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YHZ_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YHZ",
    "LocalDepartureScheduleAt": "2026-11-20T13:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-20T23:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-20T16:39:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-16T01:09:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "7M8",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 169,
    "ScheduledFittedAircraftConfigurationCode": "7M1",
    "ScheduledFittedBusinessSeatCapacity": 16,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 153,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 16,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 153,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 16,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 153,
    "OperationalFittedAircraftConfigurationCode": "7M1",
    "OperationalFittedBusinessSeatCapacity": 16,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 153,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T10:25:20.377Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T10:25:20.377Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T10:25:20.377Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T10:25:20.377Z",
    "RecordCorrelationId": "01KZ8Q9JZS70KMEERZBCH9D9J6",
    "RecordCreatedAt": "2026-08-05T10:25:20.377Z",
    "RecordModifiedAt": "2026-08-05T10:25:20.377Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785925520184214300"
  },
  {
    "InventoryFlightId": "AC-8065-2026-11-20",
    "Id": "YHZ-LHR",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8065",
    "OperatingNumber": "8065",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YHZ_2",
    "OffInventoryPlaceId": "LHR_3",
    "BoardPlaceIATACode": "YHZ",
    "OffPlaceIATACode": "LHR",
    "LocalDepartureScheduleAt": "2026-11-20T17:35:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-16T02:05:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-16T03:30:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-16T08:00:00.000Z",
    "SequenceNumber": 2,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "7M8",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 169,
    "ScheduledFittedAircraftConfigurationCode": "7M1",
    "ScheduledFittedBusinessSeatCapacity": 16,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 153,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 16,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 153,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 16,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 153,
    "OperationalFittedAircraftConfigurationCode": "7M1",
    "OperationalFittedBusinessSeatCapacity": 16,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 153,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T10:25:20.377Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T10:25:20.377Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T10:25:20.377Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T10:25:20.377Z",
    "RecordCorrelationId": "01KZ8Q9JZS70KMEERZBCH9D9J6",
    "RecordCreatedAt": "2026-08-05T10:25:20.377Z",
    "RecordModifiedAt": "2026-08-05T10:25:20.377Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785925520184214300"
  }
]
```

### Query 2: InventoryFlightLeg after update
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8065-2026-11-20"]
**Row Count:** 2
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8065-2026-11-20",
    "Id": "YYZ-YHZ",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8065",
    "OperatingNumber": "8065",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YHZ_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YHZ",
    "LocalDepartureScheduleAt": "2026-11-20T13:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-20T23:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-20T16:39:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-16T01:09:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "7M8",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 169,
    "ScheduledFittedAircraftConfigurationCode": "7M1",
    "ScheduledFittedBusinessSeatCapacity": 16,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 153,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 16,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 153,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 16,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 153,
    "OperationalFittedAircraftConfigurationCode": "7M1",
    "OperationalFittedBusinessSeatCapacity": 16,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 153,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T10:25:20.377Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T10:25:20.377Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T10:25:20.377Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T10:25:20.377Z",
    "RecordCorrelationId": "01KZ8Q9PT85E6T8GEQSQD83K6S",
    "RecordCreatedAt": "2026-08-05T10:25:20.377Z",
    "RecordModifiedAt": "2026-08-05T10:25:24.297Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785925524106931700"
  },
  {
    "InventoryFlightId": "AC-8065-2026-11-20",
    "Id": "YHZ-LHR",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8065",
    "OperatingNumber": "8065",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YHZ_2",
    "OffInventoryPlaceId": "LHR_3",
    "BoardPlaceIATACode": "YHZ",
    "OffPlaceIATACode": "LHR",
    "LocalDepartureScheduleAt": "2026-11-20T17:35:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-16T02:05:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-16T03:30:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-16T08:00:00.000Z",
    "SequenceNumber": 2,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "7M8",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 169,
    "ScheduledFittedAircraftConfigurationCode": "7M1",
    "ScheduledFittedBusinessSeatCapacity": 16,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 153,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 16,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 153,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 16,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 153,
    "OperationalFittedAircraftConfigurationCode": "7M1",
    "OperationalFittedBusinessSeatCapacity": 16,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 153,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T10:25:20.377Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T10:25:20.377Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T10:25:20.377Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T10:25:20.377Z",
    "RecordCorrelationId": "01KZ8Q9PT85E6T8GEQSQD83K6S",
    "RecordCreatedAt": "2026-08-05T10:25:20.377Z",
    "RecordModifiedAt": "2026-08-05T10:25:24.297Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785925524106931700"
  }
]
```

### Query 3: InventoryFlightPlace after update
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightPlace" WHERE "InventoryFlightId" = $1
```
**Parameters:** ["AC-8065-2026-11-20"]
**Row Count:** 3
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8065-2026-11-20",
    "InventoryPlaceId": "YYZ_1",
    "PlaceIATACode": "YYZ",
    "PlaceCityCode": "YYZ",
    "CountryCode": "CA",
    "InventoryPlaceRegionCode": "NAMER",
    "InventoryPlaceContinentCode": "ITC1",
    "LocalScheduledDepartureAt": "2026-11-20T13:30:00.000Z",
    "LocalScheduledArrivalAt": null,
    "LocalEstimatedOffBlockAt": null,
    "LocalEstimatedTakeOffAt": null,
    "LocalEstimatedTouchdownAt": null,
    "LocalEstimatedOnBlockAt": null,
    "LocalActualOffBlockAt": null,
    "LocalActualTakeOffAt": null,
    "LocalActualTouchdownAt": null,
    "LocalActualOnBlockAt": null,
    "Terminals": [
      {
        "code": "1"
      }
    ],
    "RecordCorrelationId": "01KZ8Q9PT85E6T8GEQSQD83K6S",
    "RecordCreatedAt": "2026-08-05T10:25:20.377Z",
    "RecordModifiedAt": "2026-08-05T10:25:24.297Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785925524106931700"
  },
  {
    "InventoryFlightId": "AC-8065-2026-11-20",
    "InventoryPlaceId": "YHZ_2",
    "PlaceIATACode": "YHZ",
    "PlaceCityCode": "YHZ",
    "CountryCode": "CA",
    "InventoryPlaceRegionCode": "NAMER",
    "InventoryPlaceContinentCode": "ITC1",
    "LocalScheduledDepartureAt": "2026-11-20T17:35:00.000Z",
    "LocalScheduledArrivalAt": "2026-11-20T16:39:00.000Z",
    "LocalEstimatedOffBlockAt": null,
    "LocalEstimatedTakeOffAt": null,
    "LocalEstimatedTouchdownAt": null,
    "LocalEstimatedOnBlockAt": null,
    "LocalActualOffBlockAt": null,
    "LocalActualTakeOffAt": null,
    "LocalActualTouchdownAt": null,
    "LocalActualOnBlockAt": null,
    "Terminals": null,
    "RecordCorrelationId": "01KZ8Q9PT85E6T8GEQSQD83K6S",
    "RecordCreatedAt": "2026-08-05T10:25:20.377Z",
    "RecordModifiedAt": "2026-08-05T10:25:24.297Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785925524106931700"
  },
  {
    "InventoryFlightId": "AC-8065-2026-11-20",
    "InventoryPlaceId": "LHR_3",
    "PlaceIATACode": "LHR",
    "PlaceCityCode": "LON",
    "CountryCode": "GB",
    "InventoryPlaceRegionCode": "EUROP",
    "InventoryPlaceContinentCode": "ITC2",
    "LocalScheduledDepartureAt": null,
    "LocalScheduledArrivalAt": "2026-11-16T03:30:00.000Z",
    "LocalEstimatedOffBlockAt": null,
    "LocalEstimatedTakeOffAt": null,
    "LocalEstimatedTouchdownAt": null,
    "LocalEstimatedOnBlockAt": null,
    "LocalActualOffBlockAt": null,
    "LocalActualTakeOffAt": null,
    "LocalActualTouchdownAt": null,
    "LocalActualOnBlockAt": null,
    "Terminals": [
      {
        "code": "4"
      }
    ],
    "RecordCorrelationId": "01KZ8Q9PT85E6T8GEQSQD83K6S",
    "RecordCreatedAt": "2026-08-05T10:25:20.377Z",
    "RecordModifiedAt": "2026-08-05T10:25:24.297Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785925524106931700"
  }
]
```

## Assertions

✅ **Lambda success**: ✅ PASS
✅ **Still 2 legs (no duplicates)**: ✅ PASS

---
## Final Verdict: ✅ PASSED