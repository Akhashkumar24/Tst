# TC-67 - Validate flight reinstatement after cancellation

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T10:30:50.336Z
**Result:** ✅ PASSED
**Duration:** 17868ms

## Test Description
Cancel a flight, then reinstate it. Verify IsCancelled reverts to false, legs restored.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785925844456-ynausiih1"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8067-2026-11-20",
    "version": "6700000000000000003",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8067"
    },
    "scheduledDepartureDate": "2026-11-20",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YUL_1",
        "iataCode": "YUL",
        "city": "YUL",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-20T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YYZ_2",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-20T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-20-YUL-YYZ",
        "boardFlightPointId": "YUL_1",
        "offFlightPointId": "YYZ_2",
        "boardPointIataCode": "YUL",
        "offPointIataCode": "YYZ",
        "scheduledDepartureDateTime": "2026-11-20T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-20T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-20T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-20T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YUL-YYZ"
        ]
      }
    ],
    "legs": [
      {
        "id": "YUL-YYZ",
        "boardFlightPointId": "YUL_1",
        "offFlightPointId": "YYZ_2",
        "boardPointIataCode": "YUL",
        "offPointIataCode": "YYZ",
        "scheduledDepartureDateTime": "2026-11-20T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-20T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-20T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-20T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8067-2026-11-20",
    "originFeedTimeStamp": "2026-08-05T10:30:49.456Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "UPDATED",
        "currentPath": "/isCancelled",
        "previousPath": "/isCancelled"
      },
      {
        "origin": "COMPARISON",
        "eventType": "CREATED",
        "currentPath": "/legs"
      },
      {
        "origin": "COMPARISON",
        "eventType": "CREATED",
        "currentPath": "/flightPoints"
      },
      {
        "origin": "COMPARISON",
        "eventType": "CREATED",
        "currentPath": "/segments"
      }
    ]
  },
  "previousRecord": [
    {
      "op": "replace",
      "path": "/isCancelled",
      "value": true
    },
    {
      "op": "replace",
      "path": "/version",
      "value": "6700000000000000002"
    }
  ]
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2872 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T10:30:44.456Z

## Database Verification

### Query 1: InventoryFlight after cancellation
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8067-2026-11-20"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8067-2026-11-20",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8067",
    "OperatingNumber": "8067",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-19T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8QK8PXPMX7CPZJWP1NX043",
    "RecordCreatedAt": "2026-08-05T10:30:37.533Z",
    "RecordModifiedAt": "2026-08-05T10:30:37.533Z",
    "RecordExpiredAt": null,
    "RecordVersion": "6700000000000000000"
  }
]
```

### Query 2: InventoryFlight after reinstatement
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8067-2026-11-20"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8067-2026-11-20",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8067",
    "OperatingNumber": "8067",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-19T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8QK8PXPMX7CPZJWP1NX043",
    "RecordCreatedAt": "2026-08-05T10:30:37.533Z",
    "RecordModifiedAt": "2026-08-05T10:30:37.533Z",
    "RecordExpiredAt": null,
    "RecordVersion": "6700000000000000000"
  }
]
```

### Query 3: InventoryFlightLeg after reinstatement
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8067-2026-11-20"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8067-2026-11-20",
    "Id": "YUL-YYZ",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8067",
    "OperatingNumber": "8067",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YUL_1",
    "OffInventoryPlaceId": "YYZ_2",
    "BoardPlaceIATACode": "YUL",
    "OffPlaceIATACode": "YYZ",
    "LocalDepartureScheduleAt": "2026-11-20T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-20T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-20T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-20T14:30:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "320",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 170,
    "ScheduledFittedAircraftConfigurationCode": "321",
    "ScheduledFittedBusinessSeatCapacity": 14,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 156,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 14,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 156,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 14,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 156,
    "OperationalFittedAircraftConfigurationCode": "321",
    "OperationalFittedBusinessSeatCapacity": 14,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 156,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T10:30:37.533Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T10:30:37.533Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T10:30:37.533Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T10:30:37.533Z",
    "RecordCorrelationId": "01KZ8QK8PXPMX7CPZJWP1NX043",
    "RecordCreatedAt": "2026-08-05T10:30:37.533Z",
    "RecordModifiedAt": "2026-08-05T10:30:37.533Z",
    "RecordExpiredAt": null,
    "RecordVersion": "6700000000000000000"
  }
]
```

## Assertions

✅ **Lambda success**: ✅ PASS
✅ **IsCancelled=false (reinstated)**: ✅ PASS
✅ **Leg restored after reinstatement**: ✅ PASS

---
## Final Verdict: ✅ PASSED