# TC-35 - Verify ingestion of a large multi-leg/multi-segment event and a burst of events completes without timeout or partial commit

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T16:13:01.335Z
**Result:** ✅ PASSED
**Duration:** 43519ms

## Test Description
Part A: Ingest a single large multi-leg event (2+ legs via createMultiLeg). Part B: Fire 10 events in parallel for different flight keys. Verify all complete within Lambda timeout, all records persisted, no partial commits. Uses numeric-only flight numbers.

## Payload Sent to Lambda
```json
{
  "largePayload": {
    "meta": {
      "triggerEventLog": {
        "id": "tc-1785946340003-ub2pmaq32"
      },
      "version": "1.3.0"
    },
    "scheduleProcessedFlight": {
      "type": "dated-flight",
      "id": "AC-9035-2026-11-21",
      "version": "350001",
      "flightDesignator": {
        "carrierCode": "AC",
        "flightNumber": "9035"
      },
      "scheduledDepartureDate": "2026-11-21",
      "dayOfOperation": "WED",
      "isCancelled": false,
      "characteristics": [
        "INTERNATIONAL"
      ],
      "codeshare": "OPERATING",
      "flightPoints": [
        {
          "id": "YYZ_1",
          "iataCode": "YYZ",
          "city": "YYZ",
          "country": "CA",
          "region": "NAMER",
          "continent": "ITC1",
          "departure": {
            "timings": [
              {
                "qualifier": "STD",
                "value": "2026-11-21T19:00:00"
              }
            ],
            "terminals": [
              {
                "code": "1"
              }
            ]
          }
        },
        {
          "id": "YHZ_2",
          "iataCode": "YHZ",
          "city": "YHZ",
          "country": "CA",
          "region": "NAMER",
          "continent": "ITC1",
          "departure": {
            "timings": [
              {
                "qualifier": "STD",
                "value": "2026-11-21T23:05:00"
              }
            ]
          },
          "arrival": {
            "timings": [
              {
                "qualifier": "STA",
                "value": "2026-11-21T22:09:00"
              }
            ]
          }
        },
        {
          "id": "LHR_3",
          "iataCode": "LHR",
          "city": "LON",
          "country": "GB",
          "region": "EUROP",
          "continent": "ITC2",
          "arrival": {
            "timings": [
              {
                "qualifier": "STA",
                "value": "2026-11-16T09:00:00"
              }
            ],
            "terminals": [
              {
                "code": "2"
              }
            ]
          }
        }
      ],
      "segments": [
        {
          "id": "2026-11-21-YYZ-YHZ",
          "boardFlightPointId": "YYZ_1",
          "offFlightPointId": "YHZ_2",
          "boardPointIataCode": "YYZ",
          "offPointIataCode": "YHZ",
          "scheduledDepartureDateTime": "2026-11-21T19:00:00",
          "scheduledDepartureDateTimeUtc": "2026-11-21T23:00:00Z",
          "scheduledArrivalDateTime": "2026-11-21T22:09:00",
          "scheduledArrivalDateTimeUtc": "2026-11-16T01:09:00Z",
          "numberOfLegs": 1,
          "legIds": [
            "YYZ-YHZ"
          ]
        },
        {
          "id": "2026-11-21-YYZ-LHR",
          "boardFlightPointId": "YYZ_1",
          "offFlightPointId": "LHR_3",
          "boardPointIataCode": "YYZ",
          "offPointIataCode": "LHR",
          "scheduledDepartureDateTime": "2026-11-21T19:00:00",
          "scheduledDepartureDateTimeUtc": "2026-11-21T23:00:00Z",
          "scheduledArrivalDateTime": "2026-11-16T09:00:00",
          "scheduledArrivalDateTimeUtc": "2026-11-16T08:00:00Z",
          "numberOfLegs": 2,
          "legIds": [
            "YYZ-YHZ",
            "YHZ-LHR"
          ]
        },
        {
          "id": "2026-11-21-YHZ-LHR",
          "boardFlightPointId": "YHZ_2",
          "offFlightPointId": "LHR_3",
          "boardPointIataCode": "YHZ",
          "offPointIataCode": "LHR",
          "scheduledDepartureDateTime": "2026-11-21T23:05:00",
          "scheduledDepartureDateTimeUtc": "2026-11-16T02:05:00Z",
          "scheduledArrivalDateTime": "2026-11-16T09:00:00",
          "scheduledArrivalDateTimeUtc": "2026-11-16T08:00:00Z",
          "numberOfLegs": 1,
          "legIds": [
            "YHZ-LHR"
          ]
        }
      ],
      "legs": [
        {
          "id": "YYZ-YHZ",
          "boardFlightPointId": "YYZ_1",
          "offFlightPointId": "YHZ_2",
          "boardPointIataCode": "YYZ",
          "offPointIataCode": "YHZ",
          "scheduledDepartureDateTime": "2026-11-21T19:00:00",
          "scheduledDepartureDateTimeUtc": "2026-11-21T23:00:00Z",
          "scheduledArrivalDateTime": "2026-11-21T22:09:00",
          "scheduledArrivalDateTimeUtc": "2026-11-16T01:09:00Z",
          "routingOrder": 1,
          "serviceType": "J",
          "aircraftEquipment": {
            "aircraftType": "7M8",
            "scheduledFittedConfiguration": {
              "code": "7M1",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 16
                },
                {
                  "cabin": "Y",
                  "capacity": 153
                }
              ]
            },
            "acvTotalCapacity": 169,
            "operationalSaleableConfiguration": {
              "code": "001",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 16
                },
                {
                  "cabin": "Y",
                  "capacity": 153
                }
              ]
            },
            "scheduledSaleableConfiguration": {
              "code": "001",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 16
                },
                {
                  "cabin": "Y",
                  "capacity": 153
                }
              ]
            },
            "operationalFittedConfiguration": {
              "code": "7M1",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 16
                },
                {
                  "cabin": "Y",
                  "capacity": 153
                }
              ]
            }
          },
          "legDCSStatuses": {
            "acceptanceStatus": "OPEN",
            "generalStatus": "OPEN",
            "loadControlStatus": "OPEN",
            "boardingStatus": "NOT_OPEN"
          }
        },
        {
          "id": "YHZ-LHR",
          "boardFlightPointId": "YHZ_2",
          "offFlightPointId": "LHR_3",
          "boardPointIataCode": "YHZ",
          "offPointIataCode": "LHR",
          "scheduledDepartureDateTime": "2026-11-21T23:05:00",
          "scheduledDepartureDateTimeUtc": "2026-11-16T02:05:00Z",
          "scheduledArrivalDateTime": "2026-11-16T09:00:00",
          "scheduledArrivalDateTimeUtc": "2026-11-16T08:00:00Z",
          "routingOrder": 2,
          "serviceType": "J",
          "aircraftEquipment": {
            "aircraftType": "7M8",
            "scheduledFittedConfiguration": {
              "code": "7M1",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 16
                },
                {
                  "cabin": "Y",
                  "capacity": 153
                }
              ]
            },
            "acvTotalCapacity": 169,
            "operationalSaleableConfiguration": {
              "code": "001",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 16
                },
                {
                  "cabin": "Y",
                  "capacity": 153
                }
              ]
            },
            "scheduledSaleableConfiguration": {
              "code": "001",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 16
                },
                {
                  "cabin": "Y",
                  "capacity": 153
                }
              ]
            },
            "operationalFittedConfiguration": {
              "code": "7M1",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 16
                },
                {
                  "cabin": "Y",
                  "capacity": 153
                }
              ]
            }
          },
          "legDCSStatuses": {
            "acceptanceStatus": "OPEN",
            "generalStatus": "OPEN",
            "loadControlStatus": "OPEN",
            "boardingStatus": "NOT_OPEN"
          }
        }
      ]
    },
    "events": {
      "recordDomain": "SCHEDULE",
      "recordId": "AC-9035-2026-11-21",
      "originFeedTimeStamp": "2026-08-05T16:12:20.004Z",
      "events": [
        {
          "origin": "COMPARISON",
          "eventType": "CREATED"
        }
      ]
    }
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 4571 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** N/A
- **Function Error:** None
- **Invoked At:** N/A

## Database Verification

### Query 1: Part A: InventoryFlight (large multi-leg)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-9035-2026-11-21"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-9035-2026-11-21",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "9035",
    "OperatingNumber": "9035",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-20T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": false,
    "IsInternational": true,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ9B51G4JVT6ME02FGNV28W9",
    "RecordCreatedAt": "2026-08-05T16:12:22.916Z",
    "RecordModifiedAt": "2026-08-05T16:12:22.916Z",
    "RecordExpiredAt": null,
    "RecordVersion": "350001"
  }
]
```

### Query 2: Part A: InventoryFlightLeg (all legs)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-9035-2026-11-21"]
**Row Count:** 2
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-9035-2026-11-21",
    "Id": "YYZ-YHZ",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "9035",
    "OperatingNumber": "9035",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YHZ_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YHZ",
    "LocalDepartureScheduleAt": "2026-11-21T13:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-21T23:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-21T16:39:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-16T01:09:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "7M8",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 169,
    "ScheduledFittedAircraftConfigurationCode": "7M1",
    "ScheduledFittedBusinessSeatCapacity": 16,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 153,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 16,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 153,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 16,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 153,
    "OperationalFittedAircraftConfigurationCode": "7M1",
    "OperationalFittedBusinessSeatCapacity": 16,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 153,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T16:12:22.916Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T16:12:22.916Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T16:12:22.916Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T16:12:22.916Z",
    "RecordCorrelationId": "01KZ9B51G4JVT6ME02FGNV28W9",
    "RecordCreatedAt": "2026-08-05T16:12:22.916Z",
    "RecordModifiedAt": "2026-08-05T16:12:22.916Z",
    "RecordExpiredAt": null,
    "RecordVersion": "350001"
  },
  {
    "InventoryFlightId": "AC-9035-2026-11-21",
    "Id": "YHZ-LHR",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "9035",
    "OperatingNumber": "9035",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YHZ_2",
    "OffInventoryPlaceId": "LHR_3",
    "BoardPlaceIATACode": "YHZ",
    "OffPlaceIATACode": "LHR",
    "LocalDepartureScheduleAt": "2026-11-21T17:35:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-16T02:05:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-16T03:30:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-16T08:00:00.000Z",
    "SequenceNumber": 2,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "7M8",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 169,
    "ScheduledFittedAircraftConfigurationCode": "7M1",
    "ScheduledFittedBusinessSeatCapacity": 16,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 153,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 16,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 153,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 16,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 153,
    "OperationalFittedAircraftConfigurationCode": "7M1",
    "OperationalFittedBusinessSeatCapacity": 16,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 153,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T16:12:22.916Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T16:12:22.916Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T16:12:22.916Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T16:12:22.916Z",
    "RecordCorrelationId": "01KZ9B51G4JVT6ME02FGNV28W9",
    "RecordCreatedAt": "2026-08-05T16:12:22.916Z",
    "RecordModifiedAt": "2026-08-05T16:12:22.916Z",
    "RecordExpiredAt": null,
    "RecordVersion": "350001"
  }
]
```

### Query 3: Part A: Row counts
**Database:** CustomerDataMart
**SQL:**
```sql

    SELECT 
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1)::int AS flight_count,
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1)::int AS leg_count,
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlightSegment" WHERE "InventoryFlightId" = $1)::int AS segment_count,
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlightPlace" WHERE "InventoryFlightId" = $1)::int AS place_count,
      (SELECT COUNT(*) FROM "BookingInventoryDataStore"."InventoryFlightSegmentAlias" WHERE "InventoryFlightId" = $1)::int AS alias_count
  
```
**Parameters:** ["AC-9035-2026-11-21"]
**Row Count:** 1
**Results:**
```json
[
  {
    "flight_count": 1,
    "leg_count": 2,
    "segment_count": 3,
    "place_count": 3,
    "alias_count": 0
  }
]
```

### Query 4: Part B: Burst results summary
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM InventoryFlight WHERE Id IN (burst flight IDs)
```
**Parameters:** ["AC-9300-2026-11-21","AC-9301-2026-11-21","AC-9302-2026-11-21","AC-9303-2026-11-21","AC-9304-2026-11-21","AC-9305-2026-11-21","AC-9306-2026-11-21","AC-9307-2026-11-21","AC-9308-2026-11-21","AC-9309-2026-11-21"]
**Row Count:** 10
**Results:**
```json
[
  {
    "flightId": "AC-9300-2026-11-21",
    "persisted": true,
    "statusCode": 200
  },
  {
    "flightId": "AC-9301-2026-11-21",
    "persisted": true,
    "statusCode": 200
  },
  {
    "flightId": "AC-9302-2026-11-21",
    "persisted": true,
    "statusCode": 200
  },
  {
    "flightId": "AC-9303-2026-11-21",
    "persisted": true,
    "statusCode": 200
  },
  {
    "flightId": "AC-9304-2026-11-21",
    "persisted": true,
    "statusCode": 200
  },
  {
    "flightId": "AC-9305-2026-11-21",
    "persisted": true,
    "statusCode": 200
  },
  {
    "flightId": "AC-9306-2026-11-21",
    "persisted": true,
    "statusCode": 200
  },
  {
    "flightId": "AC-9307-2026-11-21",
    "persisted": true,
    "statusCode": 200
  },
  {
    "flightId": "AC-9308-2026-11-21",
    "persisted": true,
    "statusCode": 200
  },
  {
    "flightId": "AC-9309-2026-11-21",
    "persisted": true,
    "statusCode": 200
  }
]
```

## Assertions

✅ **Part A: Lambda success (large event)**: ✅ PASS
✅ **Part A: No functionError**: ✅ PASS
✅ **Part A: Large event completed within 30s (no timeout)**: ✅ PASS
✅ **Part A: InventoryFlight created**: ✅ PASS
✅ **Part A: All legs created (>=2)**: ✅ PASS
✅ **Part A: All segments created (>=1)**: ✅ PASS
✅ **Part A: All places created (>=3)**: ✅ PASS
✅ **Part B: All 10 burst Lambdas returned 200**: ✅ PASS
✅ **Part B: Burst completed within 60s (no timeout)**: ✅ PASS
✅ **Part B: All 10 burst events persisted (no dropped records)**: ✅ PASS

---
## Final Verdict: ✅ PASSED