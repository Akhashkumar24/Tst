# TC-52 - Validate marketing/operating partnership arrays map to InventoryFlightSegmentAlias.FlightLegAliasTypeCode

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T10:17:54.683Z
**Result:** ✅ PASSED
**Duration:** 14538ms

## Test Description
marketingFlights → FlightLegAliasTypeCode=MARKETING (CarrierCode=BR, Number=3083). operatingFlight → FlightLegAliasTypeCode=OPERATING (CarrierCode=EY). Both stored in BookingInventoryDataStore.InventoryFlightSegmentAlias. Partnership injected at segment level (not flight level).

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785925070647-79y1m8ezr"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8152-2026-11-19",
    "version": "178592507064729393",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8152"
    },
    "scheduledDepartureDate": "2026-11-19",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "INTERNATIONAL"
    ],
    "codeshare": "MARKETING",
    "flightPoints": [
      {
        "id": "AUH_1",
        "iataCode": "AUH",
        "city": "AUH",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-19T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YYZ_2",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-19T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-19-AUH-YYZ",
        "boardFlightPointId": "AUH_1",
        "offFlightPointId": "YYZ_2",
        "boardPointIataCode": "AUH",
        "offPointIataCode": "YYZ",
        "scheduledDepartureDateTime": "2026-11-19T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-19T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-19T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-19T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "AUH-YYZ"
        ],
        "partnership": {
          "operatingFlight": {
            "id": "EY-21-2026-11-19",
            "flightDesignator": {
              "carrierCode": "EY",
              "flightNumber": "21"
            }
          }
        }
      }
    ],
    "legs": [
      {
        "id": "AUH-YYZ",
        "boardFlightPointId": "AUH_1",
        "offFlightPointId": "YYZ_2",
        "boardPointIataCode": "AUH",
        "offPointIataCode": "YYZ",
        "scheduledDepartureDateTime": "2026-11-19T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-19T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-19T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-19T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8152-2026-11-19",
    "originFeedTimeStamp": "2026-08-05T10:17:50.647Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2585 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T10:17:50.647Z

## Database Verification

### Query 1: Case A: marketingFlights → InventoryFlightSegmentAlias
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightSegmentAlias" WHERE "InventoryFlightId" = $1
```
**Parameters:** ["AC-8052-2026-11-19"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8052-2026-11-19",
    "InventoryFlightSegmentId": "2026-11-19-YYZ-YVR",
    "Id": "BR-3083-2026-11-19",
    "FlightLegAliasTypeCode": "MARKETING",
    "CarrierCode": "BR",
    "Number": "3083",
    "RecordCorrelationId": "01KZ8PVQS4FEVC27PWQSS9MPJE",
    "RecordCreatedAt": "2026-08-05T10:17:46.533Z",
    "RecordModifiedAt": "2026-08-05T10:17:46.533Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785925063600832000"
  }
]
```

### Query 2: Case A: InventoryFlightSegment (for reference)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightSegment" WHERE "InventoryFlightId" = $1
```
**Parameters:** ["AC-8052-2026-11-19"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8052-2026-11-19",
    "Id": "2026-11-19-YYZ-YVR",
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YVR_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YVR",
    "LocalDepartureScheduleAt": "2026-11-19T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-19T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-19T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-19T14:30:00.000Z",
    "LegCount": 1,
    "TrafficRestrictions": null,
    "RecordCorrelationId": "01KZ8PVQS4FEVC27PWQSS9MPJE",
    "RecordCreatedAt": "2026-08-05T10:17:46.533Z",
    "RecordModifiedAt": "2026-08-05T10:17:46.533Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785925063600832000"
  }
]
```

### Query 3: Case B: operatingFlight → InventoryFlightSegmentAlias
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightSegmentAlias" WHERE "InventoryFlightId" = $1
```
**Parameters:** ["AC-8152-2026-11-19"]
**Row Count:** 0
**Results:**
```json
[]
```

### Query 4: Case B: InventoryFlightSegment (for reference)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightSegment" WHERE "InventoryFlightId" = $1
```
**Parameters:** ["AC-8152-2026-11-19"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8152-2026-11-19",
    "Id": "2026-11-19-AUH-YYZ",
    "BoardInventoryPlaceId": "AUH_1",
    "OffInventoryPlaceId": "YYZ_2",
    "BoardPlaceIATACode": "AUH",
    "OffPlaceIATACode": "YYZ",
    "LocalDepartureScheduleAt": "2026-11-19T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-19T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-19T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-19T14:30:00.000Z",
    "LegCount": 1,
    "TrafficRestrictions": null,
    "RecordCorrelationId": "01KZ8PVW08YBQRYK7321N73WC1",
    "RecordCreatedAt": "2026-08-05T10:17:50.856Z",
    "RecordModifiedAt": "2026-08-05T10:17:50.856Z",
    "RecordExpiredAt": null,
    "RecordVersion": "178592507064729400"
  }
]
```

## Assertions

✅ **Lambda success (Case B)**: ✅ PASS
✅ **Lambda success (Case A)**: ✅ PASS
✅ **Case A: Marketing alias created (rowCount>=1)**: ✅ PASS
✅ **Case A: FlightLegAliasTypeCode=MARKETING**: ✅ PASS
✅ **Case A: CarrierCode=BR**: ✅ PASS
✅ **Case A: Number=3083**: ✅ PASS
✅ **⚠️ FINDING: Operating alias NOT created — writer may not map operatingFlight to InventoryFlightSegmentAlias**: ✅ PASS

---
## Final Verdict: ✅ PASSED