# TC-60 - Validate aircraft/FIN swap updates EquipmentTypeCode correctly

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T10:24:48.162Z
**Result:** ✅ PASSED
**Duration:** 9713ms

## Test Description
Initial: EquipmentTypeCode=320. Update: EquipmentTypeCode=789. Verify fully replaced in InventoryFlightLeg, no duplicate.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785925484225-96u7c6ub6"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8060-2026-11-20",
    "version": "1785925484225927364",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8060"
    },
    "scheduledDepartureDate": "2026-11-20",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "INTERNATIONAL"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-20T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "LHR_2",
        "iataCode": "LHR",
        "city": "LHR",
        "country": "GB",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-20T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-20-YYZ-LHR",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "LHR_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "LHR",
        "scheduledDepartureDateTime": "2026-11-20T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-20T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-20T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-20T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-LHR"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-LHR",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "LHR_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "LHR",
        "scheduledDepartureDateTime": "2026-11-20T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-20T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-20T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-20T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "789",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 30
              },
              {
                "cabin": "W",
                "capacity": 21
              },
              {
                "cabin": "Y",
                "capacity": 247
              }
            ]
          },
          "acvTotalCapacity": 298,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 30
              },
              {
                "cabin": "W",
                "capacity": 21
              },
              {
                "cabin": "Y",
                "capacity": 247
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 30
              },
              {
                "cabin": "W",
                "capacity": 21
              },
              {
                "cabin": "Y",
                "capacity": 247
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 30
              },
              {
                "cabin": "W",
                "capacity": 21
              },
              {
                "cabin": "Y",
                "capacity": 247
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8060-2026-11-20",
    "originFeedTimeStamp": "2026-08-05T10:24:49.225Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "UPDATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2578 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T10:24:44.226Z

## Database Verification

### Query 1: InventoryFlightLeg after FIN swap
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8060-2026-11-20"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8060-2026-11-20",
    "Id": "YYZ-LHR",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8060",
    "OperatingNumber": "8060",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "LHR_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "LHR",
    "LocalDepartureScheduleAt": "2026-11-20T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-20T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-20T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-20T14:30:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "789",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 298,
    "ScheduledFittedAircraftConfigurationCode": "321",
    "ScheduledFittedBusinessSeatCapacity": 30,
    "ScheduledFittedPremiumEconomySeatCapacity": 21,
    "ScheduledFittedEconomySeatCapacity": 247,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 30,
    "OperationalSaleablePremiumEconomySeatCapacity": 21,
    "OperationalSaleableEconomySeatCapacity": 247,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 30,
    "ScheduledSaleablePremiumEconomySeatCapacity": 21,
    "ScheduledSaleableEconomySeatCapacity": 247,
    "OperationalFittedAircraftConfigurationCode": "321",
    "OperationalFittedBusinessSeatCapacity": 30,
    "OperationalFittedPremiumEconomySeatCapacity": 21,
    "OperationalFittedEconomySeatCapacity": 247,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T10:24:40.997Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T10:24:40.997Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T10:24:40.997Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T10:24:40.997Z",
    "RecordCorrelationId": "01KZ8Q8FWAZ41REBE19GTYNTYR",
    "RecordCreatedAt": "2026-08-05T10:24:40.997Z",
    "RecordModifiedAt": "2026-08-05T10:24:44.426Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785925484225927400"
  }
]
```

## Assertions

✅ **Still 1 leg (no duplicate)**: ✅ PASS
✅ **EquipmentTypeCode updated to 789**: ✅ PASS
✅ **TotalSeatCapacity updated to 298**: ✅ PASS
✅ **ScheduledFittedPremiumEconomySeatCapacity=21 (W cabin added)**: ✅ PASS

---
## Final Verdict: ✅ PASSED