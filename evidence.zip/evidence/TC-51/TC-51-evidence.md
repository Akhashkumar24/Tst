# TC-51 - Validate trafficRestrictions storage in InventoryFlightSegment

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T10:13:20.318Z
**Result:** ✅ PASSED
**Duration:** 13282ms

## Test Description
Case A: trafficRestrictions=['D','A']. Case B: []. Case C: omitted. Verify segment records created in all cases.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785924797660-bmxkacn3z"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8251-2026-11-19",
    "version": "178592479766053896",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8251"
    },
    "scheduledDepartureDate": "2026-11-19",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-19T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YUL_2",
        "iataCode": "YUL",
        "city": "YUL",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-19T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-19-YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-19T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-19T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-19T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-19T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YUL"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-19T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-19T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-19T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-19T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8251-2026-11-19",
    "originFeedTimeStamp": "2026-08-05T10:13:17.661Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2460 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T10:13:17.661Z

## Database Verification

### Query 1: Case A: trafficRestrictions=['D','A']
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightSegment" WHERE "InventoryFlightId" = $1
```
**Parameters:** ["AC-8051-2026-11-19"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8051-2026-11-19",
    "Id": "2026-11-19-YYZ-YUL",
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YUL_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YUL",
    "LocalDepartureScheduleAt": "2026-11-19T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-19T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-19T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-19T14:30:00.000Z",
    "LegCount": 1,
    "TrafficRestrictions": [
      "D",
      "A"
    ],
    "RecordCorrelationId": "01KZ8PKBVH6KPTKEWHPQ6GZ0D7",
    "RecordCreatedAt": "2026-08-05T10:13:12.177Z",
    "RecordModifiedAt": "2026-08-05T10:13:12.177Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924791986110000"
  }
]
```

### Query 2: Case B: trafficRestrictions=[]
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightSegment" WHERE "InventoryFlightId" = $1
```
**Parameters:** ["AC-8151-2026-11-19"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8151-2026-11-19",
    "Id": "2026-11-19-YYZ-YUL",
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YUL_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YUL",
    "LocalDepartureScheduleAt": "2026-11-19T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-19T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-19T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-19T14:30:00.000Z",
    "LegCount": 1,
    "TrafficRestrictions": [],
    "RecordCorrelationId": "01KZ8PKEPPG3RA8273D788CQN1",
    "RecordCreatedAt": "2026-08-05T10:13:15.094Z",
    "RecordModifiedAt": "2026-08-05T10:13:15.094Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924794891205600"
  }
]
```

### Query 3: Case C: trafficRestrictions omitted
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightSegment" WHERE "InventoryFlightId" = $1
```
**Parameters:** ["AC-8251-2026-11-19"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8251-2026-11-19",
    "Id": "2026-11-19-YYZ-YUL",
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YUL_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YUL",
    "LocalDepartureScheduleAt": "2026-11-19T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-19T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-19T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-19T14:30:00.000Z",
    "LegCount": 1,
    "TrafficRestrictions": null,
    "RecordCorrelationId": "01KZ8PKHCGSBW5J6H8K24902KQ",
    "RecordCreatedAt": "2026-08-05T10:13:17.840Z",
    "RecordModifiedAt": "2026-08-05T10:13:17.840Z",
    "RecordExpiredAt": null,
    "RecordVersion": "178592479766053900"
  }
]
```

## Assertions

✅ **Lambda success**: ✅ PASS
✅ **Case A: segment stored**: ✅ PASS
✅ **Case B: segment stored (empty restrictions)**: ✅ PASS
✅ **Case C: segment stored (omitted restrictions)**: ✅ PASS

---
## Final Verdict: ✅ PASSED