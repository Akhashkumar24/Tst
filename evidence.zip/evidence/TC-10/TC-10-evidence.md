# TC-10 - Verify carrier code format handling at writer level

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T07:45:34.161Z
**Result:** ✅ PASSED
**Duration:** 18664ms

## Test Description
Writer Lambda does not validate carrier format. Test verifies: valid '6X' persists correctly. Invalid formats ('12','X','6XYZ') are also persisted (writer has no validation). Documents actual writer behavior.

## Payload Sent to Lambda
```json
{
  "validPayload": {
    "meta": {
      "triggerEventLog": {
        "id": "tc-1785915922587-quqljmpms"
      },
      "version": "1.3.0"
    },
    "scheduleProcessedFlight": {
      "type": "dated-flight",
      "id": "6X-8010-2026-11-16",
      "version": "1785915922587178340",
      "flightDesignator": {
        "carrierCode": "6X",
        "flightNumber": "8010"
      },
      "scheduledDepartureDate": "2026-11-16",
      "dayOfOperation": "WED",
      "isCancelled": false,
      "characteristics": [
        "DOMESTIC"
      ],
      "codeshare": "OPERATING",
      "flightPoints": [
        {
          "id": "YYZ_1",
          "iataCode": "YYZ",
          "city": "YYZ",
          "country": "CA",
          "region": "NAMER",
          "continent": "ITC1",
          "departure": {
            "timings": [
              {
                "qualifier": "STD",
                "value": "2026-11-16T08:00:00"
              }
            ],
            "terminals": [
              {
                "code": "1"
              }
            ]
          }
        },
        {
          "id": "YUL_2",
          "iataCode": "YUL",
          "city": "YUL",
          "country": "CA",
          "region": "NAMER",
          "continent": "ITC1",
          "arrival": {
            "timings": [
              {
                "qualifier": "STA",
                "value": "2026-11-16T10:30:00"
              }
            ],
            "terminals": [
              {
                "code": "1"
              }
            ]
          }
        }
      ],
      "segments": [
        {
          "id": "2026-11-16-YYZ-YUL",
          "boardFlightPointId": "YYZ_1",
          "offFlightPointId": "YUL_2",
          "boardPointIataCode": "YYZ",
          "offPointIataCode": "YUL",
          "scheduledDepartureDateTime": "2026-11-16T08:00:00",
          "scheduledDepartureDateTimeUtc": "2026-11-16T12:00:00Z",
          "scheduledArrivalDateTime": "2026-11-16T10:30:00",
          "scheduledArrivalDateTimeUtc": "2026-11-16T14:30:00Z",
          "numberOfLegs": 1,
          "legIds": [
            "YYZ-YUL"
          ]
        }
      ],
      "legs": [
        {
          "id": "YYZ-YUL",
          "boardFlightPointId": "YYZ_1",
          "offFlightPointId": "YUL_2",
          "boardPointIataCode": "YYZ",
          "offPointIataCode": "YUL",
          "scheduledDepartureDateTime": "2026-11-16T08:00:00",
          "scheduledDepartureDateTimeUtc": "2026-11-16T12:00:00Z",
          "scheduledArrivalDateTime": "2026-11-16T10:30:00",
          "scheduledArrivalDateTimeUtc": "2026-11-16T14:30:00Z",
          "routingOrder": 1,
          "serviceType": "J",
          "aircraftEquipment": {
            "aircraftType": "320",
            "scheduledFittedConfiguration": {
              "code": "321",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            },
            "acvTotalCapacity": 170,
            "operationalSaleableConfiguration": {
              "code": "001",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            },
            "scheduledSaleableConfiguration": {
              "code": "001",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            },
            "operationalFittedConfiguration": {
              "code": "321",
              "configurationContents": [
                {
                  "cabin": "J",
                  "capacity": 14
                },
                {
                  "cabin": "Y",
                  "capacity": 156
                }
              ]
            }
          },
          "legDCSStatuses": {
            "acceptanceStatus": "OPEN",
            "generalStatus": "OPEN",
            "loadControlStatus": "OPEN",
            "boardingStatus": "NOT_OPEN"
          }
        }
      ]
    },
    "events": {
      "recordDomain": "SCHEDULE",
      "recordId": "6X-8010-2026-11-16",
      "originFeedTimeStamp": "2026-08-05T07:45:22.587Z",
      "events": [
        {
          "origin": "COMPARISON",
          "eventType": "CREATED"
        }
      ]
    }
  },
  "invalidPayloads": [
    {
      "meta": {
        "triggerEventLog": {
          "id": "tc-1785915925893-f8xccepc8"
        },
        "version": "1.3.0"
      },
      "scheduleProcessedFlight": {
        "type": "dated-flight",
        "id": "12-8010-2026-11-16",
        "version": "178591592589312122",
        "flightDesignator": {
          "carrierCode": "12",
          "flightNumber": "8010"
        },
        "scheduledDepartureDate": "2026-11-16",
        "dayOfOperation": "WED",
        "isCancelled": false,
        "characteristics": [
          "DOMESTIC"
        ],
        "codeshare": "OPERATING",
        "flightPoints": [
          {
            "id": "YYZ_1",
            "iataCode": "YYZ",
            "city": "YYZ",
            "country": "CA",
            "region": "NAMER",
            "continent": "ITC1",
            "departure": {
              "timings": [
                {
                  "qualifier": "STD",
                  "value": "2026-11-16T08:00:00"
                }
              ],
              "terminals": [
                {
                  "code": "1"
                }
              ]
            }
          },
          {
            "id": "YUL_2",
            "iataCode": "YUL",
            "city": "YUL",
            "country": "CA",
            "region": "NAMER",
            "continent": "ITC1",
            "arrival": {
              "timings": [
                {
                  "qualifier": "STA",
                  "value": "2026-11-16T10:30:00"
                }
              ],
              "terminals": [
                {
                  "code": "1"
                }
              ]
            }
          }
        ],
        "segments": [
          {
            "id": "2026-11-16-YYZ-YUL",
            "boardFlightPointId": "YYZ_1",
            "offFlightPointId": "YUL_2",
            "boardPointIataCode": "YYZ",
            "offPointIataCode": "YUL",
            "scheduledDepartureDateTime": "2026-11-16T08:00:00",
            "scheduledDepartureDateTimeUtc": "2026-11-16T12:00:00Z",
            "scheduledArrivalDateTime": "2026-11-16T10:30:00",
            "scheduledArrivalDateTimeUtc": "2026-11-16T14:30:00Z",
            "numberOfLegs": 1,
            "legIds": [
              "YYZ-YUL"
            ]
          }
        ],
        "legs": [
          {
            "id": "YYZ-YUL",
            "boardFlightPointId": "YYZ_1",
            "offFlightPointId": "YUL_2",
            "boardPointIataCode": "YYZ",
            "offPointIataCode": "YUL",
            "scheduledDepartureDateTime": "2026-11-16T08:00:00",
            "scheduledDepartureDateTimeUtc": "2026-11-16T12:00:00Z",
            "scheduledArrivalDateTime": "2026-11-16T10:30:00",
            "scheduledArrivalDateTimeUtc": "2026-11-16T14:30:00Z",
            "routingOrder": 1,
            "serviceType": "J",
            "aircraftEquipment": {
              "aircraftType": "320",
              "scheduledFittedConfiguration": {
                "code": "321",
                "configurationContents": [
                  {
                    "cabin": "J",
                    "capacity": 14
                  },
                  {
                    "cabin": "Y",
                    "capacity": 156
                  }
                ]
              },
              "acvTotalCapacity": 170,
              "operationalSaleableConfiguration": {
                "code": "001",
                "configurationContents": [
                  {
                    "cabin": "J",
                    "capacity": 14
                  },
                  {
                    "cabin": "Y",
                    "capacity": 156
                  }
                ]
              },
              "scheduledSaleableConfiguration": {
                "code": "001",
                "configurationContents": [
                  {
                    "cabin": "J",
                    "capacity": 14
                  },
                  {
                    "cabin": "Y",
                    "capacity": 156
                  }
                ]
              },
              "operationalFittedConfiguration": {
                "code": "321",
                "configurationContents": [
                  {
                    "cabin": "J",
                    "capacity": 14
                  },
                  {
                    "cabin": "Y",
                    "capacity": 156
                  }
                ]
              }
            },
            "legDCSStatuses": {
              "acceptanceStatus": "OPEN",
              "generalStatus": "OPEN",
              "loadControlStatus": "OPEN",
              "boardingStatus": "NOT_OPEN"
            }
          }
        ]
      },
      "events": {
        "recordDomain": "SCHEDULE",
        "recordId": "12-8010-2026-11-16",
        "originFeedTimeStamp": "2026-08-05T07:45:25.893Z",
        "events": [
          {
            "origin": "COMPARISON",
            "eventType": "CREATED"
          }
        ]
      }
    },
    {
      "meta": {
        "triggerEventLog": {
          "id": "tc-1785915928673-4h7dx3l5b"
        },
        "version": "1.3.0"
      },
      "scheduleProcessedFlight": {
        "type": "dated-flight",
        "id": "X-8010-2026-11-16",
        "version": "178591592867379187",
        "flightDesignator": {
          "carrierCode": "X",
          "flightNumber": "8010"
        },
        "scheduledDepartureDate": "2026-11-16",
        "dayOfOperation": "WED",
        "isCancelled": false,
        "characteristics": [
          "DOMESTIC"
        ],
        "codeshare": "OPERATING",
        "flightPoints": [
          {
            "id": "YYZ_1",
            "iataCode": "YYZ",
            "city": "YYZ",
            "country": "CA",
            "region": "NAMER",
            "continent": "ITC1",
            "departure": {
              "timings": [
                {
                  "qualifier": "STD",
                  "value": "2026-11-16T08:00:00"
                }
              ],
              "terminals": [
                {
                  "code": "1"
                }
              ]
            }
          },
          {
            "id": "YUL_2",
            "iataCode": "YUL",
            "city": "YUL",
            "country": "CA",
            "region": "NAMER",
            "continent": "ITC1",
            "arrival": {
              "timings": [
                {
                  "qualifier": "STA",
                  "value": "2026-11-16T10:30:00"
                }
              ],
              "terminals": [
                {
                  "code": "1"
                }
              ]
            }
          }
        ],
        "segments": [
          {
            "id": "2026-11-16-YYZ-YUL",
            "boardFlightPointId": "YYZ_1",
            "offFlightPointId": "YUL_2",
            "boardPointIataCode": "YYZ",
            "offPointIataCode": "YUL",
            "scheduledDepartureDateTime": "2026-11-16T08:00:00",
            "scheduledDepartureDateTimeUtc": "2026-11-16T12:00:00Z",
            "scheduledArrivalDateTime": "2026-11-16T10:30:00",
            "scheduledArrivalDateTimeUtc": "2026-11-16T14:30:00Z",
            "numberOfLegs": 1,
            "legIds": [
              "YYZ-YUL"
            ]
          }
        ],
        "legs": [
          {
            "id": "YYZ-YUL",
            "boardFlightPointId": "YYZ_1",
            "offFlightPointId": "YUL_2",
            "boardPointIataCode": "YYZ",
            "offPointIataCode": "YUL",
            "scheduledDepartureDateTime": "2026-11-16T08:00:00",
            "scheduledDepartureDateTimeUtc": "2026-11-16T12:00:00Z",
            "scheduledArrivalDateTime": "2026-11-16T10:30:00",
            "scheduledArrivalDateTimeUtc": "2026-11-16T14:30:00Z",
            "routingOrder": 1,
            "serviceType": "J",
            "aircraftEquipment": {
              "aircraftType": "320",
              "scheduledFittedConfiguration": {
                "code": "321",
                "configurationContents": [
                  {
                    "cabin": "J",
                    "capacity": 14
                  },
                  {
                    "cabin": "Y",
                    "capacity": 156
                  }
                ]
              },
              "acvTotalCapacity": 170,
              "operationalSaleableConfiguration": {
                "code": "001",
                "configurationContents": [
                  {
                    "cabin": "J",
                    "capacity": 14
                  },
                  {
                    "cabin": "Y",
                    "capacity": 156
                  }
                ]
              },
              "scheduledSaleableConfiguration": {
                "code": "001",
                "configurationContents": [
                  {
                    "cabin": "J",
                    "capacity": 14
                  },
                  {
                    "cabin": "Y",
                    "capacity": 156
                  }
                ]
              },
              "operationalFittedConfiguration": {
                "code": "321",
                "configurationContents": [
                  {
                    "cabin": "J",
                    "capacity": 14
                  },
                  {
                    "cabin": "Y",
                    "capacity": 156
                  }
                ]
              }
            },
            "legDCSStatuses": {
              "acceptanceStatus": "OPEN",
              "generalStatus": "OPEN",
              "loadControlStatus": "OPEN",
              "boardingStatus": "NOT_OPEN"
            }
          }
        ]
      },
      "events": {
        "recordDomain": "SCHEDULE",
        "recordId": "X-8010-2026-11-16",
        "originFeedTimeStamp": "2026-08-05T07:45:28.673Z",
        "events": [
          {
            "origin": "COMPARISON",
            "eventType": "CREATED"
          }
        ]
      }
    },
    {
      "meta": {
        "triggerEventLog": {
          "id": "tc-1785915931473-2eyuw3k9p"
        },
        "version": "1.3.0"
      },
      "scheduleProcessedFlight": {
        "type": "dated-flight",
        "id": "6XYZ-8010-2026-11-16",
        "version": "1785915931473845391",
        "flightDesignator": {
          "carrierCode": "6XYZ",
          "flightNumber": "8010"
        },
        "scheduledDepartureDate": "2026-11-16",
        "dayOfOperation": "WED",
        "isCancelled": false,
        "characteristics": [
          "DOMESTIC"
        ],
        "codeshare": "OPERATING",
        "flightPoints": [
          {
            "id": "YYZ_1",
            "iataCode": "YYZ",
            "city": "YYZ",
            "country": "CA",
            "region": "NAMER",
            "continent": "ITC1",
            "departure": {
              "timings": [
                {
                  "qualifier": "STD",
                  "value": "2026-11-16T08:00:00"
                }
              ],
              "terminals": [
                {
                  "code": "1"
                }
              ]
            }
          },
          {
            "id": "YUL_2",
            "iataCode": "YUL",
            "city": "YUL",
            "country": "CA",
            "region": "NAMER",
            "continent": "ITC1",
            "arrival": {
              "timings": [
                {
                  "qualifier": "STA",
                  "value": "2026-11-16T10:30:00"
                }
              ],
              "terminals": [
                {
                  "code": "1"
                }
              ]
            }
          }
        ],
        "segments": [
          {
            "id": "2026-11-16-YYZ-YUL",
            "boardFlightPointId": "YYZ_1",
            "offFlightPointId": "YUL_2",
            "boardPointIataCode": "YYZ",
            "offPointIataCode": "YUL",
            "scheduledDepartureDateTime": "2026-11-16T08:00:00",
            "scheduledDepartureDateTimeUtc": "2026-11-16T12:00:00Z",
            "scheduledArrivalDateTime": "2026-11-16T10:30:00",
            "scheduledArrivalDateTimeUtc": "2026-11-16T14:30:00Z",
            "numberOfLegs": 1,
            "legIds": [
              "YYZ-YUL"
            ]
          }
        ],
        "legs": [
          {
            "id": "YYZ-YUL",
            "boardFlightPointId": "YYZ_1",
            "offFlightPointId": "YUL_2",
            "boardPointIataCode": "YYZ",
            "offPointIataCode": "YUL",
            "scheduledDepartureDateTime": "2026-11-16T08:00:00",
            "scheduledDepartureDateTimeUtc": "2026-11-16T12:00:00Z",
            "scheduledArrivalDateTime": "2026-11-16T10:30:00",
            "scheduledArrivalDateTimeUtc": "2026-11-16T14:30:00Z",
            "routingOrder": 1,
            "serviceType": "J",
            "aircraftEquipment": {
              "aircraftType": "320",
              "scheduledFittedConfiguration": {
                "code": "321",
                "configurationContents": [
                  {
                    "cabin": "J",
                    "capacity": 14
                  },
                  {
                    "cabin": "Y",
                    "capacity": 156
                  }
                ]
              },
              "acvTotalCapacity": 170,
              "operationalSaleableConfiguration": {
                "code": "001",
                "configurationContents": [
                  {
                    "cabin": "J",
                    "capacity": 14
                  },
                  {
                    "cabin": "Y",
                    "capacity": 156
                  }
                ]
              },
              "scheduledSaleableConfiguration": {
                "code": "001",
                "configurationContents": [
                  {
                    "cabin": "J",
                    "capacity": 14
                  },
                  {
                    "cabin": "Y",
                    "capacity": 156
                  }
                ]
              },
              "operationalFittedConfiguration": {
                "code": "321",
                "configurationContents": [
                  {
                    "cabin": "J",
                    "capacity": 14
                  },
                  {
                    "cabin": "Y",
                    "capacity": 156
                  }
                ]
              }
            },
            "legDCSStatuses": {
              "acceptanceStatus": "OPEN",
              "generalStatus": "OPEN",
              "loadControlStatus": "OPEN",
              "boardingStatus": "NOT_OPEN"
            }
          }
        ]
      },
      "events": {
        "recordDomain": "SCHEDULE",
        "recordId": "6XYZ-8010-2026-11-16",
        "originFeedTimeStamp": "2026-08-05T07:45:31.473Z",
        "events": [
          {
            "origin": "COMPARISON",
            "eventType": "CREATED"
          }
        ]
      }
    }
  ]
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 9885 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** N/A
- **Function Error:** None
- **Invoked At:** N/A

## Database Verification

### Query 1: Valid carrier '6X' — InventoryFlight
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["6X-8010-2026-11-16"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "6X-8010-2026-11-16",
    "MarketingCarrierCode": "6X",
    "OperatingCarrierCode": "6X",
    "MarketingNumber": "8010",
    "OperatingNumber": "8010",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-15T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8E4PD6K243NSJ3XQQF0NK2",
    "RecordCreatedAt": "2026-08-05T07:45:22.854Z",
    "RecordModifiedAt": "2026-08-05T07:45:22.854Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785915922587178200"
  }
]
```

### Query 2: Valid carrier '6X' — FlightState
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["6X","8010","YYZ","2026-11-16"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "6X",
    "OperatingFlightNumber": "8010",
    "OperationalSuffix": null,
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YUL",
    "LocalDepartureScheduledDate": "2026-11-15T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T07:45:22.854Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T07:45:22.854Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T07:45:22.854Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T07:45:22.854Z",
    "CurrentBagFlightLoadStatusCode": null,
    "PreviousBagFlightLoadStatusCode": null,
    "UTCBagFlightLoadStatusModifiedAt": null,
    "RecordCorrelationId": "01KZ8E4PD6K243NSJ3XQQF0NK2",
    "RecordCreatedAt": "2026-08-05T07:45:22.854Z",
    "RecordModifiedAt": "2026-08-05T07:45:22.854Z",
    "RecordExpiredAt": "2027-08-05T07:45:22.854Z",
    "RecordVersion": "1785915922587178200",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

### Query 3: Carrier '12' — InventoryFlight
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["12-8010-2026-11-16"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "12-8010-2026-11-16",
    "MarketingCarrierCode": "12",
    "OperatingCarrierCode": "12",
    "MarketingNumber": "8010",
    "OperatingNumber": "8010",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-15T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8E4SJF012YGNZP87F7YZYB",
    "RecordCreatedAt": "2026-08-05T07:45:26.096Z",
    "RecordModifiedAt": "2026-08-05T07:45:26.096Z",
    "RecordExpiredAt": null,
    "RecordVersion": "178591592589312130"
  }
]
```

### Query 4: Carrier 'X' — InventoryFlight
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["X-8010-2026-11-16"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "X-8010-2026-11-16",
    "MarketingCarrierCode": "X ",
    "OperatingCarrierCode": "X ",
    "MarketingNumber": "8010",
    "OperatingNumber": "8010",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-15T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8E4WB0T96TSQRV9XE9W59F",
    "RecordCreatedAt": "2026-08-05T07:45:28.928Z",
    "RecordModifiedAt": "2026-08-05T07:45:28.928Z",
    "RecordExpiredAt": null,
    "RecordVersion": "178591592867379200"
  }
]
```

### Query 5: Carrier '6XYZ' — InventoryFlight
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["6XYZ-8010-2026-11-16"]
**Row Count:** 0
**Results:**
```json
[]
```

## Assertions

✅ **Lambda 200 for valid carrier 6X**: ✅ PASS
✅ **Valid carrier 6X — InventoryFlight created**: ✅ PASS
✅ **Valid carrier 6X — FlightState created**: ✅ PASS
✅ **Lambda 200 for carrier '12' (no crash)**: ✅ PASS
✅ **Lambda 200 for carrier 'X' (no crash)**: ✅ PASS
✅ **Lambda 200 for carrier '6XYZ' (no crash)**: ✅ PASS
✅ **Carrier '12' persistence documented**: ✅ PASS
✅ **Carrier 'X' persistence documented**: ✅ PASS
✅ **Carrier '6XYZ' persistence documented**: ✅ PASS

---
## Final Verdict: ✅ PASSED