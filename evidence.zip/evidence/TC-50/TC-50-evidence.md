# TC-50 - Validate full timing-qualifier enum mapping to InventoryFlightPlace columns

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T10:13:07.019Z
**Result:** ✅ PASSED
**Duration:** 8286ms

## Test Description
Ingest event with all 10 timing qualifiers (STD, STA, ETD_OFF_BLOCK, ETD_TAKEOFF, ETA_TOUCHDOWN, ETA_ON_BLOCK, ATD_OFF_BLOCK, ATD_TAKEOFF, ATA_TOUCHDOWN, ATA_ON_BLOCK). Verify each maps to correct column in BookingInventoryDataStore.InventoryFlightPlace.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785924781712-e4oksvryc"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8050-2026-11-19",
    "version": "1785924781712746010",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8050"
    },
    "scheduledDepartureDate": "2026-11-19",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-19T08:00:00"
            },
            {
              "qualifier": "ETD_OFF_BLOCK",
              "value": "2026-11-19T07:50:00"
            },
            {
              "qualifier": "ETD_TAKEOFF",
              "value": "2026-11-19T08:05:00"
            },
            {
              "qualifier": "ATD_OFF_BLOCK",
              "value": "2026-11-19T07:55:00"
            },
            {
              "qualifier": "ATD_TAKEOFF",
              "value": "2026-11-19T08:10:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YUL_2",
        "iataCode": "YUL",
        "city": "YUL",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-19T10:30:00"
            },
            {
              "qualifier": "ETA_TOUCHDOWN",
              "value": "2026-11-19T10:25:00"
            },
            {
              "qualifier": "ETA_ON_BLOCK",
              "value": "2026-11-19T10:35:00"
            },
            {
              "qualifier": "ATA_TOUCHDOWN",
              "value": "2026-11-19T10:28:00"
            },
            {
              "qualifier": "ATA_ON_BLOCK",
              "value": "2026-11-19T10:38:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-19-YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-19T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-19T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-19T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-19T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YUL"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-19T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-19T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-19T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-19T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8050-2026-11-19",
    "originFeedTimeStamp": "2026-08-05T10:13:01.712Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2935 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T10:13:01.713Z

## Database Verification

### Query 1: InventoryFlightPlace (all timing columns)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightPlace" WHERE "InventoryFlightId" = $1
```
**Parameters:** ["AC-8050-2026-11-19"]
**Row Count:** 2
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8050-2026-11-19",
    "InventoryPlaceId": "YYZ_1",
    "PlaceIATACode": "YYZ",
    "PlaceCityCode": "YYZ",
    "CountryCode": "CA",
    "InventoryPlaceRegionCode": "NAMER",
    "InventoryPlaceContinentCode": "ITC1",
    "LocalScheduledDepartureAt": "2026-11-19T02:30:00.000Z",
    "LocalScheduledArrivalAt": null,
    "LocalEstimatedOffBlockAt": "2026-11-19T02:20:00.000Z",
    "LocalEstimatedTakeOffAt": "2026-11-19T02:35:00.000Z",
    "LocalEstimatedTouchdownAt": null,
    "LocalEstimatedOnBlockAt": null,
    "LocalActualOffBlockAt": "2026-11-19T02:25:00.000Z",
    "LocalActualTakeOffAt": "2026-11-19T02:40:00.000Z",
    "LocalActualTouchdownAt": null,
    "LocalActualOnBlockAt": null,
    "Terminals": [
      {
        "code": "1"
      }
    ],
    "RecordCorrelationId": "01KZ8PK1TPRFDPXMHCQQHYKJVZ",
    "RecordCreatedAt": "2026-08-05T10:13:01.910Z",
    "RecordModifiedAt": "2026-08-05T10:13:01.910Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924781712746000"
  },
  {
    "InventoryFlightId": "AC-8050-2026-11-19",
    "InventoryPlaceId": "YUL_2",
    "PlaceIATACode": "YUL",
    "PlaceCityCode": "YUL",
    "CountryCode": "CA",
    "InventoryPlaceRegionCode": "NAMER",
    "InventoryPlaceContinentCode": "ITC1",
    "LocalScheduledDepartureAt": null,
    "LocalScheduledArrivalAt": "2026-11-19T05:00:00.000Z",
    "LocalEstimatedOffBlockAt": null,
    "LocalEstimatedTakeOffAt": null,
    "LocalEstimatedTouchdownAt": "2026-11-19T04:55:00.000Z",
    "LocalEstimatedOnBlockAt": "2026-11-19T05:05:00.000Z",
    "LocalActualOffBlockAt": null,
    "LocalActualTakeOffAt": null,
    "LocalActualTouchdownAt": "2026-11-19T04:58:00.000Z",
    "LocalActualOnBlockAt": "2026-11-19T05:08:00.000Z",
    "Terminals": [
      {
        "code": "1"
      }
    ],
    "RecordCorrelationId": "01KZ8PK1TPRFDPXMHCQQHYKJVZ",
    "RecordCreatedAt": "2026-08-05T10:13:01.910Z",
    "RecordModifiedAt": "2026-08-05T10:13:01.910Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924781712746000"
  }
]
```

### Query 2: InventoryFlightLeg
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8050-2026-11-19"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8050-2026-11-19",
    "Id": "YYZ-YUL",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8050",
    "OperatingNumber": "8050",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YUL_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YUL",
    "LocalDepartureScheduleAt": "2026-11-19T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-19T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-19T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-19T14:30:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "320",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 170,
    "ScheduledFittedAircraftConfigurationCode": "321",
    "ScheduledFittedBusinessSeatCapacity": 14,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 156,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 14,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 156,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 14,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 156,
    "OperationalFittedAircraftConfigurationCode": "321",
    "OperationalFittedBusinessSeatCapacity": 14,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 156,
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T10:13:01.910Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T10:13:01.910Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T10:13:01.910Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T10:13:01.910Z",
    "RecordCorrelationId": "01KZ8PK1TPRFDPXMHCQQHYKJVZ",
    "RecordCreatedAt": "2026-08-05T10:13:01.910Z",
    "RecordModifiedAt": "2026-08-05T10:13:01.910Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785924781712746000"
  }
]
```

### Query 3: FlightState
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8050","YYZ","2026-11-19"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8050",
    "OperationalSuffix": null,
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YUL",
    "LocalDepartureScheduledDate": "2026-11-18T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T10:13:01.910Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T10:13:01.910Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T10:13:01.910Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T10:13:01.910Z",
    "CurrentBagFlightLoadStatusCode": null,
    "PreviousBagFlightLoadStatusCode": null,
    "UTCBagFlightLoadStatusModifiedAt": null,
    "RecordCorrelationId": "01KZ8PK1TPRFDPXMHCQQHYKJVZ",
    "RecordCreatedAt": "2026-08-05T10:13:01.910Z",
    "RecordModifiedAt": "2026-08-05T10:13:01.910Z",
    "RecordExpiredAt": "2027-08-05T10:13:01.910Z",
    "RecordVersion": "1785924781712746000",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

## Assertions

✅ **Lambda success**: ✅ PASS
✅ **InventoryFlightPlace records exist**: ✅ PASS
✅ **FlightState record exists**: ✅ PASS
✅ **Departure: LocalScheduledDepartureAt populated (STD)**: ✅ PASS
✅ **Departure: LocalEstimatedOffBlockAt populated (ETD_OFF_BLOCK)**: ✅ PASS
✅ **Departure: LocalEstimatedTakeOffAt populated (ETD_TAKEOFF)**: ✅ PASS
✅ **Departure: LocalActualOffBlockAt populated (ATD_OFF_BLOCK)**: ✅ PASS
✅ **Departure: LocalActualTakeOffAt populated (ATD_TAKEOFF)**: ✅ PASS
✅ **Arrival: LocalScheduledArrivalAt populated (STA)**: ✅ PASS
✅ **Arrival: LocalEstimatedTouchdownAt populated (ETA_TOUCHDOWN)**: ✅ PASS
✅ **Arrival: LocalEstimatedOnBlockAt populated (ETA_ON_BLOCK)**: ✅ PASS
✅ **Arrival: LocalActualTouchdownAt populated (ATA_TOUCHDOWN)**: ✅ PASS
✅ **Arrival: LocalActualOnBlockAt populated (ATA_ON_BLOCK)**: ✅ PASS

---
## Final Verdict: ✅ PASSED