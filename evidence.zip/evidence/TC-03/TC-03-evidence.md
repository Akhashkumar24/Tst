# TC-03 - Validate update of an existing flight record (upsert-update)

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T07:27:24.390Z
**Result:** ✅ PASSED
**Duration:** 7781ms

## Test Description
Ingest event, then ingest updated event (terminal change). Verify update in-place, no duplicate, RecordModifiedAt refreshed.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785914840354-clojhrzeb"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8003-2026-11-15",
    "version": "1785914840354811074",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8003"
    },
    "scheduledDepartureDate": "2026-11-15",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YOW_1",
        "iataCode": "YOW",
        "city": "YOW",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-15T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "5"
            }
          ]
        }
      },
      {
        "id": "YUL_2",
        "iataCode": "YUL",
        "city": "YUL",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-15T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-15-YOW-YUL",
        "boardFlightPointId": "YOW_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YOW",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-15T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-15T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-15T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-15T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YOW-YUL"
        ]
      }
    ],
    "legs": [
      {
        "id": "YOW-YUL",
        "boardFlightPointId": "YOW_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YOW",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-15T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-15T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-15T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-15T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8003-2026-11-15",
    "originFeedTimeStamp": "2026-08-05T07:27:25.354Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "UPDATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2461 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T07:27:20.354Z

## Database Verification

### Query 1: After initial insert
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8003-2026-11-15"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8003-2026-11-15",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8003",
    "OperatingNumber": "8003",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-14T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8D3HV27W0BJJGXQRQRDRVR",
    "RecordCreatedAt": "2026-08-05T06:56:14.520Z",
    "RecordModifiedAt": "2026-08-05T07:27:16.834Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785914836609182200"
  }
]
```

### Query 2: After update (terminal change)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8003-2026-11-15"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8003-2026-11-15",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8003",
    "OperatingNumber": "8003",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-14T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8D3NG2BA54TZ9XK3WW3CAW",
    "RecordCreatedAt": "2026-08-05T06:56:14.520Z",
    "RecordModifiedAt": "2026-08-05T07:27:20.578Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785914840354811100"
  }
]
```

### Query 3: InventoryFlightPlace after update
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightPlace" WHERE "InventoryFlightId" = $1
```
**Parameters:** ["AC-8003-2026-11-15"]
**Row Count:** 2
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8003-2026-11-15",
    "InventoryPlaceId": "YOW_1",
    "PlaceIATACode": "YOW",
    "PlaceCityCode": "YOW",
    "CountryCode": "CA",
    "InventoryPlaceRegionCode": "NAMER",
    "InventoryPlaceContinentCode": "ITC1",
    "LocalScheduledDepartureAt": "2026-11-15T02:30:00.000Z",
    "LocalScheduledArrivalAt": null,
    "LocalEstimatedOffBlockAt": null,
    "LocalEstimatedTakeOffAt": null,
    "LocalEstimatedTouchdownAt": null,
    "LocalEstimatedOnBlockAt": null,
    "LocalActualOffBlockAt": null,
    "LocalActualTakeOffAt": null,
    "LocalActualTouchdownAt": null,
    "LocalActualOnBlockAt": null,
    "Terminals": [
      {
        "code": "5"
      }
    ],
    "RecordCorrelationId": "01KZ8D3NG2BA54TZ9XK3WW3CAW",
    "RecordCreatedAt": "2026-08-05T06:56:14.520Z",
    "RecordModifiedAt": "2026-08-05T07:27:20.578Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785914840354811100"
  },
  {
    "InventoryFlightId": "AC-8003-2026-11-15",
    "InventoryPlaceId": "YUL_2",
    "PlaceIATACode": "YUL",
    "PlaceCityCode": "YUL",
    "CountryCode": "CA",
    "InventoryPlaceRegionCode": "NAMER",
    "InventoryPlaceContinentCode": "ITC1",
    "LocalScheduledDepartureAt": null,
    "LocalScheduledArrivalAt": "2026-11-15T05:00:00.000Z",
    "LocalEstimatedOffBlockAt": null,
    "LocalEstimatedTakeOffAt": null,
    "LocalEstimatedTouchdownAt": null,
    "LocalEstimatedOnBlockAt": null,
    "LocalActualOffBlockAt": null,
    "LocalActualTakeOffAt": null,
    "LocalActualTouchdownAt": null,
    "LocalActualOnBlockAt": null,
    "Terminals": [
      {
        "code": "1"
      }
    ],
    "RecordCorrelationId": "01KZ8D3NG2BA54TZ9XK3WW3CAW",
    "RecordCreatedAt": "2026-08-05T06:56:14.520Z",
    "RecordModifiedAt": "2026-08-05T07:27:20.578Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785914840354811100"
  }
]
```

## Assertions

✅ **Lambda success (insert)**: ✅ PASS
✅ **Lambda success (update)**: ✅ PASS
✅ **Still only 1 InventoryFlight row (no duplicate)**: ✅ PASS
✅ **RecordModifiedAt refreshed**: ✅ PASS
✅ **Terminal updated to 5**: ✅ PASS

---
## Final Verdict: ✅ PASSED