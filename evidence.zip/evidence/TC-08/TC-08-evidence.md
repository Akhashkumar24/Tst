# TC-08 - Validate DCS status fields and modified timestamps in FlightState

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T07:27:51.692Z
**Result:** ✅ PASSED
**Duration:** 3990ms

## Test Description
Ingest event with specific DCS statuses. Verify FlightState columns: CurrentFlightAcceptanceStatusCode, CurrentFlightGeneralStatusCode, CurrentFlightLoadControlStatusCode, CurrentFlightBoardingStatusCode and their ModifiedAt timestamps.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785914867703-gci407sup"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8008-2026-11-15",
    "version": "1785914867703450806",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8008"
    },
    "scheduledDepartureDate": "2026-11-15",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-15T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YVR_2",
        "iataCode": "YVR",
        "city": "YVR",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-15T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-15-YYZ-YVR",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YVR_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YVR",
        "scheduledDepartureDateTime": "2026-11-15T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-15T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-15T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-15T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YVR"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-YVR",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YVR_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YVR",
        "scheduledDepartureDateTime": "2026-11-15T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-15T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-15T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-15T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "GATED",
          "generalStatus": "OPEN",
          "loadControlStatus": "CONTROL_IGNORED",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8008-2026-11-15",
    "originFeedTimeStamp": "2026-08-05T07:27:47.703Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2473 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T07:27:47.703Z

## Database Verification

### Query 1: FlightState DCS statuses
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT 
      "OperatingCarrierCode",
      "OperatingFlightNumber",
      "DepartureAirportIATACode",
      "ArrivalAirportIATACode",
      "LocalDepartureScheduledDate",
      "CurrentFlightAcceptanceStatusCode",
      "CurrentFlightGeneralStatusCode",
      "CurrentFlightLoadControlStatusCode",
      "CurrentFlightBoardingStatusCode",
      "PreviousFlightAcceptanceStatusCode",
      "PreviousFlightGeneralStatusCode",
      "PreviousFlightLoadControlStatusCode",
      "PreviousFlightBoardingStatusCode",
      "UTCFlightAcceptanceStatusModifiedAt",
      "UTCFlightGeneralStatusModifiedAt",
      "UTCFlightLoadControlStatusModifiedAt",
      "UTCFlightBoardingStatusModifiedAt",
      "RecordCreatedAt",
      "RecordModifiedAt",
      "RecordVersion",
      "SourceCreatedBy"
    FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8008","YYZ","2026-11-15"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8008",
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YVR",
    "LocalDepartureScheduledDate": "2026-11-14T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "GATED",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "CONTROL_IGNORED",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T06:56:48.801Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T06:56:48.801Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T06:56:48.801Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T06:56:48.801Z",
    "RecordCreatedAt": "2026-08-05T06:56:48.801Z",
    "RecordModifiedAt": "2026-08-05T07:27:47.899Z",
    "RecordVersion": "1785914867703451000",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

### Query 2: InventoryFlightLeg
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlightLeg" WHERE "InventoryFlightId" = $1 ORDER BY "RecordCreatedAt"
```
**Parameters:** ["AC-8008-2026-11-15"]
**Row Count:** 1
**Results:**
```json
[
  {
    "InventoryFlightId": "AC-8008-2026-11-15",
    "Id": "YYZ-YVR",
    "MarketingCarrierCode": "AC",
    "MarketingNumber": "8008",
    "OperatingNumber": "8008",
    "OperationalSuffix": null,
    "BoardInventoryPlaceId": "YYZ_1",
    "OffInventoryPlaceId": "YVR_2",
    "BoardPlaceIATACode": "YYZ",
    "OffPlaceIATACode": "YVR",
    "LocalDepartureScheduleAt": "2026-11-15T02:30:00.000Z",
    "UTCDepartureScheduleAt": "2026-11-15T12:00:00.000Z",
    "LocalArrivalScheduleAt": "2026-11-15T05:00:00.000Z",
    "UTCArrivalScheduleAt": "2026-11-15T14:30:00.000Z",
    "SequenceNumber": 1,
    "FlightServiceTypeCode": "J",
    "EquipmentTypeCode": "320",
    "OperatingCarrierCode": "AC",
    "OperatingCarrierName": null,
    "TotalSeatCapacity": 170,
    "ScheduledFittedAircraftConfigurationCode": "321",
    "ScheduledFittedBusinessSeatCapacity": 14,
    "ScheduledFittedPremiumEconomySeatCapacity": null,
    "ScheduledFittedEconomySeatCapacity": 156,
    "OperationalSaleableAircraftConfigurationCode": "001",
    "OperationalSaleableBusinessSeatCapacity": 14,
    "OperationalSaleablePremiumEconomySeatCapacity": null,
    "OperationalSaleableEconomySeatCapacity": 156,
    "ScheduledSaleableAircraftConfigurationCode": "001",
    "ScheduledSaleableBusinessSeatCapacity": 14,
    "ScheduledSaleablePremiumEconomySeatCapacity": null,
    "ScheduledSaleableEconomySeatCapacity": 156,
    "OperationalFittedAircraftConfigurationCode": "321",
    "OperationalFittedBusinessSeatCapacity": 14,
    "OperationalFittedPremiumEconomySeatCapacity": null,
    "OperationalFittedEconomySeatCapacity": 156,
    "CurrentFlightAcceptanceStatusCode": "GATED",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "CONTROL_IGNORED",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "FlightAcceptanceStatusModifiedAt": "2026-08-05T06:56:48.801Z",
    "FlightGeneralStatusModifiedAt": "2026-08-05T06:56:48.801Z",
    "FlightLoadControlStatusModifiedAt": "2026-08-05T06:56:48.801Z",
    "FlightBoardingStatusModifiedAt": "2026-08-05T06:56:48.801Z",
    "RecordCorrelationId": "01KZ8D4G5V4NBZPB5JNSTDWA2Z",
    "RecordCreatedAt": "2026-08-05T06:56:48.801Z",
    "RecordModifiedAt": "2026-08-05T07:27:47.899Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785914867703451000"
  }
]
```

## Assertions

✅ **Lambda success**: ✅ PASS
✅ **FlightState record exists**: ✅ PASS
✅ **CurrentFlightAcceptanceStatusCode=GATED**: ✅ PASS
✅ **CurrentFlightGeneralStatusCode=OPEN**: ✅ PASS
✅ **CurrentFlightLoadControlStatusCode=CONTROL_IGNORED**: ✅ PASS
✅ **CurrentFlightBoardingStatusCode=NOT_OPEN**: ✅ PASS
✅ **UTCFlightAcceptanceStatusModifiedAt populated**: ✅ PASS
✅ **UTCFlightGeneralStatusModifiedAt populated**: ✅ PASS
✅ **RecordCreatedAt populated**: ✅ PASS

---
## Final Verdict: ✅ PASSED