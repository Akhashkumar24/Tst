# TC-09 - Verify missing carrierCode handling — writer persists partial, FlightState skipped

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T07:45:15.493Z
**Result:** ✅ PASSED
**Duration:** 9373ms

## Test Description
Send payload with carrierCode removed. Writer Lambda persists to InventoryFlight with null carriers. FlightState is NOT populated (null key fields). This documents writer behavior — validation is expected upstream at transformer layer.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785915908409-qut5olcpt"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8009-2026-11-16",
    "version": "1785915908409999147",
    "flightDesignator": {
      "flightNumber": "8009"
    },
    "scheduledDepartureDate": "2026-11-16",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-16T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YUL_2",
        "iataCode": "YUL",
        "city": "YUL",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-16T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-16-YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-16T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-16T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-16T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YUL"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-16T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-16T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-16T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-16T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8009-2026-11-16",
    "originFeedTimeStamp": "2026-08-05T07:45:08.410Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2442 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T07:45:08.410Z

## Database Verification

### Query 1: InventoryFlight (partial record expected)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8009-2026-11-16"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8009-2026-11-16",
    "MarketingCarrierCode": null,
    "OperatingCarrierCode": null,
    "MarketingNumber": "8009",
    "OperatingNumber": "8009",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-15T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8E4B4P0BRNX61MCZVCY56P",
    "RecordCreatedAt": "2026-08-05T07:45:11.329Z",
    "RecordModifiedAt": "2026-08-05T07:45:11.329Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785915908409999000"
  }
]
```

### Query 2: FlightState (should be empty — null key)
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8009","YYZ","2026-11-16"]
**Row Count:** 0
**Results:**
```json
[]
```

## Assertions

✅ **Lambda returned 200 (no crash)**: ✅ PASS
✅ **No Lambda functionError**: ✅ PASS
✅ **InventoryFlight record created (writer persists partial)**: ✅ PASS
✅ **MarketingCarrierCode is null (carrierCode was removed)**: ✅ PASS
✅ **OperatingCarrierCode is null (carrierCode was removed)**: ✅ PASS
✅ **FlightState NOT populated (null key field)**: ✅ PASS

---
## Final Verdict: ✅ PASSED