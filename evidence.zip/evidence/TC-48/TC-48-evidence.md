# TC-48 - Validate operationalSuffix stored in InventoryFlight and FlightState

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T10:12:49.120Z
**Result:** ✅ PASSED
**Duration:** 6396ms

## Test Description
Ingest with operationalSuffix='B'. Verify InventoryFlight.OperationalSuffix and FlightState.OperationalSuffix.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785924764989-c17rd2udp"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8048-2026-11-19",
    "version": "178592476498977373",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8048",
      "operationalSuffix": "B"
    },
    "scheduledDepartureDate": "2026-11-19",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC"
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-19T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YUL_2",
        "iataCode": "YUL",
        "city": "YUL",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-19T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-19-YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-19T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-19T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-19T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-19T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YUL"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-19T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-19T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-19T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-19T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8048-2026-11-19",
    "originFeedTimeStamp": "2026-08-05T10:12:44.989Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2484 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T10:12:44.989Z

## Database Verification

### Query 1: InventoryFlight (OperationalSuffix)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8048-2026-11-19"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8048-2026-11-19",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8048",
    "OperatingNumber": "8048",
    "OperationalSuffix": "B",
    "LocalOriginDepartureAt": "2026-11-18T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": false,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8PJHGCVQVAE6F6XSW0T0V9",
    "RecordCreatedAt": "2026-08-05T10:12:45.197Z",
    "RecordModifiedAt": "2026-08-05T10:12:45.197Z",
    "RecordExpiredAt": null,
    "RecordVersion": "178592476498977380"
  }
]
```

### Query 2: FlightState (OperationalSuffix)
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8048","YYZ","2026-11-19"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8048",
    "OperationalSuffix": "B",
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YUL",
    "LocalDepartureScheduledDate": "2026-11-18T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T10:12:45.197Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T10:12:45.197Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T10:12:45.197Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T10:12:45.197Z",
    "CurrentBagFlightLoadStatusCode": null,
    "PreviousBagFlightLoadStatusCode": null,
    "UTCBagFlightLoadStatusModifiedAt": null,
    "RecordCorrelationId": "01KZ8PJHGCVQVAE6F6XSW0T0V9",
    "RecordCreatedAt": "2026-08-05T10:12:45.197Z",
    "RecordModifiedAt": "2026-08-05T10:12:45.197Z",
    "RecordExpiredAt": "2027-08-05T10:12:45.197Z",
    "RecordVersion": "178592476498977380",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

## Assertions

✅ **Lambda success**: ✅ PASS
✅ **InventoryFlight.OperationalSuffix=B**: ✅ PASS
✅ **FlightState.OperationalSuffix=B**: ✅ PASS

---
## Final Verdict: ✅ PASSED