# TC-32 - Validate null entries in Characteristics array are ignored

**Story:** ODH-27514 | **Parent:** ODH-24518
**Lambda:** ac-odh-skd-event-ingestion-skd-event-ingestion-uatca1-writer
**Executed At:** 2026-08-05T09:58:07.229Z
**Result:** ✅ PASSED
**Duration:** 11349ms

## Test Description
Ingest event with Characteristics=[DOMESTIC, null, INTERNATIONAL, null]. Verify nulls skipped, record persists to BookingInventoryDataStore.InventoryFlight with correct IsDomestic/IsInternational flags.

## Payload Sent to Lambda
```json
{
  "meta": {
    "triggerEventLog": {
      "id": "tc-1785923878349-iypttrhv5"
    },
    "version": "1.3.0"
  },
  "scheduleProcessedFlight": {
    "type": "dated-flight",
    "id": "AC-8032-2026-11-18",
    "version": "1785923878349893796",
    "flightDesignator": {
      "carrierCode": "AC",
      "flightNumber": "8032"
    },
    "scheduledDepartureDate": "2026-11-18",
    "dayOfOperation": "WED",
    "isCancelled": false,
    "characteristics": [
      "DOMESTIC",
      null,
      "INTERNATIONAL",
      null
    ],
    "codeshare": "OPERATING",
    "flightPoints": [
      {
        "id": "YYZ_1",
        "iataCode": "YYZ",
        "city": "YYZ",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "departure": {
          "timings": [
            {
              "qualifier": "STD",
              "value": "2026-11-18T08:00:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      },
      {
        "id": "YUL_2",
        "iataCode": "YUL",
        "city": "YUL",
        "country": "CA",
        "region": "NAMER",
        "continent": "ITC1",
        "arrival": {
          "timings": [
            {
              "qualifier": "STA",
              "value": "2026-11-18T10:30:00"
            }
          ],
          "terminals": [
            {
              "code": "1"
            }
          ]
        }
      }
    ],
    "segments": [
      {
        "id": "2026-11-18-YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-18T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-18T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-18T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-18T14:30:00Z",
        "numberOfLegs": 1,
        "legIds": [
          "YYZ-YUL"
        ]
      }
    ],
    "legs": [
      {
        "id": "YYZ-YUL",
        "boardFlightPointId": "YYZ_1",
        "offFlightPointId": "YUL_2",
        "boardPointIataCode": "YYZ",
        "offPointIataCode": "YUL",
        "scheduledDepartureDateTime": "2026-11-18T08:00:00",
        "scheduledDepartureDateTimeUtc": "2026-11-18T12:00:00Z",
        "scheduledArrivalDateTime": "2026-11-18T10:30:00",
        "scheduledArrivalDateTimeUtc": "2026-11-18T14:30:00Z",
        "routingOrder": 1,
        "serviceType": "J",
        "aircraftEquipment": {
          "aircraftType": "320",
          "scheduledFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "acvTotalCapacity": 170,
          "operationalSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "scheduledSaleableConfiguration": {
            "code": "001",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          },
          "operationalFittedConfiguration": {
            "code": "321",
            "configurationContents": [
              {
                "cabin": "J",
                "capacity": 14
              },
              {
                "cabin": "Y",
                "capacity": 156
              }
            ]
          }
        },
        "legDCSStatuses": {
          "acceptanceStatus": "OPEN",
          "generalStatus": "OPEN",
          "loadControlStatus": "OPEN",
          "boardingStatus": "NOT_OPEN"
        }
      }
    ]
  },
  "events": {
    "recordDomain": "SCHEDULE",
    "recordId": "AC-8032-2026-11-18",
    "originFeedTimeStamp": "2026-08-05T09:57:58.349Z",
    "events": [
      {
        "origin": "COMPARISON",
        "eventType": "CREATED"
      }
    ]
  }
}
```

## Kafka Event Wrapper
```json
{
  "eventSource": "SelfManagedKafka",
  "bootstrapServers": "demo:9092",
  "topic": "emh-dev.ALTEA-SKDDATA-UAT",
  "partition": 0,
  "value": "<base64 of payload - 2487 bytes>"
}
```

## Lambda Invocation Result
- **Status Code:** 200
- **Function Error:** None
- **Invoked At:** 2026-08-05T09:57:58.350Z

## Database Verification

### Query 1: InventoryFlight (null characteristics handled)
**Database:** CustomerDataMart
**SQL:**
```sql
SELECT * FROM "BookingInventoryDataStore"."InventoryFlight" WHERE "Id" = $1
```
**Parameters:** ["AC-8032-2026-11-18"]
**Row Count:** 1
**Results:**
```json
[
  {
    "Id": "AC-8032-2026-11-18",
    "MarketingCarrierCode": "AC",
    "OperatingCarrierCode": "AC",
    "MarketingNumber": "8032",
    "OperatingNumber": "8032",
    "OperationalSuffix": null,
    "LocalOriginDepartureAt": "2026-11-17T18:30:00.000Z",
    "LocalOriginDepartureDay": "WED",
    "IsCancelled": false,
    "IsDomestic": true,
    "IsInternational": true,
    "IsOperatingCodeshare": true,
    "IsMarketingCodeshare": false,
    "IsPrimeCodeshare": false,
    "RecordCorrelationId": "01KZ8NQKJ5TE96TRPMB5C6TSA6",
    "RecordCreatedAt": "2026-08-05T09:58:02.566Z",
    "RecordModifiedAt": "2026-08-05T09:58:02.566Z",
    "RecordExpiredAt": null,
    "RecordVersion": "1785923878349894000"
  }
]
```

### Query 2: FlightState
**Database:** OperationsDataMart
**SQL:**
```sql

    SELECT * FROM "FlightOperationsDataStore"."FlightState"
    WHERE "OperatingCarrierCode" = $1
      AND "OperatingFlightNumber" = $2
      AND "DepartureAirportIATACode" = $3
      AND "LocalDepartureScheduledDate" = $4
  
```
**Parameters:** ["AC","8032","YYZ","2026-11-18"]
**Row Count:** 1
**Results:**
```json
[
  {
    "OperatingCarrierCode": "AC",
    "OperatingFlightNumber": "8032",
    "OperationalSuffix": null,
    "DepartureAirportIATACode": "YYZ",
    "ArrivalAirportIATACode": "YUL",
    "LocalDepartureScheduledDate": "2026-11-17T18:30:00.000Z",
    "CurrentFlightAcceptanceStatusCode": "OPEN",
    "CurrentFlightGeneralStatusCode": "OPEN",
    "CurrentFlightLoadControlStatusCode": "OPEN",
    "CurrentFlightBoardingStatusCode": "NOT_OPEN",
    "PreviousFlightAcceptanceStatusCode": null,
    "PreviousFlightGeneralStatusCode": null,
    "PreviousFlightLoadControlStatusCode": null,
    "PreviousFlightBoardingStatusCode": null,
    "UTCFlightAcceptanceStatusModifiedAt": "2026-08-05T09:58:02.566Z",
    "UTCFlightGeneralStatusModifiedAt": "2026-08-05T09:58:02.566Z",
    "UTCFlightLoadControlStatusModifiedAt": "2026-08-05T09:58:02.566Z",
    "UTCFlightBoardingStatusModifiedAt": "2026-08-05T09:58:02.566Z",
    "CurrentBagFlightLoadStatusCode": null,
    "PreviousBagFlightLoadStatusCode": null,
    "UTCBagFlightLoadStatusModifiedAt": null,
    "RecordCorrelationId": "01KZ8NQKJ5TE96TRPMB5C6TSA6",
    "RecordCreatedAt": "2026-08-05T09:58:02.566Z",
    "RecordModifiedAt": "2026-08-05T09:58:02.566Z",
    "RecordExpiredAt": "2027-08-05T09:58:02.566Z",
    "RecordVersion": "1785923878349894000",
    "SourceCreatedBy": "ALTEA-SKD"
  }
]
```

## Assertions

✅ **Lambda success (no crash on null in array)**: ✅ PASS
✅ **No Lambda functionError**: ✅ PASS
✅ **InventoryFlight record persisted**: ✅ PASS
✅ **IsDomestic flag set**: ✅ PASS
✅ **IsInternational flag set**: ✅ PASS
✅ **FlightState record persisted**: ✅ PASS

---
## Final Verdict: ✅ PASSED